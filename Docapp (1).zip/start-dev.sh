#!/bin/bash
# Robust dev server startup script
# Starts Next.js dev server and pre-warms all API routes
cd /home/z/my-project

# Kill any existing server
pkill -f "next dev" 2>/dev/null
sleep 1

# Start the dev server
node_modules/.bin/next dev -p 3000 --webpack >> /home/z/my-project/dev.log 2>&1 &
SERVER_PID=$!

# Wait for server to be ready
echo "[$(date)] Waiting for server to start..."
for i in $(seq 1 30); do
  if curl -s http://localhost:3000/ > /dev/null 2>&1; then
    echo "[$(date)] Server ready!"
    break
  fi
  sleep 1
done

# Pre-warm all API routes (compile them so first user visit is fast)
echo "[$(date)] Pre-warming API routes..."
for route in doctors hospitals ambulances categories articles slides cities auth/me medicine-reminders ratings blood-donors; do
  curl -s http://localhost:3000/api/$route > /dev/null 2>&1
done
echo "[$(date)] API routes pre-warmed!"

# Wait for the server process
wait $SERVER_PID
