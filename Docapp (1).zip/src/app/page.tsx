import fs from "node:fs";
import path from "node:path";

const HTML_PATH = path.join(process.cwd(), "index.html");

function getHtml() {
  return fs.readFileSync(HTML_PATH, "utf-8");
}

export const dynamic = "force-dynamic";

export default function Page() {
  const html = getHtml();
  return (
    <iframe
      srcDoc={html}
      title="Doctor App"
      style={{
        position: "fixed",
        inset: 0,
        width: "100vw",
        height: "100vh",
        border: 0,
        display: "block",
      }}
    />
  );
}
