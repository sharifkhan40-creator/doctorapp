import { NextResponse } from "next/server";
import { getSessionUser, clearSession, invalidateAllSessions } from "@/lib/auth";

// POST /api/auth/logout-all — clears current session AND invalidates all other
// sessions for this user (by bumping sessionVersion). The user will need to
// sign in again "by first hand" on every device.
export async function POST() {
  const user = await getSessionUser();
  if (user) {
    await invalidateAllSessions(user.id);
  }
  await clearSession();
  return NextResponse.json({
    ok: true,
    message: "Logged out from all sessions.",
  });
}
