import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { token, newPassword } = body as {
      token: string;
      newPassword: string;
    };

    if (!token || !newPassword) {
      return NextResponse.json(
        { error: "Token and new password are required." },
        { status: 400 },
      );
    }
    if (newPassword.length < 6) {
      return NextResponse.json(
        { error: "Password must be at least 6 characters." },
        { status: 400 },
      );
    }

    const reset = await db.passwordReset.findUnique({ where: { token } });
    if (!reset || reset.used) {
      return NextResponse.json(
        { error: "This reset link is invalid or has already been used." },
        { status: 400 },
      );
    }
    if (reset.expiresAt.getTime() < Date.now()) {
      return NextResponse.json(
        { error: "This reset link has expired. Please request a new one." },
        { status: 400 },
      );
    }

    const hash = await hashPassword(newPassword);
    await db.user.update({
      where: { email: reset.email },
      data: { passwordHash: hash },
    });
    await db.passwordReset.update({
      where: { id: reset.id },
      data: { used: true },
    });

    return NextResponse.json({
      message: "Your password has been reset successfully. You can now log in.",
    });
  } catch (e) {
    console.error("reset-password error", e);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 },
    );
  }
}
