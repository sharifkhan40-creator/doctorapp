import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { identifier } = body as { identifier: string };

    if (!identifier) {
      return NextResponse.json(
        { error: "Please enter your email or username." },
        { status: 400 },
      );
    }

    // Lookup by email or username
    const user = await db.user.findFirst({
      where: {
        OR: [{ email: identifier }, { username: identifier }],
      },
    });

    // For security we always return a similar message, but we generate a token
    // only when the account exists. In this sandbox we return the token to the
    // client so the user can actually recover the password without an email
    // server. The reset link contains the token.
    if (!user) {
      return NextResponse.json({
        found: false,
        message:
          "If an account exists for that email/username, a reset link has been generated.",
      });
    }

    // Invalidate old unused tokens
    await db.passwordReset.updateMany({
      where: { email: user.email, used: false },
      data: { used: true },
    });

    const token = crypto.randomUUID().replace(/-/g, "") + crypto.randomUUID().replace(/-/g, "");
    const expiresAt = new Date(Date.now() + 1000 * 60 * 30); // 30 minutes

    await db.passwordReset.create({
      data: {
        email: user.email,
        username: user.username,
        token,
        expiresAt,
      },
    });

    return NextResponse.json({
      found: true,
      token,
      email: user.email,
      username: user.username,
      message:
        "We found your account. Use the reset token below to set a new password.",
    });
  } catch (e) {
    console.error("forgot-password error", e);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 },
    );
  }
}
