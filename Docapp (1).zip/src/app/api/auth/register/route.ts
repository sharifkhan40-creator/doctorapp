import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, createSession, sanitizeUser } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { email, username, password, role, hospitalId } = body as {
      email: string;
      username: string;
      password: string;
      role: string;
      hospitalId?: string;
    };

    if (!email || !username || !password) {
      return NextResponse.json(
        { error: "Email, username and password are required." },
        { status: 400 },
      );
    }

    const emailOk = /^\S+@\S+\.\S+$/.test(email);
    if (!emailOk) {
      return NextResponse.json(
        { error: "Please enter a valid email address." },
        { status: 400 },
      );
    }
    if (password.length < 6) {
      return NextResponse.json(
        { error: "Password must be at least 6 characters." },
        { status: 400 },
      );
    }

    const normalizedRole = (role || "USER").toUpperCase();
    const allowedRoles = ["USER", "DOCTOR", "ADMIN"];
    if (!allowedRoles.includes(normalizedRole)) {
      return NextResponse.json({ error: "Invalid role." }, { status: 400 });
    }

    // Doctors must select a hospital (added by super admin / admin)
    if (normalizedRole === "DOCTOR" && !hospitalId) {
      return NextResponse.json(
        { error: "Please select your hospital to register as a doctor." },
        { status: 400 },
      );
    }
    if (hospitalId) {
      const hospital = await db.hospital.findUnique({ where: { id: hospitalId } });
      if (!hospital) {
        return NextResponse.json(
          { error: "Selected hospital not found." },
          { status: 400 },
        );
      }
    }

    const existingEmail = await db.user.findUnique({ where: { email } });
    if (existingEmail) {
      return NextResponse.json(
        { error: "An account with this email already exists." },
        { status: 409 },
      );
    }
    const existingUsername = await db.user.findUnique({ where: { username } });
    if (existingUsername) {
      return NextResponse.json(
        { error: "This username is already taken." },
        { status: 409 },
      );
    }

    const hash = await hashPassword(password);

    // Doctors and Admins need approval; the stored role stays USER but the
    // status records the requested role so a super admin can approve it.
    const isRequestRole =
      normalizedRole === "DOCTOR" || normalizedRole === "ADMIN";
    const status = isRequestRole ? `PENDING_${normalizedRole}` : "ACTIVE";

    const user = await db.user.create({
      data: {
        email,
        username,
        passwordHash: hash,
        role: "USER",
        status,
      },
    });

    // If a doctor registers with a hospital, auto-create their DoctorProfile
    // so they appear in the doctor directory. They can complete the rest later.
    if (normalizedRole === "DOCTOR" && hospitalId) {
      await db.doctorProfile.create({
        data: {
          userId: user.id,
          name: `Dr. ${username}`,
          specialty: "General Physician",
          qualifications: "Please update your qualifications",
          experience: 0,
          fee: 0,
          phone: "",
          hospitalId,
          address: "",
          city: "",
          hours: "",
        },
      });
    }

    await createSession(user.id);

    return NextResponse.json({
      user: sanitizeUser(user),
      requestedRole: normalizedRole,
      needsApproval: isRequestRole,
      message: isRequestRole
        ? "Registration successful! Your account is pending approval by a Super Admin. You can still fill in your profile meanwhile."
        : "Registration successful! Welcome aboard.",
    });
  } catch (e) {
    console.error("register error", e);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 },
    );
  }
}
