import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword, createSession, sanitizeUser } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { identifier, password } = body as {
      identifier: string;
      password: string;
    };

    if (!identifier || !password) {
      return NextResponse.json(
        { error: "Please enter your credentials." },
        { status: 400 },
      );
    }

    // Identifier can be email or username
    const user = await db.user.findFirst({
      where: {
        OR: [{ email: identifier }, { username: identifier }],
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: "No account found with those credentials." },
        { status: 404 },
      );
    }

    const ok = await verifyPassword(password, user.passwordHash);
    if (!ok) {
      return NextResponse.json(
        { error: "Incorrect password. Please try again." },
        { status: 401 },
      );
    }

    await createSession(user.id);

    // Derive the effective role from status for pending doctor/admin requests
    let effectiveRole = user.role;
    let needsApproval = false;
    if (user.status === "PENDING_DOCTOR") {
      effectiveRole = "DOCTOR";
      needsApproval = true;
    } else if (user.status === "PENDING_ADMIN") {
      effectiveRole = "ADMIN";
      needsApproval = true;
    }

    return NextResponse.json({
      user: sanitizeUser({ ...user, role: effectiveRole }),
      needsApproval,
      message: "Logged in successfully.",
    });
  } catch (e) {
    console.error("login error", e);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 },
    );
  }
}
