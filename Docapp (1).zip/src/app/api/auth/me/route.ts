import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, sanitizeUser } from "@/lib/auth";

export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ user: null }, { status: 200 });
  }

  let effectiveRole = user.role;
  let needsApproval = false;
  if (user.status === "PENDING_DOCTOR") {
    effectiveRole = "DOCTOR";
    needsApproval = true;
  } else if (user.status === "PENDING_ADMIN") {
    effectiveRole = "ADMIN";
    needsApproval = true;
  }

  const profile =
    effectiveRole === "DOCTOR"
      ? await db.doctorProfile.findUnique({
          where: { userId: user.id },
          include: { hospital: true },
        })
      : effectiveRole === "ADMIN" || effectiveRole === "SUPER_ADMIN"
        ? await db.adminProfile.findUnique({ where: { userId: user.id } })
        : null;

  return NextResponse.json({
    user: sanitizeUser({ ...user, role: effectiveRole }),
    needsApproval,
    hasProfile: !!profile,
    profile,
  });
}
