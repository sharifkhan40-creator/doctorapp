import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const ambulances = await db.ambulance.findMany({
    orderBy: [{ city: "asc" }, { name: "asc" }],
  });
  return NextResponse.json({ ambulances });
}
