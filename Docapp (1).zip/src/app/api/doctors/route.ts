import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim();
  const specialty = searchParams.get("specialty")?.trim();
  const city = searchParams.get("city")?.trim();
  const hospitalId = searchParams.get("hospitalId")?.trim();

  const where: Record<string, unknown> = {};
  if (q) {
    where.OR = [
      { name: { contains: q } },
      { specialty: { contains: q } },
      { qualifications: { contains: q } },
    ];
  }
  if (specialty) where.specialty = { contains: specialty };
  if (city) where.city = { contains: city };
  if (hospitalId) where.hospitalId = hospitalId;

  const doctors = await db.doctorProfile.findMany({
    where,
    orderBy: { name: "asc" },
    include: { hospital: true },
  });
  return NextResponse.json({ doctors });
}
