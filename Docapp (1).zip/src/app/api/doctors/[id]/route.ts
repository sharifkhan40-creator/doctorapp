import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const doctor = await db.doctorProfile.findUnique({
    where: { id },
    include: { hospital: true },
  });
  if (!doctor) {
    return NextResponse.json({ error: "Doctor not found." }, { status: 404 });
  }
  return NextResponse.json({ doctor });
}
