import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

// GET /api/blood-donors/me — the signed-in user's blood donor entry (if any)
export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const donor = await db.bloodDonor.findUnique({
    where: { userId: user.id },
  });
  return NextResponse.json({ donor });
}

// DELETE /api/blood-donors/me — remove the signed-in user's blood donor entry
export async function DELETE() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  await db.bloodDonor.deleteMany({ where: { userId: user.id } });
  return NextResponse.json({ ok: true, message: "Blood donation details removed." });
}
