import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

// GET /api/blood-donors — public list of all blood donors
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const bloodGroup = searchParams.get("bloodGroup")?.trim();
  const city = searchParams.get("city")?.trim();

  const where: Record<string, unknown> = { available: true };
  if (bloodGroup) where.bloodGroup = bloodGroup;
  if (city) where.city = { contains: city };

  const donors = await db.bloodDonor.findMany({
    where,
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ donors });
}

// POST /api/blood-donors — create or update the signed-in user's blood donor entry
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json(
      { error: "Please sign in to add blood donation details." },
      { status: 401 },
    );
  }
  try {
    const body = await req.json();
    const { name, bloodGroup, phone, city, area, available, lastDonated, note } =
      body as Record<string, string>;

    if (!name || !bloodGroup || !phone || !city) {
      return NextResponse.json(
        { error: "Name, blood group, phone and city are required." },
        { status: 400 },
      );
    }

    const existing = await db.bloodDonor.findUnique({
      where: { userId: user.id },
    });

    const data = {
      name,
      bloodGroup,
      phone,
      city,
      area: area || null,
      available: available !== undefined ? available === "true" || available === true : true,
      lastDonated: lastDonated || null,
      note: note || null,
    };

    const donor = existing
      ? await db.bloodDonor.update({
          where: { userId: user.id },
          data,
        })
      : await db.bloodDonor.create({
          data: { userId: user.id, ...data },
        });

    return NextResponse.json({
      donor,
      message: "Blood donation details saved successfully.",
    });
  } catch (e) {
    console.error("blood donor create error", e);
    return NextResponse.json(
      { error: "Something went wrong." },
      { status: 500 },
    );
  }
}
