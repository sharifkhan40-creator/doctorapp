import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

// POST /api/ratings — submit a rating for doctor/hospital/ambulance
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Please sign in to rate." }, { status: 401 });
  }
  try {
    const body = await req.json();
    const { entityType, entityId, rating, review } = body as {
      entityType: string;
      entityId: string;
      rating: number;
      review?: string;
    };
    if (!entityType || !entityId || !rating) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }
    if (rating < 1 || rating > 5) {
      return NextResponse.json({ error: "Rating must be 1-5." }, { status: 400 });
    }

    // Check if user already rated this entity
    const existing = await db.rating.findFirst({
      where: { userId: user.id, entityType, entityId },
    });

    let ratingRecord;
    if (existing) {
      ratingRecord = await db.rating.update({
        where: { id: existing.id },
        data: { rating, review: review || null },
      });
    } else {
      ratingRecord = await db.rating.create({
        data: { userId: user.id, entityType, entityId, rating, review: review || null },
      });
    }

    // Update the entity's average rating
    const allRatings = await db.rating.findMany({
      where: { entityType, entityId },
      select: { rating: true },
    });
    const avg = allRatings.reduce((sum, r) => sum + r.rating, 0) / allRatings.length;

    if (entityType === "doctor") {
      await db.doctorProfile.update({ where: { id: entityId }, data: { rating: Math.round(avg * 10) / 10 } });
    } else if (entityType === "hospital") {
      await db.hospital.update({ where: { id: entityId }, data: { rating: Math.round(avg * 10) / 10 } });
    } else if (entityType === "ambulance") {
      await db.ambulance.update({ where: { id: entityId }, data: { rating: Math.round(avg * 10) / 10 } });
    }

    return NextResponse.json({ rating: ratingRecord, average: Math.round(avg * 10) / 10, message: "Rating submitted!" });
  } catch (e) {
    console.error("rating error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}

// GET /api/ratings?entityType=doctor&entityId=xxx
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const entityType = searchParams.get("entityType");
  const entityId = searchParams.get("entityId");
  if (!entityType || !entityId) {
    return NextResponse.json({ ratings: [] });
  }
  const ratings = await db.rating.findMany({
    where: { entityType, entityId },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ ratings });
}
