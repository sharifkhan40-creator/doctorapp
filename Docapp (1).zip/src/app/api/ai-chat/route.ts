import { NextResponse } from "next/server";

const OPENROUTER_API_KEY =
  "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";
const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const MODEL = "meta-llama/llama-3.3-70b-instruct";

const SYSTEM_PROMPT = `You are "AI Assistant," a virtual medical assistant for the Doctor App healthcare website.

LANGUAGE RULES (CRITICAL):
- If the user writes in English, you MUST reply in English only.
- If the user writes in Bengali (বাংলা script), you MUST reply in Bengali only.
- If the user writes in Banglish (Bengali in Roman script), reply in Banglish.
- NEVER mix languages. Match the user's language exactly.

WORKFLOW:
1. If you don't know the patient's name and location, ask for them politely.
2. Once you have name and location, ask about their symptoms.
3. Map symptoms to specialties: Cardiologist (heart/chest), Dermatologist (skin/rash), Neurologist (headache/brain), Gynecologist (women/pregnancy), Pediatrician (child/baby), Dentist (tooth), Orthopedic (bone/joint/back), ENT (ear/nose/throat), Eye Specialist (eye/vision), General Physician (fever/cough/cold).
4. When recommending doctors, your text reply should be BRIEF — just acknowledge their symptoms and say you found some specialists. For example: "Based on your symptoms of skin rash, I found some dermatologists for you:" — then STOP. Do NOT write any doctor details.

STRICT RULE ABOUT DOCTOR DETAILS:
- DO NOT write doctor names, qualifications, addresses, phone numbers, hours, fees, or any details in your text reply.
- DO NOT use bullet points, lists, or any formatting for doctor information.
- DO NOT say "Dr. X - Specialty - Qualifications" etc.
- The app will AUTOMATICALLY show interactive doctor cards with all details after your text reply.
- Your text should ONLY be a brief intro like "Here are some recommended specialists:" or "আপনার লক্ষণ অনুযায়ী কিছু বিশেষজ্ঞ নিচে দেওয়া হলো:"
- Then STOP. Let the cards appear automatically.

SAFETY:
- If symptoms are life-threatening, tell them to call emergency services immediately.
- Keep responses concise and friendly. Do not prescribe medicines.`;

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { messages, doctors } = body as {
      messages: Array<{ role: string; content: string }>;
      doctors: Array<{
        id: string;
        name: string;
        specialty: string;
        qualifications: string;
        city: string;
        address: string;
        hours: string;
        fee: number;
        hospital?: { name: string };
      }>;
    };

    // Only pass minimal info to LLM so it can match but not output details
    const doctorList = doctors
      .map((d) => `${d.name} (${d.specialty}, ${d.city})`)
      .join(", ");

    const fullSystemPrompt = `${SYSTEM_PROMPT}

Available doctors for matching: ${doctorList}

When you recommend doctors, your reply text should ONLY be a brief sentence like:
- English: "Based on your symptoms, here are some recommended specialists:"
- Bengali: "আপনার লক্ষণ অনুযায়ী, এখানে কিছু বিশেষজ্ঞ রয়েছেন:"

Then STOP. The app will show doctor cards automatically. Do NOT write any doctor names or details in your text.`;

    // Call OpenRouter API
    const response = await fetch(OPENROUTER_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENROUTER_API_KEY}`,
        "HTTP-Referer": "https://doctor-app.local",
        "X-Title": "Doctor App AI Assistant",
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: fullSystemPrompt },
          ...messages.map((m) => ({
            role: m.role as "user" | "assistant",
            content: m.content,
          })),
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("OpenRouter API error:", response.status, errorText);
      return NextResponse.json(
        { error: "AI assistant is temporarily unavailable. Please try again." },
        { status: 500 },
      );
    }

    const data = await response.json();
    let reply =
      data.choices?.[0]?.message?.content ||
      "I'm sorry, I couldn't process that. Could you rephrase?";

    // Post-process: strip any doctor details the LLM might have included
    reply = reply
      .split("\n")
      .filter((line) => {
        const trimmed = line.trim();
        if (!trimmed) return true;
        if (trimmed.startsWith("📋")) return false;
        if (trimmed.startsWith("- **") && trimmed.includes("**")) return false;
        if (trimmed.startsWith("- Specialty")) return false;
        if (trimmed.startsWith("- Qualifications")) return false;
        if (trimmed.startsWith("- Location")) return false;
        if (trimmed.startsWith("- Hours")) return false;
        if (trimmed.startsWith("- Fee")) return false;
        if (trimmed.startsWith("- Book")) return false;
        if (trimmed.startsWith("- Hospital")) return false;
        if (trimmed.startsWith("- Phone")) return false;
        if (trimmed.startsWith("- Address")) return false;
        if (trimmed.includes("|") && trimmed.includes("Dr.")) return false;
        if (trimmed.match(/^Dr\.\s+.+[-–—]/)) return false;
        return true;
      })
      .join("\n")
      .trim();

    return NextResponse.json({ reply });
  } catch (e) {
    console.error("AI chat error:", e);
    return NextResponse.json(
      { error: "AI assistant is temporarily unavailable. Please try again." },
      { status: 500 },
    );
  }
}
