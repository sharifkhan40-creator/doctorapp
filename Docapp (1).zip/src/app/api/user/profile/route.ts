import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

// GET /api/user/profile — the signed-in user's profile fields
export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return NextResponse.json({
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
      status: user.status,
      name: user.name,
      phone: user.phone,
      address: user.address,
      photo: user.photo,
      bloodGroup: user.bloodGroup,
      createdAt: user.createdAt,
    },
  });
}

// PUT /api/user/profile — update profile fields (name, phone, address, photo, bloodGroup)
export async function PUT(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const body = await req.json();
    const { name, phone, address, photo, bloodGroup } = body as Record<
      string,
      string
    >;

    const updated = await db.user.update({
      where: { id: user.id },
      data: {
        name: name !== undefined ? name || null : undefined,
        phone: phone !== undefined ? phone || null : undefined,
        address: address !== undefined ? address || null : undefined,
        photo: photo !== undefined ? photo || null : undefined,
        bloodGroup: bloodGroup !== undefined ? bloodGroup || null : undefined,
      },
    });

    return NextResponse.json({
      user: {
        id: updated.id,
        email: updated.email,
        username: updated.username,
        role: updated.role,
        status: updated.status,
        name: updated.name,
        phone: updated.phone,
        address: updated.address,
        photo: updated.photo,
        bloodGroup: updated.bloodGroup,
      },
      message: "Profile updated successfully.",
    });
  } catch (e) {
    console.error("user profile update error", e);
    return NextResponse.json(
      { error: "Something went wrong." },
      { status: 500 },
    );
  }
}
