import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function GET() {
  const cities = await db.city.findMany({ orderBy: { name: "asc" } });
  return NextResponse.json({ cities });
}

export async function POST(req: Request) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  try {
    const body = await req.json();
    const { name } = body as { name: string };
    if (!name) {
      return NextResponse.json({ error: "City name is required." }, { status: 400 });
    }
    const existing = await db.city.findFirst({ where: { name } });
    if (existing) {
      return NextResponse.json({ error: "City already exists." }, { status: 409 });
    }
    const city = await db.city.create({ data: { name } });
    return NextResponse.json({ city, message: "City added." });
  } catch (e) {
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
