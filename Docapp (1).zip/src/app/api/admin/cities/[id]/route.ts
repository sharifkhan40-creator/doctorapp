import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  await db.city.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
