import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-auth";
import { hashPassword } from "@/lib/auth";

export async function GET() {
  const doctors = await db.doctorProfile.findMany({
    orderBy: { name: "asc" },
    include: { hospital: { select: { id: true, name: true, city: true } } },
  });
  return NextResponse.json({ doctors });
}

export async function POST(req: Request) {
  const { denied } = await requireAdmin();
  if (denied) return denied;
  try {
    const body = await req.json();
    const {
      name, specialty, qualifications, experience, fee, phone, email,
      hospitalId, address, city, hours, mapLink, photo, bio, youtubeUrl,
    } = body as Record<string, string>;
    if (!name || !specialty || !qualifications || !phone || !address || !city || !hours) {
      return NextResponse.json(
        { error: "Please fill all required fields." },
        { status: 400 },
      );
    }
    // Admin-created doctors get their own (inactive) user account so the
    // DoctorProfile → User relation stays valid.
    const base = (name || "doctor").toLowerCase().replace(/[^a-z]/g, "") || "doctor";
    let username = base;
    let n = 1;
    while (await db.user.findUnique({ where: { username } })) {
      username = `${base}${n++}`;
    }
    const doctorEmail =
      email || `${username}@doctor.app`;
    if (await db.user.findUnique({ where: { email: doctorEmail } })) {
      return NextResponse.json(
        { error: "A user with that email already exists." },
        { status: 409 },
      );
    }
    const user = await db.user.create({
      data: {
        email: doctorEmail,
        username,
        passwordHash: await hashPassword("doctor123"),
        role: "DOCTOR",
        status: "ACTIVE",
      },
    });
    const doctor = await db.doctorProfile.create({
      data: {
        userId: user.id,
        name, specialty, qualifications,
        experience: Number(experience) || 0,
        fee: Number(fee) || 0,
        phone, email: email || null,
        hospitalId: hospitalId || null,
        address, city, hours,
        mapLink: mapLink || null,
        photo: photo || null,
        bio: bio || null,
        youtubeUrl: youtubeUrl || null,
      },
    });
    return NextResponse.json({ doctor, message: "Doctor added." });
  } catch (e) {
    console.error("doctor create error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
