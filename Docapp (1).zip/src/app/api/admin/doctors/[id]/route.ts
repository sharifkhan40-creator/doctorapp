import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-auth";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await requireAdmin();
  if (denied) return denied;
  const { id } = await params;
  try {
    const body = await req.json();
    const {
      name, specialty, qualifications, experience, fee, phone, email,
      hospitalId, address, city, hours, mapLink, photo, bio, youtubeUrl,
    } = body as Record<string, string>;
    const doctor = await db.doctorProfile.update({
      where: { id },
      data: {
        name: name || undefined,
        specialty: specialty || undefined,
        qualifications: qualifications || undefined,
        experience: experience !== undefined ? Number(experience) : undefined,
        fee: fee !== undefined ? Number(fee) : undefined,
        phone: phone || undefined,
        email: email !== undefined ? email || null : undefined,
        hospitalId: hospitalId !== undefined ? hospitalId || null : undefined,
        address: address || undefined,
        city: city || undefined,
        hours: hours || undefined,
        mapLink: mapLink !== undefined ? mapLink || null : undefined,
        photo: photo !== undefined ? photo || null : undefined,
        bio: bio !== undefined ? bio || null : undefined,
        youtubeUrl: youtubeUrl !== undefined ? youtubeUrl || null : undefined,
      },
    });
    return NextResponse.json({ doctor, message: "Doctor updated." });
  } catch (e) {
    console.error("doctor update error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await requireAdmin();
  if (denied) return denied;
  const { id } = await params;
  await db.doctorProfile.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
