import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const profile = await db.adminProfile.findUnique({
    where: { userId: user.id },
  });
  return NextResponse.json({ profile });
}

export async function PUT(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const role =
    user.status === "PENDING_ADMIN" ? "ADMIN" : user.role;
  if (role !== "ADMIN" && role !== "SUPER_ADMIN") {
    return NextResponse.json(
      { error: "Only admin accounts can edit an admin profile." },
      { status: 403 },
    );
  }

  const body = await req.json();
  const { name, designation, department, phone, email, photo, bio } = body as Record<
    string,
    string
  >;

  if (!name || !designation || !department || !phone) {
    return NextResponse.json(
      { error: "Please fill in all required fields." },
      { status: 400 },
    );
  }

  const data = {
    name,
    designation,
    department,
    phone,
    email: email || null,
    photo: photo || null,
    bio: bio || null,
  };

  const existing = await db.adminProfile.findUnique({
    where: { userId: user.id },
  });

  const profile = existing
    ? await db.adminProfile.update({
        where: { userId: user.id },
        data,
      })
    : await db.adminProfile.create({
        data: { userId: user.id, ...data },
      });

  return NextResponse.json({
    profile,
    message: "Your admin profile has been saved successfully.",
  });
}
