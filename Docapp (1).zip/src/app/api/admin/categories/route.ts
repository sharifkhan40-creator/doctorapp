import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function GET() {
  const categories = await db.category.findMany({ orderBy: { name: "asc" } });
  return NextResponse.json({ categories });
}

export async function POST(req: Request) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  try {
    const body = await req.json();
    const { name, icon, bn } = body as Record<string, string>;
    if (!name) {
      return NextResponse.json({ error: "Name is required." }, { status: 400 });
    }
    const category = await db.category.create({
      data: { name, icon: icon || "stethoscope", bn: bn || name },
    });
    return NextResponse.json({ category, message: "Category added." });
  } catch (e) {
    console.error("category create error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
