import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  try {
    const body = await req.json();
    const { name, icon, bn } = body as Record<string, string>;
    const category = await db.category.update({
      where: { id },
      data: {
        name: name || undefined,
        icon: icon || undefined,
        bn: bn || undefined,
      },
    });
    return NextResponse.json({ category, message: "Category updated." });
  } catch (e) {
    console.error("category update error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  await db.category.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
