import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function GET() {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const slides = await db.slide.findMany({ orderBy: { order: "asc" } });
  return NextResponse.json({ slides });
}

export async function POST(req: Request) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  try {
    const body = await req.json();
    const { title, subtitle, image, btnText, btnLink, order } = body as Record<
      string,
      string
    >;
    if (!title || !image) {
      return NextResponse.json(
        { error: "Title and image are required." },
        { status: 400 },
      );
    }
    const slide = await db.slide.create({
      data: {
        title,
        subtitle: subtitle || null,
        image,
        btnText: btnText || null,
        btnLink: btnLink || null,
        order: Number(order) || 0,
      },
    });
    return NextResponse.json({ slide, message: "Slide added." });
  } catch (e) {
    console.error("slide create error", e);
    return NextResponse.json(
      { error: "Something went wrong." },
      { status: 500 },
    );
  }
}
