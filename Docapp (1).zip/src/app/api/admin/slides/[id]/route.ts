import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  try {
    const body = await req.json();
    const { title, subtitle, image, btnText, btnLink, order } = body as Record<
      string,
      string
    >;
    const slide = await db.slide.update({
      where: { id },
      data: {
        title: title || undefined,
        subtitle: subtitle !== undefined ? subtitle || null : undefined,
        image: image || undefined,
        btnText: btnText !== undefined ? btnText || null : undefined,
        btnLink: btnLink !== undefined ? btnLink || null : undefined,
        order: order !== undefined ? Number(order) : undefined,
      },
    });
    return NextResponse.json({ slide, message: "Slide updated." });
  } catch (e) {
    return NextResponse.json(
      { error: "Something went wrong." },
      { status: 500 },
    );
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  await db.slide.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
