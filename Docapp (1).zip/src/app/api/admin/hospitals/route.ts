import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-auth";

export async function GET() {
  const hospitals = await db.hospital.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { doctors: true } } },
  });
  return NextResponse.json({ hospitals });
}

export async function POST(req: Request) {
  const { denied } = await requireAdmin();
  if (denied) return denied;
  try {
    const body = await req.json();
    const { name, address, city, phone, mapLink, photo, fb, yt, ig, wa, web } =
      body as Record<string, string>;
    if (!name || !address || !city || !phone) {
      return NextResponse.json(
        { error: "Name, address, city and phone are required." },
        { status: 400 },
      );
    }
    const hospital = await db.hospital.create({
      data: {
        name, address, city, phone,
        mapLink: mapLink || null,
        photo: photo || null,
        fb: fb || null,
        yt: yt || null,
        ig: ig || null,
        wa: wa || null,
        web: web || null,
      },
    });
    return NextResponse.json({ hospital, message: "Hospital added." });
  } catch (e) {
    console.error("hospital create error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
