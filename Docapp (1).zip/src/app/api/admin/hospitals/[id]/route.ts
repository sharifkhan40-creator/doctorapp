import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-auth";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await requireAdmin();
  if (denied) return denied;
  const { id } = await params;
  try {
    const body = await req.json();
    const { name, address, city, phone, mapLink, photo, fb, yt, ig, wa, web } =
      body as Record<string, string>;
    const hospital = await db.hospital.update({
      where: { id },
      data: {
        name: name || undefined,
        address: address || undefined,
        city: city || undefined,
        phone: phone || undefined,
        mapLink: mapLink !== undefined ? mapLink || null : undefined,
        photo: photo !== undefined ? photo || null : undefined,
        fb: fb !== undefined ? fb || null : undefined,
        yt: yt !== undefined ? yt || null : undefined,
        ig: ig !== undefined ? ig || null : undefined,
        wa: wa !== undefined ? wa || null : undefined,
        web: web !== undefined ? web || null : undefined,
      },
    });
    return NextResponse.json({ hospital, message: "Hospital updated." });
  } catch (e) {
    console.error("hospital update error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await requireAdmin();
  if (denied) return denied;
  const { id } = await params;
  await db.hospital.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
