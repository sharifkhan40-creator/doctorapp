import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function GET() {
  const articles = await db.article.findMany({ orderBy: { createdAt: "desc" } });
  return NextResponse.json({ articles });
}

export async function POST(req: Request) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  try {
    const body = await req.json();
    const { title, excerpt, content, category, author, coverImage, readTime } =
      body as Record<string, string>;
    if (!title || !excerpt || !content) {
      return NextResponse.json(
        { error: "Title, excerpt and content are required." },
        { status: 400 },
      );
    }
    const article = await db.article.create({
      data: {
        title, excerpt, content,
        category: category || "Health",
        author: author || "Doctor App",
        coverImage: coverImage || null,
        readTime: Number(readTime) || 3,
      },
    });
    return NextResponse.json({ article, message: "Article added." });
  } catch (e) {
    console.error("article create error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
