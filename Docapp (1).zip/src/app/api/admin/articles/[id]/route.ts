import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  try {
    const body = await req.json();
    const { title, excerpt, content, category, author, coverImage, readTime } =
      body as Record<string, string>;
    const article = await db.article.update({
      where: { id },
      data: {
        title: title || undefined,
        excerpt: excerpt || undefined,
        content: content || undefined,
        category: category || undefined,
        author: author || undefined,
        coverImage: coverImage !== undefined ? coverImage || null : undefined,
        readTime: readTime !== undefined ? Number(readTime) : undefined,
      },
    });
    return NextResponse.json({ article, message: "Article updated." });
  } catch (e) {
    console.error("article update error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  await db.article.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
