import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function GET() {
  const users = await db.user.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      createdAt: true,
      doctorProfile: { select: { id: true, name: true } },
      adminProfile: { select: { id: true, name: true } },
    },
  });
  return NextResponse.json({ users });
}
