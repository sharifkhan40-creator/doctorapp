import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

// Approve a pending doctor/admin → set role + status ACTIVE
export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  try {
    const body = await req.json();
    const { action } = body as { action: string };
    const user = await db.user.findUnique({ where: { id } });
    if (!user) {
      return NextResponse.json({ error: "User not found." }, { status: 404 });
    }
    if (action === "approve") {
      let role = user.role;
      if (user.status === "PENDING_DOCTOR") role = "DOCTOR";
      else if (user.status === "PENDING_ADMIN") role = "ADMIN";
      const updated = await db.user.update({
        where: { id },
        data: { role, status: "ACTIVE" },
      });
      return NextResponse.json({
        user: updated,
        message: `Approved as ${role}.`,
      });
    }
    if (action === "reject") {
      await db.user.delete({ where: { id } });
      return NextResponse.json({ ok: true, message: "Request rejected." });
    }
    // generic role update
    if (body.role) {
      const updated = await db.user.update({
        where: { id },
        data: { role: String(body.role), status: "ACTIVE" },
      });
      return NextResponse.json({ user: updated, message: "User updated." });
    }
    return NextResponse.json({ error: "Unknown action." }, { status: 400 });
  } catch (e) {
    console.error("user update error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  await db.user.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
