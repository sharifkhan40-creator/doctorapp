import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  try {
    const body = await req.json();
    const { medicineName, dosage, times, startDate, endDate, notes, active } = body as Record<string, string>;
    const reminder = await db.medicineReminder.update({
      where: { id },
      data: {
        medicineName: medicineName || undefined,
        dosage: dosage || undefined,
        times: times || undefined,
        startDate: startDate || undefined,
        endDate: endDate !== undefined ? endDate || null : undefined,
        notes: notes !== undefined ? notes || null : undefined,
        active: active !== undefined ? active === "true" || active === true : undefined,
      },
    });
    return NextResponse.json({ reminder, message: "Reminder updated." });
  } catch (e) {
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  await db.medicineReminder.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
