import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

// GET /api/medicine-reminders — current user's reminders
export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const reminders = await db.medicineReminder.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ reminders });
}

// POST /api/medicine-reminders — create a new reminder
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  }
  try {
    const body = await req.json();
    const { medicineName, dosage, times, startDate, endDate, notes } = body as Record<string, string>;
    if (!medicineName || !dosage || !times || !startDate) {
      return NextResponse.json({ error: "Medicine name, dosage, times and start date are required." }, { status: 400 });
    }
    const reminder = await db.medicineReminder.create({
      data: {
        userId: user.id,
        medicineName,
        dosage,
        times,
        startDate,
        endDate: endDate || null,
        notes: notes || null,
      },
    });
    return NextResponse.json({ reminder, message: "Reminder added successfully." });
  } catch (e) {
    console.error("medicine reminder error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
