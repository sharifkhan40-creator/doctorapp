import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, getSessionUser } from "@/lib/auth";

// GET /api/doctor/profile — the signed-in doctor's own profile
export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const role =
    user.status === "PENDING_DOCTOR" ? "DOCTOR" : user.role;
  if (role !== "DOCTOR") {
    return NextResponse.json(
      { error: "Only doctor accounts can access a doctor profile." },
      { status: 403 },
    );
  }
  const profile = await db.doctorProfile.findUnique({
    where: { userId: user.id },
    include: { hospital: true },
  });
  return NextResponse.json({ profile, user });
}

// PUT /api/doctor/profile — create or update the signed-in doctor's profile
export async function PUT(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const role =
    user.status === "PENDING_DOCTOR" ? "DOCTOR" : user.role;
  if (role !== "DOCTOR") {
    return NextResponse.json(
      { error: "Only doctor accounts can edit a doctor profile." },
      { status: 403 },
    );
  }

  try {
    const body = await req.json();
    const {
      name, specialty, qualifications, experience, fee, phone, email,
      hospitalId, address, city, hours, mapLink, photo, bio, youtubeUrl, password,
    } = body as Record<string, string>;

    if (!name || !specialty || !qualifications || !phone || !address || !city || !hours) {
      return NextResponse.json(
        { error: "Please fill all required fields." },
        { status: 400 },
      );
    }

    const data = {
      name,
      specialty,
      qualifications,
      experience: experience !== undefined ? Number(experience) : undefined,
      fee: fee !== undefined ? Number(fee) : undefined,
      phone,
      email: email !== undefined ? email || null : undefined,
      hospitalId: hospitalId !== undefined ? hospitalId || null : undefined,
      address,
      city,
      hours,
      mapLink: mapLink !== undefined ? mapLink || null : undefined,
      photo: photo !== undefined ? photo || null : undefined,
      bio: bio !== undefined ? bio || null : undefined,
      youtubeUrl: youtubeUrl !== undefined ? youtubeUrl || null : undefined,
    };

    const existing = await db.doctorProfile.findUnique({
      where: { userId: user.id },
    });

    const profile = existing
      ? await db.doctorProfile.update({
          where: { userId: user.id },
          data,
          include: { hospital: true },
        })
      : await db.doctorProfile.create({
          data: { userId: user.id, ...data } as never,
          include: { hospital: true },
        });

    // Optional password change
    if (password && String(password).length >= 6) {
      const passwordHash = await hashPassword(String(password));
      await db.user.update({
        where: { id: user.id },
        data: { passwordHash },
      });
    }

    return NextResponse.json({
      profile,
      message: "Your doctor profile has been saved successfully.",
    });
  } catch (e) {
    console.error("doctor profile error", e);
    return NextResponse.json(
      { error: "Something went wrong." },
      { status: 500 },
    );
  }
}
