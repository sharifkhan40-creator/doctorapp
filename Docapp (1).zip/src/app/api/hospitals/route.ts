import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim();
  const city = searchParams.get("city")?.trim();

  const where: Record<string, unknown> = {};
  if (q) {
    where.OR = [
      { name: { contains: q } },
      { address: { contains: q } },
      { city: { contains: q } },
    ];
  }
  if (city) where.city = { contains: city };

  const hospitals = await db.hospital.findMany({
    where,
    orderBy: { name: "asc" },
    include: { _count: { select: { doctors: true } } },
  });
  return NextResponse.json({ hospitals });
}
