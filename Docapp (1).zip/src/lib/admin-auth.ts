import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";

// SUPER_ADMIN only — used for approving users, managing ambulances, articles,
// categories, slides.
export async function getSuperAdmin() {
  const user = await getSessionUser();
  if (!user) {
    return {
      denied: NextResponse.json(
        { error: "Unauthorized. Please sign in." },
        { status: 401 },
      ),
    };
  }
  // PENDING_ADMIN behaves as ADMIN, never as SUPER_ADMIN.
  if (user.role !== "SUPER_ADMIN") {
    return {
      denied: NextResponse.json(
        { error: "Forbidden. Super Admin access required." },
        { status: 403 },
      ),
    };
  }
  return { user, denied: null };
}

// ADMIN or SUPER_ADMIN — used for managing doctors and hospitals.
export async function requireAdmin() {
  const user = await getSessionUser();
  if (!user) {
    return {
      denied: NextResponse.json(
        { error: "Unauthorized. Please sign in." },
        { status: 401 },
      ),
    };
  }
  const role =
    user.status === "PENDING_ADMIN" ? "ADMIN" : user.role;
  if (role !== "ADMIN" && role !== "SUPER_ADMIN") {
    return {
      denied: NextResponse.json(
        { error: "Forbidden. Admin access required." },
        { status: 403 },
      ),
    };
  }
  return { user, denied: null };
}
