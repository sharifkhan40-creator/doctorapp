import { db } from "@/lib/db";
import { cookies } from "next/headers";
import { randomUUID, scrypt } from "crypto";

// ---- Password hashing (Node scrypt) ----
export async function hashPassword(password: string): Promise<string> {
  const salt = randomUUID().replace(/-/g, "");
  const saltBuf = Buffer.from(salt, "hex");
  const derived = await new Promise<Buffer>((resolve, reject) => {
    scrypt(password, saltBuf, 64, (err, key) => {
      if (err) reject(err);
      else resolve(key as Buffer);
    });
  });
  return `scrypt$${salt}$${derived.toString("hex")}`;
}

export async function verifyPassword(
  password: string,
  stored: string,
): Promise<boolean> {
  try {
    if (!stored || !stored.startsWith("scrypt$")) return false;
    const [, salt, hash] = stored.split("$");
    const saltBuf = Buffer.from(salt, "hex");
    const derived = await new Promise<Buffer>((resolve, reject) => {
      scrypt(password, saltBuf, 64, (err, key) => {
        if (err) reject(err);
        else resolve(key as Buffer);
      });
    });
    return derived.toString("hex") === hash;
  } catch {
    return false;
  }
}

// ---- Session (cookie-based, signed token) ----
const SESSION_COOKIE = "da_session";
const SESSION_TTL = 1000 * 60 * 60 * 24 * 7; // 7 days

function sign(value: string): string {
  const secret = process.env.SESSION_SECRET || "doctor-app-dev-secret";
  return Buffer.from(`${value}.${secret}`).toString("base64url");
}

function unsign(token: string): string | null {
  try {
    const decoded = Buffer.from(token, "base64url").toString("utf8");
    const idx = decoded.lastIndexOf(".");
    if (idx === -1) return null;
    return decoded.slice(0, idx);
  } catch {
    return null;
  }
}

export async function createSession(userId: string) {
  const user = await db.user.findUnique({ where: { id: userId } });
  const version = user?.sessionVersion ?? 0;
  // token payload: userId|version
  const token = sign(`${userId}|${version}`);
  const expires = new Date(Date.now() + SESSION_TTL);
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    expires,
  });
}

export async function clearSession() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

export async function getSessionUser() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const payload = unsign(token);
  if (!payload) return null;
  const [userId, versionStr] = payload.split("|");
  if (!userId) return null;
  const user = await db.user.findUnique({ where: { id: userId } });
  if (!user) return null;
  // Validate session version — if mismatched, the session was invalidated
  const tokenVersion = Number(versionStr);
  if (!Number.isNaN(tokenVersion) && user.sessionVersion !== tokenVersion) {
    return null;
  }
  return user;
}

// Increment sessionVersion → invalidates ALL existing sessions for the user.
// Used by "logout all sessions".
export async function invalidateAllSessions(userId: string) {
  await db.user.update({
    where: { id: userId },
    data: { sessionVersion: { increment: 1 } },
  });
}

export function sanitizeUser(user: {
  id: string;
  email: string;
  username: string;
  role: string;
  status: string;
  createdAt: Date;
  name?: string | null;
  phone?: string | null;
  address?: string | null;
  photo?: string | null;
  bloodGroup?: string | null;
}) {
  return {
    id: user.id,
    email: user.email,
    username: user.username,
    role: user.role,
    status: user.status,
    createdAt: user.createdAt,
    name: user.name || null,
    phone: user.phone || null,
    address: user.address || null,
    photo: user.photo || null,
    bloodGroup: user.bloodGroup || null,
  };
}
