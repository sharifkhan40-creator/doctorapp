import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-auth";

export async function GET() {
  const doctors = await db.doctorProfile.findMany({
    orderBy: { name: "asc" },
    include: { hospital: true, user: true },
  });
  return NextResponse.json({ doctors });
}

export async function POST(req: Request) {
  const { denied } = await requireAdmin();
  if (denied) return denied;
  try {
    const body = await req.json();
    const {
      name, specialty, qualifications, experience, fee, phone, email,
      hospitalId, address, city, hours, mapLink, photo, bio,
    } = body as Record<string, string>;
    if (!name || !specialty || !qualifications || !phone || !address || !city || !hours) {
      return NextResponse.json(
        { error: "Please fill all required fields." },
        { status: 400 },
      );
    }
    const doctor = await db.doctorProfile.create({
      data: {
        userId: "admin-created",
        name, specialty, qualifications,
        experience: Number(experience) || 0,
        fee: Number(fee) || 0,
        phone, email: email || null,
        hospitalId: hospitalId || null,
        address, city, hours,
        mapLink: mapLink || null,
        photo: photo || null,
        bio: bio || null,
      },
    });
    return NextResponse.json({ doctor, message: "Doctor added." });
  } catch (e) {
    console.error("doctor create error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
