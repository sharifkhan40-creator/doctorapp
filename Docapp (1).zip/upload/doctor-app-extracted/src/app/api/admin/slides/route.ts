import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-auth";

export async function GET() {
  const { denied } = await requireAdmin();
  if (denied) return denied;
  const slides = await db.slide.findMany({ orderBy: { order: "asc" } });
  return NextResponse.json({ slides });
}
