import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function GET() {
  const ambulances = await db.ambulance.findMany({ orderBy: { city: "asc" } });
  return NextResponse.json({ ambulances });
}

export async function POST(req: Request) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  try {
    const body = await req.json();
    const { name, phone, city, area, type, available, mapLink } = body as Record<
      string,
      string
    >;
    if (!name || !phone || !city) {
      return NextResponse.json(
        { error: "Name, phone and city are required." },
        { status: 400 },
      );
    }
    const ambulance = await db.ambulance.create({
      data: {
        name, phone, city,
        area: area || null,
        type: type || "Ambulance",
        available: available !== undefined ? available === "true" || available === true : true,
        mapLink: mapLink || null,
      },
    });
    return NextResponse.json({ ambulance, message: "Ambulance added." });
  } catch (e) {
    console.error("ambulance create error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
