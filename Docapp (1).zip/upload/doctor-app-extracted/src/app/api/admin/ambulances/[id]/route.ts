import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSuperAdmin } from "@/lib/admin-auth";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  try {
    const body = await req.json();
    const { name, phone, city, area, type, available, mapLink } = body as Record<
      string,
      string
    >;
    const ambulance = await db.ambulance.update({
      where: { id },
      data: {
        name: name || undefined,
        phone: phone || undefined,
        city: city || undefined,
        area: area !== undefined ? area || null : undefined,
        type: type || undefined,
        available: available !== undefined ? available === "true" || available === true : undefined,
        mapLink: mapLink !== undefined ? mapLink || null : undefined,
      },
    });
    return NextResponse.json({ ambulance, message: "Ambulance updated." });
  } catch (e) {
    console.error("ambulance update error", e);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { denied } = await getSuperAdmin();
  if (denied) return denied;
  const { id } = await params;
  await db.ambulance.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
