import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function scryptHash(password: string): Promise<string> {
  const { randomUUID, scrypt } = await import("crypto");
  const salt = randomUUID().replace(/-/g, "");
  const saltBuf = Buffer.from(salt, "hex");
  const derived: Buffer = await new Promise((resolve, reject) => {
    scrypt(password, saltBuf, 64, (err, key) => {
      if (err) reject(err);
      else resolve(key as Buffer);
    });
  });
  return `scrypt$${salt}$${derived.toString("hex")}`;
}

async function main() {
  console.log("Seeding database...");

  // ---- Super Admin ----
  const adminHash = await scryptHash("Sharif@123");
  let superAdmin = await db.user.findUnique({ where: { email: "contacttosharif@gmail.com" } });
  if (!superAdmin) {
    superAdmin = await db.user.create({
      data: {
        email: "contacttosharif@gmail.com",
        username: "sharif",
        passwordHash: adminHash,
        role: "SUPER_ADMIN",
        status: "ACTIVE",
      },
    });
  }
  const existingAdminProfile = await db.adminProfile.findUnique({ where: { userId: superAdmin.id } });
  if (!existingAdminProfile) {
    await db.adminProfile.create({
      data: {
        userId: superAdmin.id,
        name: "Super Admin",
        designation: "System Administrator",
        department: "Management",
        phone: "+8801710000000",
        email: "contacttosharif@gmail.com",
        bio: "Overall platform administrator.",
      },
    });
  }
  console.log("Super admin ready: contacttosharif@gmail.com / Sharif@123");

  // ---- Categories ----
  const categoryData = [
    { name: "Cardiologist", icon: "heart", bn: "হৃদরোগ বিশেষজ্ঞ" },
    { name: "Dermatologist", icon: "skin", bn: "চর্মরোগ বিশেষজ্ঞ" },
    { name: "Neurologist", icon: "brain", bn: "স্নায়ুরোগ বিশেষজ্ঞ" },
    { name: "Gynecologist", icon: "baby", bn: "গাইনি বিশেষজ্ঞ" },
    { name: "Pediatrician", icon: "child", bn: "শিশু বিশেষজ্ঞ" },
    { name: "General Physician", icon: "stethoscope", bn: "মেডিসিন বিশেষজ্ঞ" },
    { name: "Dentist", icon: "tooth", bn: "দন্ত চিকিৎসক" },
    { name: "Orthopedic", icon: "bone", bn: "হাড় বিশেষজ্ঞ" },
    { name: "ENT Specialist", icon: "ear", bn: "নাক-কান-গলা বিশেষজ্ঞ" },
    { name: "Eye Specialist", icon: "eye", bn: "চক্ষু বিশেষজ্ঞ" },
  ];
  const categories = [];
  for (const c of categoryData) {
    let cat = await db.category.findFirst({ where: { name: c.name } });
    if (!cat) cat = await db.category.create({ data: c });
    categories.push(cat);
  }

  // ---- Hospitals ----
  const hospitalData = [
    {
      name: "City Care Hospital",
      address: "123 Main Road, Gulshan",
      city: "Dhaka",
      phone: "+8802-555-0101",
      mapLink: "https://maps.google.com/?q=Gulshan+Dhaka",
      photo:
        "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800",
      web: "https://example.com",
    },
    {
      name: "Life Line Medical Center",
      address: "45 College Avenue, Motijheel",
      city: "Dhaka",
      phone: "+8802-555-0102",
      mapLink: "https://maps.google.com/?q=Motijheel+Dhaka",
      photo:
        "https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800",
    },
    {
      name: "Chattogram General Hospital",
      address: "78 Agrabad Road",
      city: "Chattogram",
      phone: "+88031-555-0201",
      mapLink: "https://maps.google.com/?q=Agrabad+Chattogram",
      photo:
        "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800",
    },
    {
      name: "Sylhet Health Hub",
      address: "Zindabazar, Sylhet",
      city: "Sylhet",
      phone: "+880821-555-0301",
      mapLink: "https://maps.google.com/?q=Zindabazar+Sylhet",
      photo:
        "https://images.unsplash.com/photo-1591801525298-4c6b6d6b6c6c?w=800",
    },
  ];
  const hospitals = [];
  for (const h of hospitalData) {
    let hosp = await db.hospital.findFirst({ where: { name: h.name } });
    if (!hosp) hosp = await db.hospital.create({ data: h });
    hospitals.push(hosp);
  }

  // ---- Doctors ----
  const doctorsData = [
    {
      name: "Dr. Ayesha Rahman",
      specialty: "Cardiologist",
      qualifications: "MBBS, FCPS (Cardiology)",
      experience: 12,
      fee: 800,
      phone: "+8801711000001",
      email: "ayesha@doctor.app",
      hospitalId: hospitals[0].id,
      address: "Room 204, City Care Hospital, Gulshan",
      city: "Dhaka",
      hours: "Sat-Thu, 10:00 AM - 4:00 PM",
      mapLink: "https://maps.google.com/?q=Gulshan+Dhaka",
      photo:
        "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=600",
      bio: "Senior cardiologist with 12+ years of experience treating heart conditions.",
    },
    {
      name: "Dr. Imran Hossain",
      specialty: "Neurologist",
      qualifications: "MBBS, MD (Neurology)",
      experience: 9,
      fee: 1000,
      phone: "+8801711000002",
      email: "imran@doctor.app",
      hospitalId: hospitals[0].id,
      address: "Room 110, City Care Hospital, Gulshan",
      city: "Dhaka",
      hours: "Sat-Wed, 9:00 AM - 3:00 PM",
      photo:
        "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=600",
      bio: "Neurology specialist focused on stroke and headache management.",
    },
    {
      name: "Dr. Nadia Karim",
      specialty: "Gynecologist",
      qualifications: "MBBS, FCPS (Gynae & Obs)",
      experience: 10,
      fee: 700,
      phone: "+8801711000003",
      email: "nadia@doctor.app",
      hospitalId: hospitals[1].id,
      address: "Life Line Medical Center, Motijheel",
      city: "Dhaka",
      hours: "Sun-Thu, 11:00 AM - 5:00 PM",
      photo:
        "https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=600",
      bio: "Caring gynecologist dedicated to women's health.",
    },
    {
      name: "Dr. Tanvir Ahmed",
      specialty: "Pediatrician",
      qualifications: "MBBS, DCH",
      experience: 7,
      fee: 500,
      phone: "+8801711000004",
      email: "tanvir@doctor.app",
      hospitalId: hospitals[1].id,
      address: "Life Line Medical Center, Motijheel",
      city: "Dhaka",
      hours: "Sat-Thu, 10:00 AM - 6:00 PM",
      photo:
        "https://images.unsplash.com/photo-1622253692010-333f2da6031b?w=600",
      bio: "Child specialist treating newborns and adolescents.",
    },
    {
      name: "Dr. Farzana Alam",
      specialty: "Dermatologist",
      qualifications: "MBBS, DDV",
      experience: 8,
      fee: 600,
      phone: "+8801711000005",
      email: "farzana@doctor.app",
      hospitalId: hospitals[2].id,
      address: "Chattogram General Hospital, Agrabad",
      city: "Chattogram",
      hours: "Sun-Thu, 9:00 AM - 2:00 PM",
      photo:
        "https://images.unsplash.com/photo-1638202993928-7267aad84c31?w=600",
      bio: "Dermatologist for skin, hair and nail disorders.",
    },
    {
      name: "Dr. Rafiq Islam",
      specialty: "General Physician",
      qualifications: "MBBS, BCS (Health)",
      experience: 15,
      fee: 400,
      phone: "+8801711000006",
      email: "rafiq@doctor.app",
      hospitalId: hospitals[3].id,
      address: "Sylhet Health Hub, Zindabazar",
      city: "Sylhet",
      hours: "Sat-Thu, 8:00 AM - 12:00 PM",
      photo:
        "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=600",
      bio: "Family physician with broad medical expertise.",
    },
    {
      name: "Dr. Sumaiya Akter",
      specialty: "Dentist",
      qualifications: "BDS, FCPS",
      experience: 6,
      fee: 500,
      phone: "+8801711000007",
      email: "sumaiya@doctor.app",
      hospitalId: hospitals[0].id,
      address: "Room 8, City Care Hospital, Gulshan",
      city: "Dhaka",
      hours: "Sat-Thu, 3:00 PM - 8:00 PM",
      photo:
        "https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?w=600",
      bio: "Dental surgeon offering cosmetic and restorative dentistry.",
    },
    {
      name: "Dr. Mehedi Hasan",
      specialty: "Orthopedic",
      qualifications: "MBBS, MS (Ortho)",
      experience: 11,
      fee: 900,
      phone: "+8801711000008",
      email: "mehedi@doctor.app",
      hospitalId: hospitals[2].id,
      address: "Chattogram General Hospital, Agrabad",
      city: "Chattogram",
      hours: "Sun-Thu, 10:00 AM - 4:00 PM",
      photo:
        "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=600",
      bio: "Orthopedic surgeon treating fractures and joint issues.",
    },
  ];

  for (const d of doctorsData) {
    const existing = await db.doctorProfile.findFirst({ where: { name: d.name } });
    if (existing) continue;
    // Create a real user account for each seeded doctor
    const email = d.email || `${d.name.toLowerCase().replace(/[^a-z]/g, "")}@doctor.app`;
    let dUser = await db.user.findUnique({ where: { email } });
    if (!dUser) {
      dUser = await db.user.create({
        data: {
          email,
          username: d.name.toLowerCase().replace(/[^a-z]/g, ""),
          passwordHash: await scryptHash("doctor123"),
          role: "DOCTOR",
          status: "ACTIVE",
        },
      });
    }
    await db.doctorProfile.create({
      data: { userId: dUser.id, ...d } as never,
    });
  }

  // ---- Ambulances ----
  const ambulances = [
    { name: "City Ambulance Service", phone: "+8801712000001", city: "Dhaka", area: "Gulshan", type: "ICU Ambulance", available: true, mapLink: "https://maps.google.com/?q=Gulshan" },
    { name: "Quick Rescue", phone: "+8801712000002", city: "Dhaka", area: "Motijheel", type: "Ambulance", available: true, mapLink: "https://maps.google.com/?q=Motijheel" },
    { name: "Port Care Ambulance", phone: "+8801712000003", city: "Chattogram", area: "Agrabad", type: "Freezer Ambulance", available: true, mapLink: "https://maps.google.com/?q=Agrabad" },
    { name: "Sylhet Emergency", phone: "+8801712000004", city: "Sylhet", area: "Zindabazar", type: "ICU Ambulance", available: true, mapLink: "https://maps.google.com/?q=Zindabazar" },
    { name: "Life Line Transport", phone: "+8801712000005", city: "Dhaka", area: "Uttara", type: "Ambulance", available: false, mapLink: "https://maps.google.com/?q=Uttara" },
  ];
  for (const a of ambulances) {
    const existing = await db.ambulance.findFirst({ where: { name: a.name } });
    if (!existing) await db.ambulance.create({ data: a });
  }

  // ---- Articles ----
  const articles = [
    {
      title: "10 Habits for a Healthy Heart",
      excerpt: "Simple lifestyle changes that keep your heart strong and reduce the risk of cardiac disease.",
      content:
        "Heart disease is one of the leading causes of death worldwide, but many cases are preventable. Here are ten habits that can keep your heart healthy:\n\n1. Eat a balanced diet rich in vegetables, fruits, whole grains and lean protein.\n2. Exercise for at least 30 minutes most days of the week.\n3. Avoid smoking and secondhand smoke.\n4. Limit alcohol consumption.\n5. Manage stress through meditation or hobbies.\n6. Get 7-8 hours of quality sleep.\n7. Monitor your blood pressure regularly.\n8. Keep cholesterol and blood sugar in check.\n9. Maintain a healthy weight.\n10. Visit your cardiologist for regular check-ups.\n\nSmall, consistent changes add up over time. Start today and your heart will thank you.",
      category: "Cardiology",
      author: "Dr. Ayesha Rahman",
      readTime: 5,
      coverImage: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800",
    },
    {
      title: "Understanding Childhood Vaccination",
      excerpt: "A guide for parents on the essential vaccines every child needs in their first years.",
      content:
        "Vaccination is one of the most effective ways to protect children from serious diseases. Follow the recommended schedule:\n\n- BCG and first polio dose at birth.\n- Pentavalent, OPV, PCV and rotavirus vaccines at 6, 10 and 14 weeks.\n- Measles vaccine at 9 months.\n\nAlways keep your child's vaccine card updated and consult your pediatrician if you miss a dose. Mild fever after vaccination is normal, but report any severe reactions immediately.",
      category: "Pediatrics",
      author: "Dr. Tanvir Ahmed",
      readTime: 4,
      coverImage: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800",
    },
    {
      title: "Skin Care Tips for Every Season",
      excerpt: "How to adjust your skincare routine as the weather changes throughout the year.",
      content:
        "Your skin's needs change with the seasons. In winter, use a thicker moisturizer and avoid hot showers. In summer, never skip sunscreen with SPF 30 or higher. Stay hydrated year-round and cleanse gently twice a day. If you have a persistent skin issue, see a dermatologist rather than self-treating.",
      category: "Dermatology",
      author: "Dr. Farzana Alam",
      readTime: 3,
      coverImage: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800",
    },
    {
      title: "When to See a Neurologist",
      excerpt: "Frequent headaches, numbness or dizziness could be signs you need a specialist.",
      content:
        "Occasional headaches are common, but certain symptoms warrant a visit to a neurologist: severe or worsening headaches, numbness or weakness in limbs, sudden dizziness, vision changes, or memory problems. Early evaluation can prevent serious complications. Never ignore neurological symptoms that persist or interfere with daily life.",
      category: "Neurology",
      author: "Dr. Imran Hossain",
      readTime: 4,
      coverImage: "https://images.unsplash.com/photo-1559757175-5700dde675bc?w=800",
    },
  ];
  for (const a of articles) {
    const existing = await db.article.findFirst({ where: { title: a.title } });
    if (!existing) await db.article.create({ data: a });
  }

  // ---- Slides ----
  const slides = [
    { title: "Find Trusted Doctors Near You", subtitle: "Book appointments with verified specialists across Bangladesh.", image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=1200", btnText: "Find a Doctor", btnLink: "#/doctors", order: 0 },
    { title: "24/7 Ambulance Service", subtitle: "Emergency transport available in your city anytime.", image: "https://images.unsplash.com/photo-1583912267550-d44c9c2b4c8c?w=1200", btnText: "Call Ambulance", btnLink: "#/ambulances", order: 1 },
    { title: "Health Tips & Articles", subtitle: "Stay informed with expert health advice from our doctors.", image: "https://images.unsplash.com/photo-1505751171710-1f6d0ace5a85?w=1200", btnText: "Read Articles", btnLink: "#/articles", order: 2 },
  ];
  for (const s of slides) {
    const existing = await db.slide.findFirst({ where: { title: s.title } });
    if (!existing) await db.slide.create({ data: s });
  }

  console.log("Seed complete.");
  console.log("Categories:", categories.length);
  console.log("Hospitals:", hospitals.length);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
