/* ===================================================================
   Doctor App — vanilla JS SPA (mobile-first)
   =================================================================== */
"use strict";

/* ---------- State ---------- */
const state = { user:null, needsApproval:false, profile:null, meLoaded:false, lang:"en", theme:"light", notifs:[], deferredPrompt:null, favs:[], installed:false };

/* ---------- i18n (English / Bangla) ---------- */
const I18N = {
  en:{
    home:"Home", blood:"Blood", drAi:"Dr. AI", category:"Category", profile:"Profile",
    welcome:"Welcome back", welcomeSub:"Sign in to your Doctor App account",
    createAccount:"Create account", createSub:"Join Doctor App to manage your health",
    emailOrUser:"Email or username", password:"Password", signIn:"Sign in", signUp:"Sign up",
    forgotPw:"Forgot password?", noAccount:"Don't have an account?", haveAccount:"Already have an account?",
    registerAs:"Register as", patient:"Patient (User)", doctor:"Doctor (needs approval)", admin:"Admin (needs approval)",
    hospital:"Hospital", selectHospital:"Select hospital…", hospitalHint:"Required for doctor registration — hospitals are added by admins",
    createBtn:"Create account", searchPh:"Search doctor, hospital or speciality",
    all:"All", browseCat:"Browse categories", topDoctors:"Top", doctors:"doctors",
    topHospitals:"Top hospitals", emergency:"Emergency ambulance", healthArt:"Health articles",
    seeAll:"See all →", allCities:"All cities", nearMe:"Near me",
    call:"Call", map:"Map", profileBtn:"Profile", directions:"Directions",
    guest:"Guest", loginRegister:"Login / Register", findDoctors:"Find Doctors",
    hospitals:"Hospitals", ambulance:"Ambulance", healthArticles:"Health Articles",
    favorites:"Favorites", sendFeedback:"Send Feedback", privacyPolicy:"Privacy Policy",
    termsOfUse:"Terms of Use", followUs:"Follow us", version:"Version 1.1.3",
    logout:"Logout", myDoctorProfile:"My Doctor Profile", adminDashboard:"Admin Dashboard",
    myAccount:"My Account", notifications:"Notifications", markAllRead:"Mark all read",
    noNotifs:"No notifications yet", update:"Update",
    findDoctor:"Find a Doctor", verifiedSpec:"verified specialists near you", available:"available",
    bloodDonors:"Blood Donors", registeredDonors:"registered donors available",
    allBloodGroups:"All blood groups", ambulanceServices:"Ambulance Services",
    ambulanceProviders:"ambulance providers. Tap to call instantly",
    allCategories:"All Categories", browseBySpecialty:"Browse doctors by specialty",
    healthArticlesTitle:"Health Articles", expertTips:"Expert health tips and advice",
    installApp:"Install App", installDoctorApp:"Install Doctor App",
    addToHome:"Add to your home screen for quick access",
    myProfile:"My Profile", saveProfile:"Save Profile", profileInfo:"Profile Information",
    fullName:"Full Name", phoneNumber:"Phone Number", address:"Address", bloodGroup:"Blood Group",
    bloodDonation:"Blood Donation", account:"Account", logoutAll:"Logout All Sessions",
    joined:"Joined", username:"Username", role:"Role", email:"Email", status:"Status",
    backHome:"← Home", backDoctors:"← Back to doctors", backArticles:"← Back to articles",
    openInMaps:"Open in Google Maps ↗", locationOnMap:"Location on Map",
    bangladeshMap:"Bangladesh Coverage Map", chamberContact:"Chamber & Contact",
    qualifications:"Qualifications", chamberHours:"Chamber Hours", consultationFee:"Consultation Fee",
    videoIntro:"Video Introduction", about:"About",
    medTracker:"💊 Medicine Tracker", medTrackerSub:"Track your medicines and get reminder notifications",
    addMedReminder:"➕ Add Medicine Reminder", noReminders:"No reminders yet",
    noRemindersSub:"Add your first medicine reminder to get started!",
    medActive:"Active", medPaused:"Paused", medOngoing:"ongoing", medTo:"To",
    medMarkTaken:"Mark as Taken", medTaken:"Taken", medAllTakenToday:"✅ All doses taken today",
    medNextDoseIn:"Next dose in", medDoseDueNow:"Dose due now", medDaysActive:"Days Active",
    medNextIn:"Next in", medDoneForToday:"✅ Done for today", medAllDosesTaken:"All doses taken",
    medEdit:"Edit", medPause:"Pause", medResume:"Resume", medDelete:"Delete",
    medDetails:"📋 Medicine Details", medDetailsSub:"Complete information about your medicine reminder",
    medInfo:"💊 Medicine Information", medMedName:"Medicine Name", medDosage:"Dosage",
    medStatus:"Status", medNotes:"Notes", medSchedule:"⏰ Reminder Schedule",
    medReminderTimes:"Reminder Times", medFrequency:"Frequency", medDailyDoses:"Total Daily Doses",
    medDuration:"📅 Treatment Duration", medStartDate:"Start Date", medEndDate:"End Date",
    medNoEnd:"Ongoing (no end date)", medAddedOn:"Added On", medEditDetails:"Edit Details",
    medDeleteReminder:"Delete This Reminder", medBackTracker:"← Back to Medicine Tracker",
    medNotFound:"Medicine not found", medNotFoundSub:"This reminder may have been deleted.",
    medGoTracker:"Go to Medicine Tracker", timePerDay:"time(s) per day", dosePlural:"dose(s)",
    ratingReviews:"⭐ Rating & Reviews", doctorsAtHosp:"Doctors at this hospital",
    ambCallNow:"📞 Call Now", ambAvailable:"Available", ambOffDuty:"Off duty",
    ambType:"Type", ambLocation:"Location", ambNoRating:"Not rated",
  },
  bn:{
    home:"হোম", blood:"রক্ত", drAi:"ডাক্তার AI", category:"ক্যাটাগরি", profile:"প্রোফাইল",
    welcome:"ফিরে আসায় স্বাগতম", welcomeSub:"আপনার ডাক্তার অ্যাপ অ্যাকাউন্টে সাইন ইন করুন",
    createAccount:"অ্যাকাউন্ট তৈরি করুন", createSub:"স্বাস্থ্য ব্যবস্থাপনার জন্য যোগ দিন",
    emailOrUser:"ইমেইল বা ইউজারনেম", password:"পাসওয়ার্ড", signIn:"সাইন ইন", signUp:"সাইন আপ",
    forgotPw:"পাসওয়ার্ড ভুলে গেছেন?", noAccount:"অ্যাকাউন্ট নেই?", haveAccount:"ইতিমধ্যে অ্যাকাউন্ট আছে?",
    registerAs:"হিসেবে নিবন্ধন", patient:"রোগী (ইউজার)", doctor:"ডাক্তার (অনুমোদন প্রয়োজন)", admin:"অ্যাডমিন (অনুমোদন প্রয়োজন)",
    hospital:"হাসপাতাল", selectHospital:"হাসপাতাল নির্বাচন করুন…", hospitalHint:"ডাক্তার নিবন্ধনের জন্য প্রয়োজন",
    createBtn:"অ্যাকাউন্ট তৈরি করুন", searchPh:"ডাক্তার, হাসপাতাল বা বিশেষত্ব খুঁজুন",
    all:"সব", browseCat:"ক্যাটাগরি ব্রাউজ করুন", topDoctors:"শীর্ষ", doctors:"জন ডাক্তার",
    topHospitals:"শীর্ষ হাসপাতাল", emergency:"ইমার্জেন্সি অ্যাম্বুলেন্স", healthArt:"স্বাস্থ্য আর্টিকেল",
    seeAll:"সব দেখুন →", allCities:"সব শহর", nearMe:"আমার কাছে",
    call:"কল", map:"মানচিত্র", profileBtn:"প্রোফাইল", directions:"দিকনির্দেশ",
    guest:"অতিথি", loginRegister:"লগইন / নিবন্ধন", findDoctors:"ডাক্তার খুঁজুন",
    hospitals:"হাসপাতাল", ambulance:"অ্যাম্বুলেন্স", healthArticles:"স্বাস্থ্য আর্টিকেল",
    favorites:"পছন্দ", sendFeedback:"মতামত পাঠান", privacyPolicy:"গোপনীয়তা নীতি",
    termsOfUse:"ব্যবহারের শর্ত", followUs:"ফলো করুন", version:"ভার্সন 1.1.3",
    logout:"লগআউট", myDoctorProfile:"আমার ডাক্তার প্রোফাইল", adminDashboard:"অ্যাডমিন ড্যাশবোর্ড",
    myAccount:"আমার অ্যাকাউন্ট", notifications:"নোটিফিকেশন", markAllRead:"সব পড়া হিসেবে চিহ্নিত করুন",
    noNotifs:"কোনো নোটিফিকেশন নেই", update:"আপডেট",
    findDoctor:"একজন ডাক্তার খুঁজুন", verifiedSpec:"আপনার কাছে যাচাইকৃত বিশেষজ্ঞ", available:"উপলব্ধ",
    bloodDonors:"রক্তদাতা", registeredDonors:"নিবন্ধিত রক্তদাতা উপলব্ধ",
    allBloodGroups:"সব রক্তের গ্রুপ", ambulanceServices:"অ্যাম্বুলেন্স সেবা",
    ambulanceProviders:"জন অ্যাম্বুলেন্স প্রদানকারী। সরাসরি কল করতে ট্যাপ করুন",
    allCategories:"সব ক্যাটাগরি", browseBySpecialty:"বিশেষত্ব অনুযায়ী ডাক্তার ব্রাউজ করুন",
    healthArticlesTitle:"স্বাস্থ্য আর্টিকেল", expertTips:"বিশেষজ্ঞের স্বাস্থ্য টিপস ও পরামর্শ",
    installApp:"অ্যাপ ইনস্টল করুন", installDoctorApp:"ডাক্তার অ্যাপ ইনস্টল করুন",
    addToHome:"দ্রুত অ্যাক্সেসের জন্য হোম স্ক্রিনে যোগ করুন",
    myProfile:"আমার প্রোফাইল", saveProfile:"প্রোফাইল সংরক্ষণ করুন", profileInfo:"প্রোফাইল তথ্য",
    fullName:"পূর্ণ নাম", phoneNumber:"ফোন নম্বর", address:"ঠিকানা", bloodGroup:"রক্তের গ্রুপ",
    bloodDonation:"রক্তদান", account:"অ্যাকাউন্ট", logoutAll:"সব সেশন থেকে লগআউট",
    joined:"যোগ দিয়েছেন", username:"ইউজারনেম", role:"ভূমিকা", email:"ইমেইল", status:"স্ট্যাটাস",
    backHome:"← হোম", backDoctors:"← ডাক্তারদের তালিকায়", backArticles:"← আর্টিকেলে ফিরে যান",
    openInMaps:"গুগল ম্যাপে খুলুন ↗", locationOnMap:"মানচিত্রে অবস্থান",
    bangladeshMap:"বাংলাদেশ কভারেজ ম্যাপ", chamberContact:"চেম্বার ও যোগাযোগ",
    qualifications:"যোগ্যতা", chamberHours:"চেম্বার সময়", consultationFee:"কনসালটেশন ফি",
    videoIntro:"ভিডিও পরিচিতি", about:"পরিচিতি",
    medTracker:"💊 ওষুধ ট্র্যাকার", medTrackerSub:"আপনার ওষুধ ট্র্যাক করুন এবং রিমাইন্ডার নোটিফিকেশন পান",
    addMedReminder:"➕ ওষুধ রিমাইন্ডার যোগ করুন", noReminders:"এখনো কোনো রিমাইন্ডার নেই",
    noRemindersSub:"শুরু করতে আপনার প্রথম ওষুধ রিমাইন্ডার যোগ করুন!",
    medActive:"সক্রিয়", medPaused:"বিরতিতে", medOngoing:"চলমান", medTo:"থেকে",
    medMarkTaken:"নেওয়া হয়েছে", medTaken:"নেওয়া হয়েছে", medAllTakenToday:"✅ আজ সব ডোজ নেওয়া হয়েছে",
    medNextDoseIn:"পরবর্তী ডোজের সময়", medDoseDueNow:"ডোজ এখনই নিন", medDaysActive:"দিন অতিবাহিত",
    medNextIn:"পরবর্তী", medDoneForToday:"✅ আজকের জন্য সম্পন্ন", medAllDosesTaken:"সব ডোজ নেওয়া হয়েছে",
    medEdit:"সম্পাদনা", medPause:"বিরতি", medResume:"পুনরায় শুরু", medDelete:"মুছুন",
    medDetails:"📋 ওষুধের বিস্তারিত", medDetailsSub:"আপনার ওষুধ রিমাইন্ডার সম্পর্কে সম্পূর্ণ তথ্য",
    medInfo:"💊 ওষুধের তথ্য", medMedName:"ওষুধের নাম", medDosage:"মাত্রা",
    medStatus:"অবস্থা", medNotes:"নোট", medSchedule:"⏰ রিমাইন্ডার সূচি",
    medReminderTimes:"রিমাইন্ডার সময়", medFrequency:"ফ্রিকোয়েন্সি", medDailyDoses:"মোট দৈনিক ডোজ",
    medDuration:"📅 চিকিৎসার মেয়াদ", medStartDate:"শুরুর তারিখ", medEndDate:"শেষ তারিখ",
    medNoEnd:"চলমান (কোনো শেষ তারিখ নেই)", medAddedOn:"যোগ করা হয়েছে", medEditDetails:"বিস্তারিত সম্পাদনা",
    medDeleteReminder:"এই রিমাইন্ডার মুছুন", medBackTracker:"← ওষুধ ট্র্যাকারে ফিরে যান",
    medNotFound:"ওষুধ পাওয়া যায়নি", medNotFoundSub:"এই রিমাইন্ডার মুছে ফেলা হয়ে থাকতে পারে।",
    medGoTracker:"ওষুধ ট্র্যাকারে যান", timePerDay:"বার প্রতিদিন", dosePlural:"ডোজ",
    ratingReviews:"⭐ রেটিং ও পর্যালোচনা", doctorsAtHosp:"এই হাসপাতালের ডাক্তারগণ",
    ambCallNow:"📞 এখনই কল করুন", ambAvailable:"উপলব্ধ", ambOffDuty:"অফ ডিউটি",
    ambType:"ধরন", ambLocation:"অবস্থান", ambNoRating:"এখনো রেটিং নেই",
  }
};
function t(key){ const v=(I18N[state.lang]||I18N.en)[key]; return v||key; }

/* ---------- Helpers ---------- */
const $ = (s,r=document)=>r.querySelector(s);
const $$ = (s,r=document)=>Array.from(r.querySelectorAll(s));
const esc = (s)=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const initials = (name)=>{const p=String(name||"").trim().split(/\s+/);return ((p[0]||"")[0]||"")+((p[1]||p[p.length-1]||"")[0]||"")};
const fmtDate = (d)=>{try{return new Date(d).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"});}catch{return"";}};
/* Format "HH:MM" → "8:00 am" / "8:00 pm" (12-hour with lowercase am/pm) */
const fmtTime12 = (t)=>{
  if(!t||!/^\d{1,2}:\d{2}$/.test(t))return t||"";
  const [h,m]=t.split(":").map(Number); const ap=h<12?"am":"pm";
  let hr=h%12; if(hr===0)hr=12;
  return hr+":"+String(m).padStart(2,"0")+" "+ap;
};
/* Format an array of "HH:MM" → "8:00 am - 8:00 pm" (range using en dash) */
const fmtTimeRange = (times)=>{
  if(!Array.isArray(times)||times.length===0)return "";
  const sorted=[...times].sort();
  if(sorted.length===1)return fmtTime12(sorted[0]);
  return fmtTime12(sorted[0])+" - "+fmtTime12(sorted[sorted.length-1]);
};
/* Format a date range like "10 Oct 2026 To 30 Oct 2026" or "10 Oct 2026 (ongoing)" */
const fmtDateRange = (start,end,ongoingLbl)=>{
  const s=fmtDate(start);
  if(!end)return s+" ("+ongoingLbl+")";
  return s+" "+(I18N[state.lang]||I18N.en).medTo+" "+fmtDate(end);
};
/* Medicine "Mark as taken" tracking — per reminder/day/time, stored in localStorage */
const medTakenKey=(id,date,time)=>"med_taken_"+id+"_"+date+"_"+time;
const isMedTaken=(id,date,time)=>{try{return !!localStorage.getItem(medTakenKey(id,date,time));}catch{return false;}};
const markMedTaken=(id,date,time)=>{try{localStorage.setItem(medTakenKey(id,date,time),"1");}catch(e){}};
const unmarkMedTaken=(id,date,time)=>{try{localStorage.removeItem(medTakenKey(id,date,time));}catch(e){}};
/* Compute the next untaken dose for a reminder today (returns {time, msUntil} or null).
   Prioritises overdue (past & untaken) doses first, so "Mark as Taken" marks the
   missed dose, and the countdown shows "Dose due now" until it's taken. */
function nextDoseInfo(r){
  const times=JSON.parse(r.times||"[]");
  if(!times.length)return null;
  const now=new Date();
  const today=now.toISOString().slice(0,10);
  const sorted=[...times].sort();
  const currentTime=String(now.getHours()).padStart(2,"0")+":"+String(now.getMinutes()).padStart(2,"0");
  // 1) first overdue (past, untaken) dose → due now
  for(const t of sorted){
    if(isMedTaken(r.id,today,t))continue;
    if(t<currentTime){
      return {time:t, msUntil:0, taken:false, overdue:true};
    }
  }
  // 2) first upcoming untaken dose today (due now or in the future)
  for(const t of sorted){
    if(isMedTaken(r.id,today,t))continue;
    if(t>=currentTime){
      const [h,m]=t.split(":").map(Number);
      const target=new Date(now); target.setHours(h,m,0,0);
      return {time:t, msUntil:target-now, taken:false};
    }
  }
  // 3) all taken today → next is tomorrow's first dose
  const [h,m]=sorted[0].split(":").map(Number);
  const target=new Date(now); target.setDate(target.getDate()+1); target.setHours(h,m,0,0);
  return {time:sorted[0], msUntil:target-now, taken:true, allTakenToday:true};
}
/* Format a millisecond duration → "2h 15m" / "45m" / "10s" (live countdown) */
function fmtCountdown(ms){
  if(ms<=0)return "0m";
  const s=Math.floor(ms/1000);
  const d=Math.floor(s/86400);
  const h=Math.floor((s%86400)/3600);
  const m=Math.floor((s%3600)/60);
  const sec=s%60;
  if(d>0)return d+"d "+h+"h";
  if(h>0)return h+"h "+m+"m";
  if(m>0)return m+"m "+sec+"s";
  return sec+"s";
}

function toast(msg,type="info"){
  const w=$("#toastWrap"); const t=document.createElement("div");
  t.className="toast "+(type==="success"?"success":type==="error"?"error":type==="warn"?"warn":"");
  const ico=type==="success"?"✓":type==="error"?"✕":type==="warn"?"!":"i";
  t.innerHTML=`<span class="t-ico">${ico}</span><span>${esc(msg)}</span>`;
  w.appendChild(t);
  setTimeout(()=>{t.style.opacity="0";t.style.transition=".25s";setTimeout(()=>t.remove(),260);},3000);
}

async function api(path,opts={},retries=4){
  var method=opts.method||"GET";
  // For GET requests, try to use cached data from localStorage as fallback
  var cacheKey="api_cache_"+path;
  for(let attempt=0;attempt<=retries;attempt++){
    try{
      const res=await fetch(path,{headers:{"Content-Type":"application/json",...(opts.headers||{})},credentials:"same-origin",...opts,body:opts.body?JSON.stringify(opts.body):undefined});
      const data=await res.json().catch(()=>({}));
      if(!res.ok) return {error:data.error||"Request failed",status:res.status};
      // Cache successful GET responses
      if(method==="GET"&&data){
        try{localStorage.setItem(cacheKey,JSON.stringify({data:data,ts:Date.now()}));}catch(e){}
      }
      return {data,status:res.status};
    }catch(e){
      if(attempt<retries){ await new Promise(r=>setTimeout(r,500*(attempt+1))); continue; }
      // All retries failed - try cached data for GET requests
      if(method==="GET"){
        try{
          var cached=localStorage.getItem(cacheKey);
          if(cached){
            var parsed=JSON.parse(cached);
            if(parsed.data) return {data:parsed.data,status:200,cached:true};
          }
        }catch(e){}
      }
      return {error:"Network error. Please check your connection."};
    }
  }
}

function navigate(hash){ location.hash=hash; }
function qs(name){
  const h=location.hash.replace(/^#\/?/,""); const qi=h.indexOf("?");
  if(qi<0) return null;
  try{return new URLSearchParams(h.slice(qi+1).split("#")[0]).get(name);}catch{return null;}
}
function pathParts(){return location.hash.replace(/^#\/?/,"").split("?")[0].split("/").filter(Boolean);}

const CAT_ICONS={Cardiologist:"❤️",Dermatologist:"🧴",Neurologist:"🧠",Gynecologist:"🤱",Pediatrician:"🧒","General Physician":"🩺",Dentist:"🦷",Orthopedic:"🦴","ENT Specialist":"👂","Eye Specialist":"👁️",default:"🩺"};
function catIcon(name){return CAT_ICONS[name]||CAT_ICONS.default;}

/* ---------- Auth ---------- */
async function loadMe(){
  const {data,error}=await api("/api/auth/me");
  if(error){state.user=null;state.meLoaded=true;return;}
  state.user=data.user; state.needsApproval=data.needsApproval; state.profile=data.profile||null; state.meLoaded=true;
}
async function logout(){await api("/api/auth/logout",{method:"POST"});state.user=null;state.profile=null;state.needsApproval=false;toast("Logged out","success");navigate("/");render();}
async function logoutAll(){
  if(!confirm("This will log you out from ALL devices. You'll need to sign in again on each one. Continue?")) return;
  await api("/api/auth/logout-all",{method:"POST"});
  state.user=null;state.profile=null;state.needsApproval=false;
  toast("Logged out from all sessions","success");
  navigate("/");render();
}
window.logoutAll=logoutAll;
function isSuperAdmin(){return state.user&&state.user.role==="SUPER_ADMIN";}
function isAdmin(){return state.user&&(state.user.role==="ADMIN"||state.user.role==="SUPER_ADMIN");}
function isDoctor(){return state.user&&state.user.role==="DOCTOR";}

/* ===================================================================
   LAYOUT shell
   =================================================================== */
function header(){
  const u=state.user;
  const unreadCount = state.notifs.filter(n=>!n.read).length;
  return `
  <header class="app-header">
    <div class="header-row">
      <button class="hamburger" onclick="openDrawer()" aria-label="Menu"><span></span></button>
      <a class="brand" href="#/"><span class="logo"><img src="/icon-192.png" alt="Doctor App" style="width:100%;height:100%;object-fit:cover;border-radius:9px"/></span><span class="brand-info"><span class="brand-name">Doctor App</span><span class="brand-slogan">Find Your Nearest Doctor</span></span></a>
      <div class="header-btns">
        <button class="hbtn" onclick="toggleLang()" aria-label="Language">${state.lang==="en"?"বাং":"EN"}</button>
        <button class="hbtn" onclick="toggleTheme()" aria-label="Dark mode">${state.theme==="dark"?"☀️":"🌙"}</button>
        <button class="hbtn" onclick="openNotif()" aria-label="Notifications">🔔${unreadCount?`<span class="dot"></span>`:""}</button>
      </div>
    </div>
  </header>`;
}

function drawerHtml(){
  const u=state.user;
  // Blue line-style SVG icons (matches reference: outlined, stroke=primary-2)
  const I = {
    home:'<svg viewBox="0 0 24 24"><path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1V9.5z"/></svg>',
    install:'<svg viewBox="0 0 24 24"><path d="M12 3v12m0 0l-4-4m4 4l4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>',
    fav:'<svg viewBox="0 0 24 24"><path d="M12 21s-7-4.5-9.5-9C1 8.5 3 5 6.5 5c2 0 3.5 1.5 5.5 4 2-2.5 3.5-4 5.5-4C21 5 23 8.5 21.5 12c-2.5 4.5-9.5 9-9.5 9z"/></svg>',
    about:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.5v.5"/></svg>',
    contact:'<svg viewBox="0 0 24 24"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg>',
    feedback:'<svg viewBox="0 0 24 24"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>',
    privacy:'<svg viewBox="0 0 24 24"><path d="M12 2l8 3v7c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V5l8-3z"/><path d="M9 12l2 2 4-4"/></svg>',
    terms:'<svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></svg>',
    profile:'<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>',
    dashboard:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
    logout:'<svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>',
  };
  const items=[
    {href:"#/ ",label:"Home",svg:I.home},
    {href:"#/doctors",label:"Find Doctors",svg:I.dashboard},
    {href:"#/hospitals",label:"Hospitals",svg:I.about},
    {href:"#/blood-donors",label:"Blood Donors",svg:'<svg viewBox="0 0 24 24"><path d="M12 2s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/></svg>'},
    {href:"#/ambulances",label:"Ambulance",svg:I.contact},
    {href:"#/articles",label:"Health Articles",svg:I.terms},
  ];
  const extraItems=[
    {label:"Install App",svg:I.install,act:"installApp()"},
    {label:"Favorites",svg:I.fav,act:"showFavorites()"},
    {label:"Send Feedback",svg:I.feedback,act:"window.open('https://forms.gle/PZVA778gmxUZtt6S7','_blank')"},
    {label:"Privacy Policy",svg:I.privacy,act:"closeDrawer();navigate('/privacy')"},
    {label:"Terms of Use",svg:I.terms,act:"closeDrawer();navigate('/terms')"},
  ];
  const userItems = isDoctor() ? [{href:"#/doctor-profile",label:"My Doctor Profile",svg:I.profile}]
    : isAdmin() ? [{href:"#/admin",label:"Admin Dashboard",svg:I.dashboard}]
    : state.user ? [{href:"#/account",label:"My Account",svg:I.profile}] : [];
  const p = pathParts()[0]||"";
  return `
    <div class="drawer-head">
      <div class="drawer-avatar">
        ${u ? `<svg viewBox="0 0 24 24" style="width:26px;height:26px;stroke:var(--primary-2);stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>` : `<svg viewBox="0 0 24 24" style="width:26px;height:26px;stroke:var(--primary-2);stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>`}
      </div>
      <div class="drawer-head-info">
        <div class="uname">${u?esc(u.username):"Guest"}</div>
        ${u
          ? `<div style="font-size:12px;color:var(--muted);margin-bottom:2px">${esc(u.email)}</div>
             <span class="badge badge-primary">${esc(u.role)}</span>`
          : `<a href="#/login" class="drawer-login-btn" onclick="closeDrawer()">Login / Register</a>`}
      </div>
      <button class="drawer-close" onclick="closeDrawer()" aria-label="Close">×</button>
    </div>
    <nav class="drawer-nav">
      ${items.map(i=>{
        const isA = (i.href==="#/ "&&p==="")||("#/"+p)===i.href;
        return `<a href="${i.href}" class="${isA?"active":""}" onclick="closeDrawer()"><span class="dico">${i.svg}</span>${i.label}</a>`;
      }).join("")}
      ${userItems.length?`<div class="drawer-sep"></div>${userItems.map(i=>`<a href="${i.href}" onclick="closeDrawer()"><span class="dico">${i.svg}</span>${i.label}</a>`).join("")}`:""}
      <div class="drawer-sep"></div>
      ${extraItems.map(i=>`<button class="ditem" onclick="closeDrawer();${i.act}"><span class="dico">${i.svg}</span>${i.label}</button>`).join("")}
      ${u?`<div class="drawer-sep"></div><button class="ditem" onclick="closeDrawer();logout()"><span class="dico">${I.logout}</span>Logout</button>`:""}
    </nav>
    <div class="drawer-foot">
      <div class="follow-label">Follow us</div>
      <div class="social">
        <a href="#" onclick="event.preventDefault();toast('Facebook — demo')" aria-label="Facebook">f</a>
        <a href="#" onclick="event.preventDefault();toast('YouTube — demo')" aria-label="YouTube">▶</a>
        <a href="#" onclick="event.preventDefault();toast('Messenger — demo')" aria-label="Messenger">💬</a>
      </div>
      <div class="version">❤️ Version 1.1.3<br>© 2026 Doctor App</div>
    </div>
  `;
}

function openDrawer(){
  const d=$("#drawer"); const b=$("#drawerBack");
  d.innerHTML=drawerHtml(); d.classList.add("open"); b.classList.add("open");
}
function closeDrawer(){const d=$("#drawer");const b=$("#drawerBack");if(d)d.classList.remove("open");if(b)b.classList.remove("open");}
window.openDrawer=openDrawer; window.closeDrawer=closeDrawer; window.logout=logout;

/* ---------- Language toggle ---------- */
function toggleLang(){
  state.lang = state.lang==="en" ? "bn" : "en";
  try{ localStorage.setItem("da_lang", state.lang); }catch(e){}
  toast(state.lang==="en" ? "Language: English" : "ভাষা: বাংলা", "success");
  render();
}
window.toggleLang = toggleLang;

/* ---------- Theme toggle ---------- */
function toggleTheme(){
  state.theme = state.theme==="dark" ? "light" : "dark";
  try{ localStorage.setItem("da_theme", state.theme); }catch(e){}
  document.body.classList.toggle("dark", state.theme==="dark");
  toast(state.theme==="dark" ? "Dark mode on" : "Light mode on", "success");
  render();
}
window.toggleTheme = toggleTheme;

/* ---------- PWA install ---------- */
function installApp(){
  if(state.deferredPrompt){
    state.deferredPrompt.prompt();
    state.deferredPrompt.userChoice.then((choice)=>{
      if(choice.outcome==="accepted"){
        toast("Doctor App installed!","success");
        try{ localStorage.setItem("da_install_dismissed","1"); }catch(e){}
        const b=document.getElementById("installBanner"); if(b) b.remove();
      } else {
        toast("Install dismissed","info");
      }
      state.deferredPrompt = null;
    }).catch(()=>{});
  } else {
    // Show install instructions modal for browsers without beforeinstallprompt
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isAndroid = /Android/i.test(navigator.userAgent);
    let instructions = "";
    if(isIOS){
      instructions = `<p style="font-size:14px;line-height:1.8">1. Tap the <strong>Share</strong> button (⬆️) in Safari<br>2. Select <strong>"Add to Home Screen"</strong><br>3. Tap <strong>"Add"</strong> to install</p>`;
    } else if(isAndroid){
      instructions = `<p style="font-size:14px;line-height:1.8">1. Tap the <strong>⋮ menu</strong> in Chrome<br>2. Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong><br>3. Tap <strong>"Install"</strong></p>`;
    } else {
      instructions = `<p style="font-size:14px;line-height:1.8">1. Click the <strong>install icon</strong> (⊕) in the address bar<br>Or: Click <strong>⋮ menu → Install Doctor App</strong><br>2. Click <strong>"Install"</strong></p>`;
    }
    openModal("📱 Install Doctor App", `
      <div style="text-align:center;margin-bottom:14px">
        <img src="/icon-192.png" alt="Doctor App" style="width:64px;height:64px;border-radius:16px;margin:0 auto 8px;display:block"/>
        <div style="font-weight:700;font-size:16px">Doctor App</div>
        <div style="color:var(--muted);font-size:13px">Install on your device for quick access</div>
      </div>
      ${instructions}
      <div class="alert alert-warn" style="margin-top:10px">💡 After installing, the app will open in full screen like a native app.</div>
    `, [{label:"Got it", cls:"btn-primary", onClick:()=>{ closeModal(); try{ localStorage.setItem("da_install_dismissed","1"); }catch(e){} const b=document.getElementById("installBanner"); if(b) b.remove(); }}]);
  }
}
window.installApp = installApp;

/* ---------- PWA install banner (show once, hide after install/dismiss) ---------- */
function shouldShowInstallBanner(){
  // Already installed (running as standalone PWA)
  if(window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) return false;
  if(window.navigator.standalone) return false;
  // User dismissed or installed before
  try{ if(localStorage.getItem("da_install_dismissed")==="1") return false; }catch(e){}
  // Show only if the browser fired beforeinstallprompt (installable) OR
  // we haven't shown it yet. We show it once on first visit.
  try{ if(localStorage.getItem("da_install_shown")==="1" && !state.deferredPrompt) return false; }catch(e){}
  return true;
}
function dismissInstall(){
  try{ localStorage.setItem("da_install_dismissed","1"); }catch(e){}
  const b=document.getElementById("installBanner");
  if(b){ b.style.transition=".25s"; b.style.opacity="0"; b.style.transform="translateY(-8px)"; setTimeout(()=>b.remove(),260); }
  toast("Install dismissed","info");
}
window.dismissInstall=dismissInstall;

/* ---------- Favorites ---------- */
function loadFavs(){
  try{ const raw=localStorage.getItem("da_favs"); state.favs=raw?JSON.parse(raw):[]; }catch(e){ state.favs=[]; }
}
function saveFavs(){ try{ localStorage.setItem("da_favs",JSON.stringify(state.favs)); }catch(e){} }
function toggleFav(id,btn){
  const i=state.favs.indexOf(id);
  if(i>-1){ state.favs.splice(i,1); btn.classList.remove("active"); btn.textContent="♡"; toast("Removed from favorites","info"); }
  else{ state.favs.push(id); btn.classList.add("active"); btn.textContent="❤"; toast("Added to favorites","success"); }
  saveFavs();
}
/* ---------- Share doctor ---------- */
async function shareDoctor(id){
  try{
    const d=window.__allDoctors?window.__allDoctors.find(function(x){return x.id===id}):null;
    const url=location.origin+"/#/doctors/"+id;
    const title=d?d.name:"Doctor App";
    const text=d?(d.name+" — "+d.specialty+(d.hospital?" ("+d.hospital.name+")":"")):"Check out this doctor";
    if(navigator.share){
      await navigator.share({title:title,text:text,url:url});
    } else {
      await navigator.clipboard.writeText(url);
      toast("Link copied to clipboard","success");
    }
  }catch(e){ /* user cancelled share — do nothing */ }
}
window.toggleFav=toggleFav; window.shareDoctor=shareDoctor;

/* ---------- Show Favorites page ---------- */
async function showFavorites(){
  closeDrawer();
  mount(loadingView());
  const {data}=await api("/api/doctors");
  const allDoctors=data?.doctors||[];
  const favDocs=allDoctors.filter(d=>state.favs.includes(d.id));
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>❤️ ${state.lang==="bn"?"পছন্দ":"Favorites"}</h1><p>${favDocs.length} ${state.lang==="bn"?"জন প্রিয় ডাক্তার":"favorite doctors"}</p></div>
  ${favDocs.length?`<div id="favList">${favDocs.map(doctorCard).join("")}</div>`:emptyState(state.lang==="bn"?"কোনো প্রিয় ডাক্তার নেই":"No favorites yet","Tap the ♡ icon on doctor cards to save them here.")}
  `;
  mount(inner);
}
window.showFavorites=showFavorites;
function loadNotifs(){
  try{
    const raw = localStorage.getItem("da_notifs");
    state.notifs = raw ? JSON.parse(raw) : [];
  }catch(e){ state.notifs = []; }
}
function saveNotifs(){
  try{ localStorage.setItem("da_notifs", JSON.stringify(state.notifs.slice(0,50))); }catch(e){}
}
function playNotifSound(){
  try{
    // Use Web Audio API to generate a notification sound (no external file needed)
    const ctx = new (window.AudioContext||window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.setValueAtTime(1100, ctx.currentTime + 0.15);
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.5);
  }catch(e){}
  // Also try the Notification API sound (vibrate on mobile)
  try{ if(navigator.vibrate) navigator.vibrate([200,100,200]); }catch(e){}
}
function addNotif(title, msg, icon){
  const n = { id: Date.now()+"_"+Math.random().toString(36).slice(2,6), title, msg, icon:icon||"🔔", read:false, ts: Date.now() };
  state.notifs.unshift(n);
  saveNotifs();
  renderHeaderBtns();
  playNotifSound();
}
function markNotifRead(id){
  const n = state.notifs.find(x=>x.id===id);
  if(n && !n.read){ n.read = true; saveNotifs(); renderHeaderBtns(); renderNotifPanel(); }
}
function markAllNotifsRead(){
  state.notifs.forEach(n=>n.read=true);
  saveNotifs();
  renderHeaderBtns();
  renderNotifPanel();
  toast("All marked as read","success");
}
function renderHeaderBtns(){
  // Update the notification button dot without full re-render
  const btns = document.querySelectorAll(".app-header .hbtn");
  if(btns.length>=3){
    const unread = state.notifs.filter(n=>!n.read).length;
    btns[2].innerHTML = "🔔" + (unread?`<span class="dot"></span>`:"");
  }
}
function notifPanelHtml(){
  const unread = state.notifs.filter(n=>!n.read).length;
  const items = state.notifs;
  return `
    <div class="notif-head">
      <h3>${t("notifications")} ${unread?`<span class="badge badge-danger">${unread}</span>`:""}</h3>
      <button class="clear" onclick="markAllNotifsRead()">${t("markAllRead")}</button>
    </div>
    <div class="notif-body" id="notifBody">
      ${items.length ? items.map(n=>`
        <div class="notif-item ${n.read?"read":"unread"}" onclick="markNotifRead('${n.id}')">
          <div class="n-ico">${n.icon||"🔔"}</div>
          <div class="n-body">
            <div class="n-title">${esc(n.title)}</div>
            <div class="n-msg">${esc(n.msg)}</div>
            <div class="n-time">${fmtNotifTime(n.ts)}</div>
          </div>
          <div class="n-dot"></div>
        </div>
      `).join("") : `<div class="notif-empty"><div class="ico">🔔</div><div>${t("noNotifs")}</div></div>`}
    </div>
  `;
}
function fmtNotifTime(ts){
  const diff = Date.now() - ts;
  const m = Math.floor(diff/60000), h = Math.floor(diff/3600000), d = Math.floor(diff/86400000);
  if(m<1) return "just now";
  if(m<60) return m+" min ago";
  if(h<24) return h+" hr ago";
  if(d<7) return d+" day"+(d>1?"s":"")+" ago";
  return fmtDate(ts);
}
function openNotif(){
  const p=$("#notifPanel"); const b=$("#notifBack");
  p.innerHTML = notifPanelHtml();
  p.classList.add("open"); b.classList.add("open");
}
function closeNotif(){const p=$("#notifPanel");const b=$("#notifBack");if(p)p.classList.remove("open");if(b)b.classList.remove("open");}
function renderNotifPanel(){
  const p=$("#notifPanel");
  if(p && p.classList.contains("open")) p.innerHTML = notifPanelHtml();
}
window.toggleLang=toggleLang; window.toggleTheme=toggleTheme;
window.openNotif=openNotif; window.closeNotif=closeNotif;
window.markNotifRead=markNotifRead; window.markAllNotifsRead=markAllNotifsRead;

/* ===================================================================
   Dr. AI — AI Assistant Assistant
   =================================================================== */
const aiState = { messages:[], patient:null, doctors:[], step:"greet", lang:"en" };

// Symptom → specialty mapping (keywords in English + Bangla + Banglish)
const SYMPTOM_MAP = [
  { specialty:"Cardiologist", kw:["chest pain","heart","cardiac","breath","blood pressure","bp","বুক ব্যথা","হৃদ","হার্ট","শ্বাস","রক্তচাপ","buk byatha","hrid","shwas"] },
  { specialty:"Dermatologist", kw:["skin","rash","itch","acne","pimple","eczema","allergy","চামড়া","র্যাশ","চুলকানি","ব্রণ","একজিমা","chamra","chulkani","brn"] },
  { specialty:"Neurologist", kw:["headache","migraine","dizzy","numb","stroke","seizure","brain","মাথা ব্যথা","মাইগ্রেন","মাথা ঘোরা","ঝিমঝিম","স্নায়ু","matha byatha","matha ghora"] },
  { specialty:"Gynecologist", kw:["pregnan","gynec","women","period","menstrual","uterus","ovary","গর্ভ","স্ত্রী","মাসিক","জরায়ু","garbho","stri","masik"] },
  { specialty:"Pediatrician", kw:["child","kid","baby","infant","শিশু","বাচ্চা","shishu","baccha"] },
  { specialty:"Dentist", kw:["tooth","teeth","dental","gum","দাঁত","দন্ত","dant"] },
  { specialty:"Orthopedic", kw:["bone","joint","fracture","back pain","knee","neck","spine","হাড়","জয়েন্ট","কোমর","ঘাড়","মেরুদণ্ড","har","kumor"] },
  { specialty:"ENT Specialist", kw:["ear","nose","throat","sinus","hearing","কান","নাক","গলা","সাইনাস","kan","nak","gala"] },
  { specialty:"Eye Specialist", kw:["eye","vision","sight","blind","চোখ","দৃষ্টি","cokh"] },
  { specialty:"General Physician", kw:["fever","cough","cold","flu","stomach","diarrhea","vomit","weak","জ্বর","কাশি","সর্দি","পেট","বমি","দুর্বল","jor","kashi","sordi","pet"] },
];

// Emergency keywords
const EMERGENCY_KW = ["severe chest pain","can't breathe","unconscious","bleeding heavily","stroke","heart attack","paralysis","suicid","অজ্ঞান","অচেতন","মারাত্মক রক্তক্ষয়","ajanto","acetonto"];

function detectLang(text){
  // Bengali Unicode range
  if(/[\u0980-\u09FF]/.test(text)) return "bn";
  return "en";
}

function detectSpecialty(text){
  const t = text.toLowerCase();
  for(const m of SYMPTOM_MAP){
    if(m.kw.some(k=>t.includes(k))) return m.specialty;
  }
  return null;
}

function isEmergency(text){
  const t = text.toLowerCase();
  return EMERGENCY_KW.some(k=>t.includes(k));
}

function aiGreeting(){
  const saved = aiLoadProfile();
  if(saved && saved.patient_name){
    aiState.lang = saved.lang || "en";
    if(aiState.lang==="bn"){
      return `হ্যালো! আবার স্বাগতম, ${saved.patient_name}! 🩺\n\nআপনি কি এখনও "${saved.symptoms||"আগের সমস্যা"}" নিয়ে সাহায্য খুঁজছেন, নাকি আজ নতুন কিছু জানাতে চান?\n\nঅনুগ্রহ করে আপনার লক্ষণ বা সমস্যাটি বিস্তারিত বলুন।`;
    }
    return `Hello! Welcome back, ${saved.patient_name}! 🩺\n\nAre you still looking for assistance regarding "${saved.symptoms||"your previous concern"}", or is there something new today?\n\nPlease describe your symptoms or concern in detail.`;
  }
  return `Hello! Welcome to Doctor App. I'm AI Assistant, your virtual medical assistant. 🩺\n\nTo help you find the right doctor, could you please tell me your **Name** and **Current City/Address**?\n\nআমি বাংলায়ও কথা বলতে পারি। আপনার নাম এবং ঠিকানা বাংলায় লিখতে পারেন।`;
}

function aiLoadProfile(){
  try{ return JSON.parse(localStorage.getItem("da_ai_patient")); }catch(e){ return null; }
}
function aiSaveProfile(data){
  try{ localStorage.setItem("da_ai_patient", JSON.stringify(data)); }catch(e){}
}

function openDrAI(){
  const back=$("#aiBack");
  back.classList.add("open");
  if(aiState.messages.length===0){
    aiState.messages=[];
    aiState.step="greet";
    aiAddBot(aiGreeting());
    aiAddQuickReplies(["I need a doctor","আমার ডাক্তার দরকার","Book appointment"]);
  }
  setTimeout(()=>{const b=$("#aiBody"); if(b) b.scrollTop=b.scrollHeight;},100);
  setTimeout(()=>{const i=$("#aiInput"); if(i) i.focus();},300);
}
function closeDrAI(){
  const back=$("#aiBack");
  if(back) back.classList.remove("open");
}
function clearAIChat(){
  if(!confirm("Clear chat history?")) return;
  aiState.messages=[]; aiState.patient=null; aiState.step="greet";
  $("#aiBody").innerHTML="";
  aiAddBot(aiGreeting());
  aiAddQuickReplies(["I need a doctor","আমার ডাক্তার দরকার","Book appointment"]);
}
window.openDrAI=openDrAI; window.closeDrAI=closeDrAI; window.clearAIChat=clearAIChat;

function aiAddBot(html, cls="bot"){
  const body=$("#aiBody");
  const div=document.createElement("div");
  div.className="ai-msg "+cls;
  div.innerHTML=html;
  body.appendChild(div);
  body.scrollTop=body.scrollHeight;
  aiState.messages.push({role:"bot", html});
}
function aiAddUser(text){
  const body=$("#aiBody");
  const div=document.createElement("div");
  div.className="ai-msg user";
  div.textContent=text;
  body.appendChild(div);
  body.scrollTop=body.scrollHeight;
  aiState.messages.push({role:"user", text});
}
function aiAddQuickReplies(options){
  const body=$("#aiBody");
  const div=document.createElement("div");
  div.className="ai-quick";
  options.forEach(opt=>{
    const btn=document.createElement("button");
    btn.textContent=opt;
    btn.onclick=()=>{ $("#aiInput").value=opt; aiSend(); };
    div.appendChild(btn);
  });
  body.appendChild(div);
  body.scrollTop=body.scrollHeight;
}
function aiTyping(){
  const body=$("#aiBody");
  const div=document.createElement("div");
  div.className="ai-typing"; div.id="aiTyping";
  div.innerHTML="<span></span><span></span><span></span>";
  body.appendChild(div);
  body.scrollTop=body.scrollHeight;
}
function aiRemoveTyping(){
  const t=$("#aiTyping"); if(t) t.remove();
}

async function aiSend(){
  const input=$("#aiInput");
  const text=input.value.trim();
  if(!text) return;
  input.value="";
  aiAddUser(text);
  aiState.lang = detectLang(text);

  aiTyping();

  // Build conversation messages for the LLM
  const convMessages = aiState.messages
    .filter(m=>m.role==="user"||m.role==="bot")
    .map(m=>({
      role: m.role==="user"?"user":"assistant",
      content: m.text || m.html?.replace(/<[^>]+>/g,"") || ""
    }));

  // Fetch doctors for the system prompt
  const {data:docData} = await api("/api/doctors");
  const doctors = docData?.doctors || [];

  try{
    const res = await fetch("/api/ai-chat",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({messages:convMessages, doctors}),
    });
    const d = await res.json();
    aiRemoveTyping();
    if(d.error){
      aiAddBot("⚠️ "+d.error);
      return;
    }
    // Show the LLM text reply (without doctor details — LLM is told to only recommend)
    aiAddBot(d.reply);

    // Find mentioned doctors by name matching (case-insensitive)
    const replyLower = d.reply.toLowerCase();
    let mentionedDocs = doctors.filter(doc=>replyLower.includes(doc.name.toLowerCase()));

    // If no doctors mentioned by name, check if this is a recommendation response
    if(mentionedDocs.length===0){
      const allText = (text+" "+d.reply).toLowerCase();
      // Only show cards if the AI is clearly recommending (not just mentioning "specialist")
      const isRecommending = (
        allText.includes("here are some recommend") ||
        allText.includes("i found some") ||
        allText.includes("i recommend") ||
        allText.includes("based on your symptoms") ||
        allText.includes("নিচে দেওয়া হলো") ||
        allText.includes("এখানে কিছু বিশেষজ্ঞ") ||
        allText.includes("আপনার লক্ষণ অনুযায়ী")
      );
      if(isRecommending){
        // Detect specialty from the full conversation
        const specialty = detectSpecialty(allText);
        if(specialty){
          let matched = doctors.filter(doc=>doc.specialty && doc.specialty.toLowerCase().includes(specialty.toLowerCase()));
          if(matched.length===0){
            matched = doctors.filter(doc=>doc.specialty && doc.specialty.toLowerCase().includes(specialty.toLowerCase().split(" ")[0]));
          }
          if(matched.length===0){
            matched = doctors.filter(doc=>doc.specialty && doc.specialty.toLowerCase().includes("general"));
          }
          mentionedDocs = matched;
        }
      }
    }

    // Always show up to 4 doctor cards if any doctors were mentioned or matched
    if(mentionedDocs.length>0){
      const cardsHtml = mentionedDocs.slice(0,4).map(doc=>`
        <div class="ai-doc-card" onclick="closeDrAI();navigate('/doctors/${doc.id}')">
          <div class="dc-top">
            <div class="dc-avatar">${esc(initials(doc.name))}</div>
            <div class="dc-info">
              <div class="dc-name">${esc(doc.name)}</div>
              <div class="dc-spec">${esc(doc.specialty)}</div>
            </div>
          </div>
          <div class="dc-meta">
            ${doc.qualifications?`<div class="row">🎓 ${esc(doc.qualifications)}</div>`:""}
            ${doc.hospital?`<div class="row">🏥 ${esc(doc.hospital.name)}</div>`:""}
            ${doc.city?`<div class="row">📍 ${esc(doc.address||"")}, ${esc(doc.city)}</div>`:""}
            ${doc.hours?`<div class="row">🕒 ${esc(doc.hours)}</div>`:""}
            ${doc.fee?`<div class="row">৳${esc(doc.fee)} visit fee</div>`:""}
          </div>
        </div>
      `).join("");
      aiAddBot('<div style="margin-top:4px">'+cardsHtml+'</div>',"doctors");
      aiAddBot("Tap any doctor's card to view full details and book an appointment. Need more help?","bot");
      aiAddQuickReplies(["Thank you","ধন্যবাদ","Find another doctor"]);
    }

    // Save patient profile from conversation
    aiSaveProfile({
      patient_name: aiState.patient?.name || "",
      patient_address: aiState.patient?.city || "",
      symptoms: text,
      recommended_doctors: mentionedDocs.slice(0,4).map(d=>d.name),
      last_updated: new Date().toISOString(),
      lang: aiState.lang,
    });
  }catch(e){
    aiRemoveTyping();
    aiAddBot("⚠️ Connection error. Please try again.");
  }
}
window.aiSend=aiSend;

function bottomNav(){
  const p=pathParts()[0]||"";
  const active=(k)=> (k==="home"&&p==="")||p===k ? "active":"";
  return `
  <nav class="bottom-nav">
    <a class="bn-item ${active("")||active("home")?"active":""}" href="#/"><span class="ico"><svg viewBox="0 0 24 24" style="width:22px;height:22px;stroke:currentColor;stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round"><path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1V9.5z"/></svg></span><span>Home</span></a>
    <a class="bn-item ${active("blood-donors")?"active":""}" href="#/blood-donors"><span class="ico"><svg viewBox="0 0 24 24" style="width:22px;height:22px;stroke:currentColor;stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round"><path d="M12 2s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/></svg></span><span>Blood</span></a>
    <a class="bn-item ai" onclick="openDrAI()" style="cursor:pointer"><button class="bn-ai-btn"><svg viewBox="0 0 24 24" style="width:26px;height:26px;stroke:#0284C7;stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round"><path d="M6 3v5a6 6 0 0 0 12 0V3"/><path d="M6 3h2M16 3h2"/><circle cx="18" cy="15" r="2"/><path d="M18 17v3a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3v-5"/></svg></button><span class="lbl">Dr. AI</span></a>
    <a class="bn-item ${active("medicine")?"active":""}" href="#/medicine"><span class="ico"><svg viewBox="0 0 24 24" style="width:22px;height:22px;stroke:currentColor;stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round"><path d="M10.5 20.5L3.5 13.5a5 5 0 0 1 7-7l7 7a5 5 0 0 1-7 7z"/><path d="M8.5 8.5l7 7"/></svg></span><span>Medicine</span></a>
    <a class="bn-item ${active("account")||active("doctor-profile")||active("admin")?"active":""}" href="${state.user?(isDoctor()?'#/doctor-profile':isAdmin()?'#/admin':'#/account'):'#/login'}"><span class="ico"><svg viewBox="0 0 24 24" style="width:22px;height:22px;stroke:currentColor;stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span><span>Profile</span></a>
  </nav>`;
}

function shell(inner,opts={}){
  return `<div class="app-wrap">${header()}<main class="app-main">${inner}</main>${bottomNav()}</div>`;
}

function mount(inner,init,opts={}){
  $("#app").innerHTML=shell(inner,opts);
  window.scrollTo(0,0);
  if(init) init();
}
function loadingView(){return `<div class="loading"><div class="spinner"></div></div>`;}
function emptyState(title,sub){return `<div class="empty"><div class="ico">🔍</div><div style="font-weight:600;color:var(--text)">${esc(title)}</div><div style="font-size:13px;margin-top:4px">${esc(sub||"")}</div></div>`;}

/* ===================================================================
   HOME
   =================================================================== */
async function viewHome(){
  // Phase 1: Try to render immediately with cached data (instant load)
  var cached=apiGetCache("/api/slides"),cachedCats=apiGetCache("/api/categories"),cachedDocs=apiGetCache("/api/doctors"),cachedHosps=apiGetCache("/api/hospitals"),cachedAmbs=apiGetCache("/api/ambulances"),cachedArts=apiGetCache("/api/articles"),cachedCities=apiGetCache("/api/cities");
  var hasCached=cached||cachedCats||cachedDocs||cachedHosps||cachedAmbs||cachedArts||cachedCities;
  if(hasCached){
    // Render with cached data immediately
    renderHome(cached&&cached.slides||[],cachedCats&&cachedCats.categories||[],(cachedDocs&&cachedDocs.doctors||[]).slice(0,10),(cachedHosps&&cachedHosps.hospitals||[]).slice(0,4),cachedCities&&cachedCities.cities||[],(cachedAmbs&&cachedAmbs.ambulances||[]).slice(0,8),(cachedArts&&cachedArts.articles||[]).slice(0,4));
  }else{
    mount(loadingView());
  }
  // Phase 2: Fetch fresh data and re-render
  const [slides,cats,docs,hosps,ambs,arts,citiesData]=await Promise.all([
    api("/api/slides"),api("/api/categories"),api("/api/doctors"),
    api("/api/hospitals"),api("/api/ambulances"),api("/api/articles"),
    api("/api/cities")
  ]);
  const slideArr=slides.data?.slides||[];
  const catArr=cats.data?.categories||[];
  const docArr=(docs.data?.doctors||[]).slice(0,10);
  const hospArr=(hosps.data?.hospitals||[]).slice(0,4);
  const cityArr=citiesData.data?.cities||[];
  const ambArr=(ambs.data?.ambulances||[]).slice(0,8);
  const artArr=(arts.data?.articles||[]).slice(0,4);
  renderHome(slideArr,catArr,docArr,hospArr,cityArr,ambArr,artArr);
}
function apiGetCache(path){
  try{
    var cached=localStorage.getItem("api_cache_"+path);
    if(cached){
      var parsed=JSON.parse(cached);
      if(parsed.data) return parsed.data;
    }
  }catch(e){}
  return null;
}
function renderHome(slideArr,catArr,docArr,hospArr,cityArr,ambArr,artArr){
  const slidesHtml=slideArr.length?slideArr.map((s,i)=>`<div class="hero-slide ${i===0?"active":""}" style="background-image:url('${esc(s.image||"")}')"></div>`).join("")
    :`<div class="hero-slide active" style="background:linear-gradient(135deg,#0EA5E9,#0369A1)"></div>`;
  const dots=slideArr.length?slideArr.map((_,i)=>`<button data-i="${i}" class="${i===0?"active":""}"></button>`).join(""):"";

  const settings=loadSettings();
  const marqueeItems=(settings.marqueeText&&settings.marqueeText.length)?settings.marqueeText:[
    "Welcome to Doctor App — your health, our priority.",
    "Find trusted doctors near you.",
    "24/7 ambulance service available.",
    "Book appointments with verified specialists.",
    "Stay healthy, stay safe."
  ];

  const inner=`
  ${shouldShowInstallBanner()?`
  <div class="install-banner" id="installBanner">
    <div class="ib-ico"><img src="/icon-192.png" alt="Doctor App" style="width:32px;height:32px;border-radius:8px;object-fit:cover"/></div>
    <div class="ib-body">
      <div class="ib-title">Install Doctor App</div>
      <div class="ib-sub">Add to your home screen for quick access</div>
    </div>
    <button class="ib-btn" onclick="installApp()">Install</button>
    <button class="ib-close" onclick="dismissInstall()" aria-label="Close">×</button>
  </div>
  `:""}

  ${settings.marquee!==false?`
  <div class="update-bar">
    <button class="ub-btn" onclick="toast('${t("update")}')">📢 ${t("update")}</button>
    <div class="ub-marquee"><div class="ub-track">${marqueeItems.map(m=>`<span>${esc(m)}</span>`).join("")}</div></div>
  </div>
  `:""}

  <div class="hero" id="hero">
    ${slidesHtml}
    <div class="hero-dots" id="heroDots">${dots}</div>
  </div>

  <div class="searchbar" style="position:relative">
    <span class="ico">🔎</span>
    <input id="homeSearch" placeholder="${t("searchPh")}" oninput="instantSearch(this.value)" onkeydown="if(event.key==='Enter')homeSearchGo()">
    <button class="go" onclick="homeSearchGo()">➜</button>
    <div id="searchDropdown" style="display:none;position:absolute;top:calc(100% + 6px);left:0;right:0;background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow-lg);max-height:320px;overflow-y:auto;z-index:40;border:1px solid var(--line)"></div>
  </div>

  <div class="chips-row" id="homeChips">
    <button class="chip active" onclick="homeChip(this,'')">📋 ${t("all")}</button>
    ${catArr.map(c=>`<button class="chip" onclick="homeChip(this,'${esc(c.name)}')"><span class="c-ico">${catIcon(c.name)}</span>${esc(state.lang==="bn"&&c.bn?c.bn:c.name)}</button>`).join("")}
  </div>

  <div class="loc-row">
    <div class="loc-pill"><span class="ico">📍</span><select id="homeCity" onchange="homeCityGo()"><option value="">${t("allCities")}</option>${cityArr.map(c=>`<option value="${esc(c.name)}">${esc(c.name)}</option>`).join("")}</select></div>
    <button class="loc-pill near" onclick="findNearMe()"><span class="ico">📌</span>${t("nearMe")}</button>
  </div>

  <section class="section">
    <div class="section-head"><h2>${t("browseCat")}</h2></div>
    <div class="cat-grid">
      ${catArr.slice(0,8).map(c=>`<div class="cat-card" onclick="navigate('/doctors?specialty=${encodeURIComponent(c.name)}')"><div class="cat-ico">${catIcon(c.name)}</div><div class="name">${esc(state.lang==="bn"&&c.bn?c.bn:c.name)}</div></div>`).join("")}
    </div>
  </section>

  <section class="section">
    <div class="section-head"><h2>${t("topDoctors")} ${docArr.length} ${t("doctors")}</h2><a class="see-all" href="#/doctors">${t("seeAll")}</a></div>
    <div id="homeDocs">${docArr.map(doctorCard).join("")}</div>
  </section>

  <section class="section">
    <div class="section-head"><h2>${t("topHospitals")}</h2><a class="see-all" href="#/hospitals">${t("seeAll")}</a></div>
    <div>${hospArr.map(hospitalCard).join("")}</div>
  </section>

  <section class="section">
    <div class="section-head"><h2>${t("emergency")}</h2><a class="see-all" href="#/ambulances">${t("seeAll")}</a></div>
    ${ambArr.length
      ?`<div class="amb-carousel">${ambArr.map(a=>ambulanceCardHome(a)).join("")}</div>`
      :`<div class="amb-carousel-empty">${state.lang==="bn"?"কোনো অ্যাম্বুলেন্স পাওয়া যায়নি।":"No ambulances available."}</div>`}
  </section>

  <section class="section">
    <div class="section-head"><h2>📍 ${t("bangladeshMap")}</h2></div>
    <div style="border-radius:var(--radius);overflow:hidden;box-shadow:var(--shadow);position:relative">
      <iframe id="bdMapFrame" src="https://maps.google.com/maps?q=Bangladesh&z=7&output=embed" style="width:100%;height:320px;border:0;display:block" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <div id="mapPins" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
      ${[...new Set(docArr.filter(d=>d.city).map(d=>d.city))].map(city=>`<a href="#/doctors?city=${encodeURIComponent(city)}" class="chip" style="font-size:11px"><span class="c-ico">📍</span>${esc(city)} (${docArr.filter(d=>d.city===city).length})</a>`).join("")}
    </div>
    <a href="https://maps.app.goo.gl/JhbJEr6h3m7T59dB8" target="_blank" rel="noopener" class="btn btn-ghost btn-block" style="margin-top:8px">${t("openInMaps")}</a>
  </section>

  <section class="section">
    <div class="section-head"><h2>${t("healthArt")}</h2><a class="see-all" href="#/articles">${t("seeAll")}</a></div>
    <div class="art-grid">${artArr.map(articleCard).join("")}</div>
  </section>
  `;
  mount(inner,()=>{
    window.__allDoctors=docArr;
    // Mark install banner as shown (won't show again unless beforeinstallprompt fires)
    if(shouldShowInstallBanner()){ try{ localStorage.setItem("da_install_shown","1"); }catch(e){} }
    // Update Bangladesh map to show doctor cities as pins
    const citiesWithDocs=[...new Set(docArr.filter(d=>d.city).map(d=>d.city))];
    if(citiesWithDocs.length>0){
      const mapFrame=$("#bdMapFrame");
      if(mapFrame){
        // Build a map URL that shows all doctor cities
        const cityQuery=citiesWithDocs.map(c=>c+" Bangladesh").join("|");
        mapFrame.src="https://maps.google.com/maps?q="+encodeURIComponent(cityQuery)+"&z=7&output=embed";
      }
      // Add click handlers to city chips to update map
      $$("#mapPins .chip").forEach(chip=>{
        chip.addEventListener("click",(e)=>{
          e.preventDefault();
          const city=chip.textContent.replace(/📍|\s*\(\d+\)/g,"").trim();
          const mf=$("#bdMapFrame");
          if(mf) mf.src="https://maps.google.com/maps?q="+encodeURIComponent(city+" Bangladesh")+"&z=11&output=embed";
        });
      });
    }
    const slidesEls=$$(".hero-slide"); const dotsEls=$$("#heroDots button");
    if(slidesEls.length>1){
      let i=0;
      setInterval(()=>{slidesEls[i].classList.remove("active");dotsEls[i]&&dotsEls[i].classList.remove("active");i=(i+1)%slidesEls.length;slidesEls[i].classList.add("active");dotsEls[i]&&dotsEls[i].classList.add("active");},5000);
    }
  });
}
window.homeSearchGo=function(){
  const q=$("#homeSearch").value.trim();
  if(q) navigate("/doctors?q="+encodeURIComponent(q));
};
/* ---------- Instant search (live results dropdown) ---------- */
let __searchTimer=null;
let __searchData={doctors:[],hospitals:[],donors:[]};
async function loadSearchData(){
  if(__searchData.doctors.length) return;
  const [d,h,b]=await Promise.all([api("/api/doctors"),api("/api/hospitals"),api("/api/blood-donors")]);
  __searchData.doctors=d.data?.doctors||[];
  __searchData.hospitals=h.data?.hospitals||[];
  __searchData.donors=b.data?.donors||[];
}
function instantSearch(q){
  clearTimeout(__searchTimer);
  const dd=$("#searchDropdown");
  if(!q||q.trim().length<1){ if(dd){dd.style.display="none";} return; }
  __searchTimer=setTimeout(async()=>{
    await loadSearchData();
    const t=q.toLowerCase().trim();
    const dMatch=__searchData.doctors.filter(d=>(d.name+" "+d.specialty+" "+d.city).toLowerCase().includes(t)).slice(0,4);
    const hMatch=__searchData.hospitals.filter(h=>(h.name+" "+h.city).toLowerCase().includes(t)).slice(0,3);
    const bMatch=__searchData.donors.filter(b=>(b.name+" "+b.bloodGroup+" "+b.city).toLowerCase().includes(t)).slice(0,3);
    let html="";
    if(dMatch.length){
      html+=`<div style="padding:6px 12px;font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.03em;background:var(--surface-2)">🩺 Doctors</div>`;
      html+=dMatch.map(d=>`<a href="#/doctors/${d.id}" style="display:flex;align-items:center;gap:10px;padding:9px 12px;border-bottom:1px solid var(--line-2);cursor:pointer" onmouseover="this.style.background='var(--primary-faint)'" onmouseout="this.style.background=''"><div style="width:32px;height:32px;border-radius:50%;background:var(--primary-soft);color:var(--primary-dark);display:grid;place-items:center;font-weight:700;font-size:12px;flex-shrink:0">${esc(initials(d.name))}</div><div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(d.name)}</div><div style="font-size:11px;color:var(--muted)">${esc(d.specialty)}${d.city?" · "+esc(d.city):""}</div></div></a>`).join("");
    }
    if(hMatch.length){
      html+=`<div style="padding:6px 12px;font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.03em;background:var(--surface-2)">🏥 Hospitals</div>`;
      html+=hMatch.map(h=>`<a href="#/hospitals/${h.id}" style="display:flex;align-items:center;gap:10px;padding:9px 12px;border-bottom:1px solid var(--line-2);cursor:pointer" onmouseover="this.style.background='var(--primary-faint)'" onmouseout="this.style.background=''"><div style="width:32px;height:32px;border-radius:50%;background:var(--primary-soft);color:var(--primary-dark);display:grid;place-items:center;font-size:14px;flex-shrink:0">🏥</div><div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(h.name)}</div><div style="font-size:11px;color:var(--muted)">${esc(h.city||"")}</div></div></a>`).join("");
    }
    if(bMatch.length){
      html+=`<div style="padding:6px 12px;font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.03em;background:var(--surface-2)">🩸 Blood Donors</div>`;
      html+=bMatch.map(b=>`<a href="#/blood-donors" style="display:flex;align-items:center;gap:10px;padding:9px 12px;border-bottom:1px solid var(--line-2);cursor:pointer" onmouseover="this.style.background='var(--primary-faint)'" onmouseout="this.style.background=''"><div style="width:32px;height:32px;border-radius:50%;background:var(--red-soft);color:var(--red);display:grid;place-items:center;font-weight:700;font-size:11px;flex-shrink:0">${esc(b.bloodGroup)}</div><div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(b.name)}</div><div style="font-size:11px;color:var(--muted)">${esc(b.city)}${b.available?" · Available":""}</div></div></a>`).join("");
    }
    if(!html){
      html=`<div style="padding:20px;text-align:center;color:var(--muted);font-size:13px">No results for "${esc(q)}"</div>`;
    }
    html+=`<div style="padding:8px 12px;text-align:center;border-top:1px solid var(--line-2)"><a href="#/doctors?q=${encodeURIComponent(q)}" style="font-size:12px;color:var(--primary-2);font-weight:600">Search all doctors →</a></div>`;
    if(dd){dd.innerHTML=html;dd.style.display="block";}
  },200);
}
window.instantSearch=instantSearch;
// Close search dropdown when clicking outside
document.addEventListener("click",(e)=>{
  if(!e.target.closest(".searchbar")){
    const dd=$("#searchDropdown"); if(dd) dd.style.display="none";
  }
});
window.homeChip=function(btn,sp){
  $$("#homeChips .chip").forEach(c=>c.classList.remove("active"));
  btn.classList.add("active");
  navigate("/doctors"+(sp?("?specialty="+encodeURIComponent(sp)):""));
};
window.homeCityGo=function(){
  const c=$("#homeCity").value;
  if(c) navigate("/doctors?city="+encodeURIComponent(c));
};
/* ---------- Near Me (geolocation) ---------- */
function findNearMe(){
  if(!navigator.geolocation){ toast("Geolocation not supported","error"); return; }
  toast("Getting your location…","info");
  navigator.geolocation.getCurrentPosition(
    (pos)=>{
      const lat=pos.coords.latitude, lng=pos.coords.longitude;
      // Use reverse-geocoding via OpenStreetMap (no API key needed)
      fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=10`)
        .then(r=>r.json())
        .then(d=>{
          const addr=d.address||{};
          const city=addr.city||addr.town||addr.village||addr.county||addr.state||"";
          if(city){
            toast("Showing doctors near "+city,"success");
            navigate("/doctors?near="+encodeURIComponent(city)+"&lat="+lat+"&lng="+lng);
          } else {
            // Use coordinates directly with embedded map
            toast("Showing doctors near your location","success");
            navigate("/doctors?near=My+Location&lat="+lat+"&lng="+lng);
          }
        })
        .catch(()=>{
          // Fallback: use coordinates with embedded map (no API key)
          toast("Showing doctors near your location","success");
          navigate("/doctors?near=My+Location&lat="+lat+"&lng="+lng);
        });
    },
    (err)=>{
      const msg = err.code===1?"Location permission denied":"Could not get location";
      toast(msg,"error");
    },
    {enableHighAccuracy:true,timeout:10000,maximumAge:60000}
  );
}
window.findNearMe=findNearMe;

/* ---------- Cards ---------- */
function doctorCard(d){
  const creds=[d.qualifications,d.experience?`${d.experience} yrs exp`:null].filter(Boolean).join(" · ");
  return `
  <div class="doc-card" onclick="navigate('/doctors/${d.id}')">
    <div class="doc-card-top">
      <div class="doc-avatar">${esc(initials(d.name))}</div>
      <div class="doc-info">
        <div class="doc-name">${esc(d.name)} ${d.mapLink?`<span style="font-size:14px">📍</span>`:""}</div>
        <div class="doc-badge"><span class="b-ico">${catIcon(d.specialty)}</span>${esc(d.specialty)}</div>
      </div>
      <div class="doc-actions-top">
        <button onclick="event.stopPropagation();toggleFav('${d.id}',this)" aria-label="Favorite" class="fav-btn${state.favs&&state.favs.includes(d.id)?' active':''}">♡</button>
        <button onclick="event.stopPropagation();shareDoctor('${d.id}')" aria-label="Share"><svg viewBox="0 0 24 24" style="width:18px;height:18px;stroke:currentColor;stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/></svg></button>
      </div>
    </div>
    ${creds?`<div class="doc-creds">${esc(creds)}${d.rating?` · ⭐ ${d.rating.toFixed(1)}`:""}</div>`:""}
    ${d.hospital?`<div class="doc-clinic">🏥 ${esc(d.hospital.name)}</div>`:""}
    <div class="doc-meta">
      ${d.city?`<div class="row"><span class="ico">📍</span>${esc(d.address||"")}, ${esc(d.city)}</div>`:""}
      ${d.hours?`<div class="row"><span class="ico">🕒</span>${esc(d.hours)}</div>`:""}
    </div>
    <div class="doc-btns">
      <a class="b-call" href="tel:${esc(d.phone)}" onclick="event.stopPropagation()">📞 Call</a>
      ${d.mapLink?`<a class="b-sec" href="${esc(d.mapLink)}" target="_blank" rel="noopener" onclick="event.stopPropagation()">📍 Map</a>`:""}
      <button class="b-sec" onclick="event.stopPropagation();navigate('/doctors/${d.id}')">👤 Profile</button>
    </div>
  </div>`;
}
function hospitalCard(h){
  const photo=h.photo?`background-image:url('${esc(h.photo)}')`:"";
  const count=h._count?.doctors??h.doctors?.length??0;
  const rating=h.rating?parseFloat(h.rating):0;
  const ratingBadge=rating>0
    ?`<span class="hosp-rating">⭐ ${rating.toFixed(1)}</span>`
    :`<span class="hosp-rating no-rating">☆ N/A</span>`;
  return `
  <div class="hosp-card" onclick="navigate('/hospitals/${h.id}')">
    <div class="hosp-photo" style="${photo}">${h.photo?"":"🏥"}</div>
    <div class="hosp-body">
      <div class="hosp-name">${esc(h.name)}</div>
      <div class="hosp-meta">
        <div class="row"><span class="ico">📍</span>${esc(h.address||"")}, ${esc(h.city||"")}</div>
        <div class="row"><span class="ico">☎</span>${esc(h.phone||"")}</div>
        <div class="row"><span class="ico">🩺</span>${count} doctor${count===1?"":"s"}</div>
      </div>
    </div>
    ${ratingBadge}
  </div>`;
}
function ambulanceCard(a,compact){
  if(compact){
    return `
    <div class="amb-card compact">
      <div class="amb-top">
        <div class="amb-ico">🚑</div>
        <div class="amb-info">
          <div class="amb-name">${esc(a.name)}</div>
          <div class="amb-city">${esc(a.city||"")}${a.area?", "+esc(a.area):""}</div>
        </div>
      </div>
      <div class="amb-btns">
        <a class="b-call" href="tel:${esc(a.phone)}">📞 ${esc(a.phone)}</a>
      </div>
    </div>`;
  }
  return `
  <div class="amb-card">
    <div class="amb-top">
      <div class="amb-ico">🚑</div>
      <div class="amb-info">
        <div class="amb-name">${esc(a.name)} ${a.rating?`<span style="font-size:12px;color:#F59E0B">⭐${a.rating.toFixed(1)}</span>`:""}</div>
        <div class="amb-city">${esc(a.city||"")}${a.area?", "+esc(a.area):""} · ${a.available!==false?'<span class="badge badge-success">Available</span>':'<span class="badge badge-gray">Off duty</span>'}</div>
      </div>
    </div>
    <div class="amb-row"><span>☎ Phone</span><strong>${esc(a.phone)}</strong></div>
    <div class="amb-row"><span>🏷 Type</span><span>${esc(a.type||"Ambulance")}</span></div>
    <div class="amb-btns">
      <a class="b-call" href="tel:${esc(a.phone)}">📞 Call now</a>
      ${a.mapLink?`<a class="b-map" href="${esc(a.mapLink)}" target="_blank" rel="noopener">📍 Map</a>`:""}
    </div>
    ${state.user?`<button class="b-sec" style="width:100%;margin-top:4px" onclick="showRatingModal('ambulance','${a.id}','${esc(a.name)}')">⭐ Rate This Service</button>`:""}
  </div>`;
}
/* Homepage emergency ambulance card for the horizontal carousel.
   Shows: profile picture, name, location, type, rating, and a call button with the number. */
function ambulanceCardHome(a){
  const photo=a.photo?`background-image:url('${esc(a.photo)}')`:"";
  const rating=parseFloat(a.rating||0);
  const ratingBadge=rating>0
    ?`<span class="ach-rating">⭐ ${rating.toFixed(1)}</span>`
    :`<span class="ach-rating no-rating">☆ ${t("ambNoRating")}</span>`;
  const location=[a.area,a.city].filter(Boolean).join(", ");
  const statusBadge=a.available!==false
    ?`<span class="ach-status avail">● ${t("ambAvailable")}</span>`
    :`<span class="ach-status off">● ${t("ambOffDuty")}</span>`;
  return `
  <div class="amb-slide">
    <div class="amb-card-h">
      <div class="ach-photo" style="${photo}">${a.photo?"":"🚑"}</div>
      <div class="ach-body">
        <div class="ach-top">
          <div class="ach-name">${esc(a.name)}</div>
          ${ratingBadge}
        </div>
        ${location?`<div class="ach-loc">📍 ${esc(location)}</div>`:""}
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <span class="ach-type">🚑 ${esc(a.type||"Ambulance")}</span>
          ${statusBadge}
        </div>
        <a class="ach-call" href="tel:${esc(a.phone)}">
          <span>${t("ambCallNow")}</span>
          <span class="num">${esc(a.phone)}</span>
        </a>
      </div>
    </div>
  </div>`;
}
function articleCard(a){
  const cover=a.coverImage?`background-image:url('${esc(a.coverImage)}')`:"";
  return `
  <div class="art-card" onclick="navigate('/articles/${a.id}')">
    <div class="art-cover" style="${cover}">${a.coverImage?"":"📰"}</div>
    <div class="art-body">
      <div class="art-cat">${esc(a.category||"Health")}</div>
      <div class="art-title">${esc(a.title)}</div>
      <div class="art-meta">${a.readTime||3} min read</div>
    </div>
  </div>`;
}

/* ===================================================================
   DOCTORS list + detail
   =================================================================== */
async function viewDoctors(){
  mount(loadingView());
  const [docs,cats]=await Promise.all([api("/api/doctors"+location.hash.replace(/^#\/doctors/,"")),api("/api/categories")]);
  let list=docs.data?.doctors||[];
  const catsArr=cats.data?.categories||[];
  const sp=qs("specialty")||""; const q=qs("q")||""; const ct=qs("city")||"";
  const near=qs("near")||"";
  // If "near" param, filter doctors by that city (partial match)
  if(near && near!=="My Location"){
    const nearLower=near.toLowerCase();
    list=list.filter(d=>d.city && (d.city.toLowerCase()===nearLower || d.city.toLowerCase().includes(nearLower) || nearLower.includes(d.city.toLowerCase())));
  }
  const cities=[...new Set(list.map(d=>d.city).filter(Boolean))].sort();
  const heading = near ? `Doctors near ${near}` : "Find a Doctor";
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>${esc(heading)}</h1><p>${list.length} verified specialists ${near?"near you":"available"}.</p></div>
  <div class="chips-row" id="fChips">
    <button class="chip ${!sp?"active":""}" onclick="setFilter('specialty','')">📋 All</button>
    ${catsArr.map(c=>`<button class="chip ${c.name===sp?"active":""}" onclick="setFilter('specialty','${esc(c.name)}')"><span class="c-ico">${catIcon(c.name)}</span>${esc(state.lang==="bn"&&c.bn?c.bn:c.name)}</button>`).join("")}
  </div>
  <div class="toolbar">
    <input class="search-input" id="fQ" placeholder="Search name…" value="${esc(q)}" onkeydown="if(event.key==='Enter')doctorsFilter()">
    <select id="fCity" onchange="doctorsFilter()"><option value="">All cities</option>${cities.map(c=>`<option value="${esc(c)}" ${c===ct?"selected":""}>${esc(c)}</option>`).join("")}</select>
  </div>
  <div class="filter-bar" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px;align-items:center">
    <span style="font-size:12px;font-weight:600;color:var(--muted);margin-right:4px">💵 Fee:</span>
    <select id="fFee" onchange="doctorsFilter()" style="height:36px;padding:0 10px;border:1px solid var(--line);border-radius:var(--radius-pill);font-size:12px;background:var(--surface);color:var(--text-2)">
      <option value="">Any fee</option>
      <option value="0-300">৳0 - ৳300</option>
      <option value="301-500">৳301 - ৳500</option>
      <option value="501-800">৳501 - ৳800</option>
      <option value="801-9999">৳800+</option>
    </select>
    <span style="font-size:12px;font-weight:600;color:var(--muted);margin-left:6px;margin-right:4px">⭐ Rating:</span>
    <select id="fRating" onchange="doctorsFilter()" style="height:36px;padding:0 10px;border:1px solid var(--line);border-radius:var(--radius-pill);font-size:12px;background:var(--surface);color:var(--text-2)">
      <option value="">Any rating</option>
      <option value="4">⭐ 4+ & up</option>
      <option value="3">⭐ 3+ & up</option>
      <option value="2">⭐ 2+ & up</option>
    </select>
    <label style="display:flex;align-items:center;gap:4px;font-size:12px;font-weight:600;color:var(--text-2);margin-left:6px;cursor:pointer">
      <input type="checkbox" id="fEmergency" onchange="doctorsFilter()" style="width:16px;height:16px"> 🚑 24/7
    </label>
  </div>
  <div id="docList">${list.length?list.map(doctorCard).join(""):emptyState("No doctors found","Try a different search.")}</div>
  `;
  mount(inner,()=>{window.__docs=list;window.__allDoctors=list;});
}
window.setFilter=function(key,val){
  const parts=pathParts(); const params=new URLSearchParams();
  if(key==="specialty"&&val) params.set("specialty",val);
  else if(qs("specialty")&&key!=="specialty") params.set("specialty",qs("specialty"));
  if(qs("q")&&key!=="specialty") params.set("q",qs("q"));
  if(qs("city")&&key!=="specialty") params.set("city",qs("city"));
  const s=params.toString();
  navigate("/doctors"+(s?"?"+s:""));
};
window.doctorsFilter=function(){
  const q=$("#fQ").value.trim();
  const ct=$("#fCity").value;
  const feeVal=$("#fFee")?$("#fFee").value:"";
  const ratingVal=$("#fRating")?$("#fRating").value:"";
  const emergency=$("#fEmergency")?$("#fEmergency").checked:false;
  let list=window.__docs||[];
  if(q) list=list.filter(d=>(d.name+" "+d.specialty+" "+d.qualifications).toLowerCase().includes(q.toLowerCase()));
  if(ct) list=list.filter(d=>d.city===ct);
  if(feeVal){
    const [min,max]=feeVal.split("-").map(Number);
    list=list.filter(d=>(d.fee||0)>=min && (d.fee||0)<=max);
  }
  if(ratingVal){
    const minRating=Number(ratingVal);
    list=list.filter(d=>(d.rating||0)>=minRating);
  }
  if(emergency){
    list=list.filter(d=>d.hours && (d.hours.toLowerCase().includes("24/7")||d.hours.toLowerCase().includes("24-7")||d.hours.toLowerCase().includes("emergency")));
  }
  $("#docList").innerHTML=list.length?list.map(doctorCard).join(""):emptyState("No doctors found","Try another search.");
};

async function viewDoctorDetail(id){
  mount(loadingView());
  const {data,error}=await api(`/api/doctors/${id}`);
  if(error){mount(`${emptyState("Doctor not found",error)}<a class="btn btn-primary" href="#/doctors">Back to doctors</a>`);return;}
  const d=data.doctor;
  const ytId=ytEmbedId(d.youtubeUrl);
  const avatarStyle=d.photo?`style="background-image:url('${esc(d.photo)}')"`:"";
  const inner=`
  <div class="page-head"><a class="back-link" href="#/doctors">← Back to doctors</a></div>
  <div class="doc-hero">
    <div class="dh-avatar" ${avatarStyle}>${d.photo?"":esc(initials(d.name))}</div>
    <h1>${esc(d.name)}</h1>
    <div class="dh-sub">${esc(d.specialty)}</div>
    <div class="dh-badges">
      ${d.hospital?`<span class="b">🏥 ${esc(d.hospital.name)}</span>`:""}
      ${d.city?`<span class="b">📍 ${esc(d.city)}</span>`:""}
    </div>
  </div>
  <div class="doc-stats">
    <div class="doc-stat"><div class="v">${d.experience||0}</div><div class="l">Years Exp</div></div>
    <div class="doc-stat"><div class="v">${d.fee?`৳${d.fee}`:"Free"}</div><div class="l">Fee</div></div>
    <div class="doc-stat"><div class="v">${esc(d.qualifications?d.qualifications.split(",")[0]:"-")}</div><div class="l">Degree</div></div>
  </div>
  <div class="doc-contact-grid">
    <a class="btn btn-green" href="tel:${esc(d.phone)}">📞 Call</a>
    ${d.mapLink?`<a class="btn btn-ghost" href="${esc(d.mapLink)}" target="_blank" rel="noopener">📍 Directions</a>`:`<a class="btn btn-soft" href="#/doctors">← Back</a>`}
  </div>
  ${d.bio?`<div class="doc-section"><h3>👤 About</h3><div style="font-size:14px;line-height:1.6;color:var(--text-2)">${esc(d.bio)}</div></div>`:""}
  ${ytId?`<div class="doc-section"><h3>▶️ Video Introduction</h3><div class="doc-yt"><iframe src="https://www.youtube.com/embed/${esc(ytId)}" title="Doctor video" allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen></iframe></div></div>`:""}
  <div class="doc-section">
    <h3>⭐ Rating & Reviews</h3>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
      <span style="font-size:28px;font-weight:800;color:#F59E0B">${d.rating?d.rating.toFixed(1):'N/A'}</span>
      <span style="color:#F59E0B;font-size:18px">${'★'.repeat(Math.round(d.rating||0))}${'☆'.repeat(5-Math.round(d.rating||0))}</span>
    </div>
    ${state.user?`<button class="btn btn-soft btn-block" onclick="showRatingModal('doctor','${d.id}','${esc(d.name)}')">⭐ Rate This Doctor</button>`:`<a class="btn btn-ghost btn-block" href="#/login">Sign in to rate</a>`}
  </div>
  <div class="doc-section">
    <h3>📋 Chamber & Contact</h3>
    <div class="doc-info-line"><span class="ico">☎</span><div><div class="lbl">Phone</div><div class="val"><a href="tel:${esc(d.phone)}" style="color:var(--primary-2)">${esc(d.phone)}</a></div></div></div>
    ${d.email?`<div class="doc-info-line"><span class="ico">✉</span><div><div class="lbl">Email</div><div class="val">${esc(d.email)}</div></div></div>`:""}
    <div class="doc-info-line"><span class="ico">📍</span><div><div class="lbl">Address</div><div class="val">${esc(d.address)}, ${esc(d.city)}</div></div></div>
    <div class="doc-info-line"><span class="ico">🕒</span><div><div class="lbl">Chamber Hours</div><div class="val">${esc(d.hours)}</div></div></div>
    ${d.qualifications?`<div class="doc-info-line"><span class="ico">🎓</span><div><div class="lbl">Qualifications</div><div class="val">${esc(d.qualifications)}</div></div></div>`:""}
  </div>
  ${d.mapLink?`<div class="doc-section"><h3>📍 Location on Map</h3><div class="doc-yt"><iframe src="${esc(gMapsEmbedUrl(d.mapLink))}" style="border:0" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div><a href="${esc(d.mapLink)}" target="_blank" rel="noopener" class="btn btn-ghost btn-block" style="margin-top:8px">Open in Google Maps ↗</a></div>`:""}
  `;
  mount(inner);
}
function ytEmbedId(url){
  if(!url) return null;
  const m=String(url).match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/);
  return m?m[1]:null;
}
/* Convert any Google Maps URL into an embeddable iframe src.
   Handles /maps?q=, /maps/place/, /maps/search/, ?q=coords, and plain search. */
function gMapsEmbedUrl(url){
  const u=String(url||"");
  // Already an embed URL
  if(u.includes("/maps/embed")) return u;
  // Extract query or coordinates
  let q="";
  const qm=u.match(/[?&]q=([^&]+)/);
  if(qm) q=decodeURIComponent(qm[1]);
  if(!q){
    const place=u.match(/\/maps\/place\/([^/]+)/);
    if(place) q=decodeURIComponent(place[1].replace(/\+/g," "));
  }
  if(!q){
    const search=u.match(/\/maps\/search\/([^/?]+)/);
    if(search) q=decodeURIComponent(search[1].replace(/\+/g," "));
  }
  if(!q){
    const coords=u.match(/@(-?[\d.]+),(-?[\d.]+)/);
    if(coords) q=coords[1]+","+coords[2];
  }
  if(!q) q=u; // fallback: use whole URL as query
  return "https://maps.google.com/maps?q="+encodeURIComponent(q)+"&output=embed";
}

/* ===================================================================
   HOSPITALS
   =================================================================== */
async function viewHospitals(){
  mount(loadingView());
  const {data}=await api("/api/hospitals"+location.hash.replace(/^#\/hospitals/,""));
  const list=data?.hospitals||[];
  const q=qs("q")||"";
  const cities=[...new Set(list.map(h=>h.city).filter(Boolean))].sort();
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>Hospitals & Clinics</h1><p>${list.length} healthcare facilities.</p></div>
  <div class="toolbar">
    <input class="search-input" id="hQ" placeholder="Search hospitals…" value="${esc(q)}" onkeydown="if(event.key==='Enter')hospFilter()">
    <select id="hCity" onchange="hospFilter()"><option value="">All cities</option>${cities.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join("")}</select>
  </div>
  <div id="hospList">${list.length?list.map(hospitalCard).join(""):emptyState("No hospitals found","Try another search.")}</div>
  `;
  mount(inner,()=>{window.__hosps=list;});
}
window.hospFilter=function(){
  const q=$("#hQ").value.trim(); const ct=$("#hCity").value;
  let list=window.__hosps||[];
  if(q) list=list.filter(h=>(h.name+" "+h.address+" "+h.city).toLowerCase().includes(q.toLowerCase()));
  if(ct) list=list.filter(h=>h.city===ct);
  $("#hospList").innerHTML=list.length?list.map(hospitalCard).join(""):emptyState("No hospitals found","Try another search.");
};

async function viewHospitalDetail(id){
  mount(loadingView());
  const {data,error}=await api(`/api/hospitals/${id}`);
  if(error){mount(`${emptyState("Hospital not found",error)}`);return;}
  const h=data.hospital; const docs=h.doctors||[];
  const rating=parseFloat(h.rating||0);
  const docCount=docs.length;
  const inner=`
  <div class="page-head"><a class="back-link" href="#/hospitals">← Back to hospitals</a></div>
  <div class="detail-head">
    <div class="detail-avatar">${h.photo?`<img src="${esc(h.photo)}" alt="${esc(h.name)}" style="width:100%;height:100%;border-radius:50%;object-fit:cover">`:"🏥"}</div>
    <div><h1 class="detail-title">${esc(h.name)}</h1><div class="detail-sub">${esc(h.city)}</div></div>
    <!-- Hospital profile info shown directly under the profile picture -->
    <div class="hosp-profile-under">
      <div class="hosp-profile-rating">
        <span class="hpr-num">${rating>0?rating.toFixed(1):'N/A'}</span>
        <span class="hpr-stars">${rating>0?'★'.repeat(Math.round(rating))+'☆'.repeat(5-Math.round(rating)):'☆☆☆☆☆'}</span>
        <span class="hpr-label">${rating>0?(state.lang==="bn"?"রেটিং":"Rating"):(state.lang==="bn"?"এখনো রেটিং নেই":"Not rated yet")}</span>
      </div>
      <div class="hosp-profile-chips">
        ${h.address?`<span class="hpc">📍 ${esc(h.address)}</span>`:""}
        <span class="hpc">🩺 ${docCount} ${state.lang==="bn"?"জন ডাক্তার":(docCount===1?"doctor":"doctors")}</span>
        ${h.phone?`<span class="hpc">☎ ${esc(h.phone)}</span>`:""}
      </div>
    </div>
  </div>
  <div class="detail-actions">
    <a class="btn btn-green" href="tel:${esc(h.phone)}">📞 ${t("call")}</a>
    ${h.mapLink?`<a class="btn btn-ghost" href="${esc(h.mapLink)}" target="_blank" rel="noopener">📍 ${t("directions")}</a>`:""}
  </div>
  <div class="info-card">
    <div class="info-row"><span class="lbl">${state.lang==="bn"?"ঠিকানা":"Address"}</span><span class="val">${esc(h.address)}</span></div>
    <div class="info-row"><span class="lbl">${state.lang==="bn"?"ফোন":"Phone"}</span><span class="val"><a href="tel:${esc(h.phone)}" style="color:var(--primary-2);font-weight:600">${esc(h.phone)}</a></span></div>
    ${h.web?`<div class="info-row"><span class="lbl">${state.lang==="bn"?"ওয়েবসাইট":"Website"}</span><span class="val"><a href="${esc(h.web)}" target="_blank" rel="noopener" style="color:var(--primary-2)">${esc(h.web)}</a></span></div>`:""}
  </div>
  <div class="doc-section">
    <h3>${t("ratingReviews")}</h3>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
      <span style="font-size:28px;font-weight:800;color:#F59E0B">${rating>0?rating.toFixed(1):'N/A'}</span>
      <span style="color:#F59E0B;font-size:18px">${rating>0?'★'.repeat(Math.round(rating))+'☆'.repeat(5-Math.round(rating)):'☆☆☆☆☆'}</span>
    </div>
    ${state.user?`<button class="btn btn-soft btn-block" onclick="showRatingModal('hospital','${h.id}','${esc(h.name)}')">⭐ ${state.lang==="bn"?"এই হাসপাতাল রেট করুন":"Rate This Hospital"}</button>`:`<a class="btn btn-ghost btn-block" href="#/login">${state.lang==="bn"?"রেট করতে সাইন ইন করুন":"Sign in to rate"}</a>`}
  </div>
  <section class="section">
    <div class="section-head"><h2>${t("doctorsAtHosp")}</h2></div>
    <div>${docs.length?docs.map(doctorCard).join(""):emptyState(state.lang==="bn"?"এখনো কোনো ডাক্তার নেই":"No doctors listed yet",state.lang==="bn"?"পরে আবার দেখুন":"Check back later.")}</div>
  </section>
  `;
  mount(inner);
}

/* ===================================================================
   AMBULANCES
   =================================================================== */
async function viewAmbulances(){
  mount(loadingView());
  const {data}=await api("/api/ambulances");
  const list=data?.ambulances||[];
  const cities=[...new Set(list.map(a=>a.city).filter(Boolean))].sort();
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>${t("ambulanceServices")}</h1><p>${list.length} ${t("ambulanceProviders")}</p></div>
  <div class="toolbar">
    <input class="search-input" id="aQ" placeholder="Search by name or area…" onkeydown="if(event.key==='Enter')ambFilter()">
    <select id="aCity" onchange="ambFilter()"><option value="">All cities</option>${cities.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join("")}</select>
  </div>
  <div id="ambList" class="amb-grid-2col">${list.length?list.map(ambulanceCard2Col).join(""):emptyState("No ambulances listed","Check back later.")}</div>
  `;
  mount(inner,()=>{window.__ambs=list;});
}
function ambulanceCard2Col(a){
  const rating=parseFloat(a.rating||0);
  const ratingBadge=rating>0?`<span class="ach-rating">⭐ ${rating.toFixed(1)}</span>`:`<span class="ach-rating no-rating">☆ N/A</span>`;
  const location=[a.area,a.city].filter(Boolean).join(", ");
  const statusBadge=a.available!==false?`<span class="ach-status avail">● Available</span>`:`<span class="ach-status off">● Off duty</span>`;
  const photo=a.photo?`background-image:url('${esc(a.photo)}')`:"";
  return `
  <div class="amb-card-2col">
    <div class="amb2-photo" style="${photo}">${a.photo?"":"🚑"}</div>
    <div class="amb2-body">
      <div class="amb2-top">
        <div class="amb2-name">${esc(a.name)}</div>
        ${ratingBadge}
      </div>
      ${location?`<div class="amb2-loc">📍 ${esc(location)}</div>`:""}
      <div class="amb2-meta">
        <span class="amb2-type">🚑 ${esc(a.type||"Ambulance")}</span>
        ${statusBadge}
      </div>
      <div class="amb2-phone">☎ ${esc(a.phone)}</div>
      <a class="amb2-call" href="tel:${esc(a.phone)}">📞 ${t("ambCallNow")}</a>
      ${state.user?`<button class="amb2-rate" onclick="showRatingModal('ambulance','${a.id}','${esc(a.name)}')">⭐ Rate</button>`:""}
    </div>
  </div>`;
}
window.ambFilter=function(){
  const q=$("#aQ").value.trim(); const ct=$("#aCity").value;
  let list=window.__ambs||[];
  if(q) list=list.filter(a=>(a.name+" "+a.area+" "+a.city).toLowerCase().includes(q.toLowerCase()));
  if(ct) list=list.filter(a=>a.city===ct);
  $("#ambList").innerHTML=list.length?list.map(ambulanceCard2Col).join(""):emptyState("No ambulances found","Try another search.");
};

/* ===================================================================
   ARTICLES
   =================================================================== */
async function viewArticles(){
  mount(loadingView());
  const {data}=await api("/api/articles");
  const list=data?.articles||[];
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>${t("healthArticlesTitle")}</h1><p>${t("expertTips")}</p></div>
  <div class="art-grid">${list.length?list.map(articleCard).join(""):emptyState("No articles yet","Check back soon.")}</div>
  `;
  mount(inner);
}
async function viewArticleDetail(id){
  mount(loadingView());
  const {data,error}=await api(`/api/articles/${id}`);
  if(error){mount(`${emptyState("Article not found",error)}`);return;}
  const a=data.article;
  const cover=a.coverImage?`background-image:url('${esc(a.coverImage)}')`:"";
  const inner=`
  <div class="page-head"><a class="back-link" href="#/articles">← Back to articles</a></div>
  <article class="art-content">
    ${a.coverImage?`<div class="cover" style="${cover}"></div>`:""}
    <div class="badge badge-primary" style="margin-bottom:8px">${esc(a.category||"Health")}</div>
    <h1>${esc(a.title)}</h1>
    <div class="art-byline">By ${esc(a.author||"Doctor App")} · ${fmtDate(a.createdAt)} · ${a.readTime||3} min read</div>
    <div class="art-body-text">${esc(a.content)}</div>
  </article>
  `;
  mount(inner);
}

/* ===================================================================
   AUTH (login / register / forgot / reset)
   =================================================================== */
function viewLogin(){
  
  const inner=`
  <div class="auth-page">
    <div class="auth-logo"><img src="/icon-192.png" alt="Doctor App" style="width:100%;height:100%;object-fit:cover;border-radius:18px"/></div>
    <h1 class="auth-title">Welcome back</h1>
    <p class="auth-sub">Sign in to your Doctor App account</p>
    <div class="auth-card">
      <div id="loginAlert"></div>
      <form id="loginForm">
        <div class="field"><label>Email or username</label><input id="identifier" required placeholder="you@example.com" autocomplete="username"></div>
        <div class="field"><label>Password</label>
          <div class="password-wrap"><input id="password" type="password" required placeholder="••••••••" autocomplete="current-password"><button type="button" class="toggle" onclick="togglePw('password','loginPwToggle')" id="loginPwToggle">Show</button></div>
        </div>
        <div style="text-align:right;margin:-6px 0 14px"><a class="btn-link" href="#/forgot" style="font-size:13px">Forgot password?</a></div>
        <button class="btn btn-primary btn-block" type="submit">Sign in</button>
      </form>
      <div class="auth-foot">Don't have an account? <a href="#/register">Sign up</a></div>
    </div>
  </div>`;
  mount(inner,()=>{
    $("#loginForm").addEventListener("submit",async(e)=>{
      e.preventDefault();
      const identifier=$("#identifier").value.trim(); const password=$("#password").value;
      const btn=e.target.querySelector("button[type=submit]"); btn.disabled=true; btn.textContent="Signing in…";
      const {data,error}=await api("/api/auth/login",{method:"POST",body:{identifier,password}});
      btn.disabled=false; btn.textContent="Sign in";
      if(error){$("#loginAlert").innerHTML=`<div class="alert alert-error">${esc(error)}</div>`;return;}
      await loadMe(); toast("Logged in successfully","success");
      if(isAdmin()) navigate("/admin");
      else if(isDoctor()) navigate("/doctor-profile");
      else navigate("/");
      render();
    });
  });
}

function viewRegister(){
  
  const inner=`
  <div class="auth-page">
    <div class="auth-logo"><img src="/icon-192.png" alt="Doctor App" style="width:100%;height:100%;object-fit:cover;border-radius:18px"/></div>
    <h1 class="auth-title">Create account</h1>
    <p class="auth-sub">Join Doctor App to manage your health</p>
    <div class="auth-card">
      <div id="regAlert"></div>
      <form id="regForm">
        <div class="field"><label>Email</label><input id="email" type="email" required placeholder="you@example.com" autocomplete="email"></div>
        <div class="form-row">
          <div class="field"><label>Username</label><input id="username" required placeholder="johndoe" autocomplete="username"></div>
          <div class="field"><label>Password</label>
            <div class="password-wrap"><input id="password" type="password" required placeholder="min 6 chars" autocomplete="new-password"><button type="button" class="toggle" onclick="togglePw('password','regPwToggle')" id="regPwToggle">Show</button></div>
          </div>
        </div>
        <div class="field"><label>Register as</label>
          <select id="role">
            <option value="USER">Patient (User)</option>
            <option value="DOCTOR">Doctor (needs approval)</option>
            <option value="ADMIN">Admin (needs approval)</option>
          </select>
        </div>
        <div class="field" id="hospitalField" style="display:none"><label>Hospital *</label><select id="hospitalId"><option value="">Select hospital…</option></select><div class="hint">Required for doctor registration — hospitals are added by admins</div></div>
        <button class="btn btn-primary btn-block" type="submit">Create account</button>
      </form>
      <div class="auth-foot">Already have an account? <a href="#/login">Sign in</a></div>
    </div>
  </div>`;
  mount(inner,async()=>{
    const {data}=await api("/api/hospitals");
    const sel=$("#hospitalId");
    (data?.hospitals||[]).forEach(h=>{const o=document.createElement("option");o.value=h.id;o.textContent=h.name+" — "+h.city;sel.appendChild(o);});
    $("#role").addEventListener("change",e=>{$("#hospitalField").style.display=e.target.value==="DOCTOR"?"block":"none";});
    $("#regForm").addEventListener("submit",async(e)=>{
      e.preventDefault();
      const role=$("#role").value;
      const hospitalId=$("#hospitalId").value;
      if(role==="DOCTOR"&&!hospitalId){
        $("#regAlert").innerHTML=`<div class="alert alert-error">Please select your hospital to register as a doctor.</div>`;
        return;
      }
      const body={email:$("#email").value.trim(),username:$("#username").value.trim(),password:$("#password").value,role,hospitalId:hospitalId||undefined};
      const btn=e.target.querySelector("button[type=submit]"); btn.disabled=true; btn.textContent="Creating…";
      const {data:d,error}=await api("/api/auth/register",{method:"POST",body});
      btn.disabled=false; btn.textContent="Create account";
      if(error){$("#regAlert").innerHTML=`<div class="alert alert-error">${esc(error)}</div>`;return;}
      await loadMe();
      if(d.needsApproval){
        toast("Account created! Pending approval by Super Admin.","warn");
        navigate(d.requestedRole==="DOCTOR"?"/doctor-profile":"/admin");
      }
      else{toast("Welcome to Doctor App!","success");navigate("/");}
      render();
    });
  });
}

function viewForgot(){
  
  const inner=`
  <div class="auth-page">
    <div class="auth-logo"><img src="/icon-192.png" alt="Doctor App" style="width:100%;height:100%;object-fit:cover;border-radius:18px"/></div>
    <h1 class="auth-title">Reset password</h1>
    <p class="auth-sub">Enter your email or username to get a reset token.</p>
    <div class="auth-card">
      <div id="fgAlert"></div>
      <form id="fgForm">
        <div class="field"><label>Email or username</label><input id="identifier" required placeholder="you@example.com"></div>
        <button class="btn btn-primary btn-block" type="submit">Send reset token</button>
      </form>
      <div class="auth-foot"><a href="#/login">← Back to sign in</a></div>
    </div>
  </div>`;
  mount(inner,()=>{
    $("#fgForm").addEventListener("submit",async(e)=>{
      e.preventDefault();
      const identifier=$("#identifier").value.trim();
      const btn=e.target.querySelector("button[type=submit]"); btn.disabled=true;
      const {data,error}=await api("/api/auth/forgot-password",{method:"POST",body:{identifier}});
      btn.disabled=false;
      if(error){$("#fgAlert").innerHTML=`<div class="alert alert-error">${esc(error)}</div>`;return;}
      if(data.found&&data.token){
        $("#fgAlert").innerHTML=`<div class="alert alert-success">Account found! Your reset token is:<br><strong style="word-break:break-all">${esc(data.token)}</strong><br><a class="btn btn-primary btn-block" style="margin-top:10px" href="#/reset?token=${encodeURIComponent(data.token)}">Continue to reset</a></div>`;
      }else{$("#fgAlert").innerHTML=`<div class="alert alert-success">${esc(data.message)}</div>`;}
    });
  });
}

function viewReset(){
  const token=qs("token")||"";
  const inner=`
  <div class="auth-page">
    <div class="auth-logo"><img src="/icon-192.png" alt="Doctor App" style="width:100%;height:100%;object-fit:cover;border-radius:18px"/></div>
    <h1 class="auth-title">Set new password</h1>
    <p class="auth-sub">Enter your reset token and a new password.</p>
    <div class="auth-card">
      <div id="rsAlert"></div>
      <form id="rsForm">
        <div class="field"><label>Reset token</label><input id="token" required value="${esc(token)}" placeholder="paste token here"></div>
        <div class="field"><label>New password</label>
          <div class="password-wrap"><input id="newPassword" type="password" required placeholder="min 6 chars"><button type="button" class="toggle" onclick="togglePw('newPassword','rsPwToggle')" id="rsPwToggle">Show</button></div>
        </div>
        <button class="btn btn-primary btn-block" type="submit">Reset password</button>
      </form>
      <div class="auth-foot"><a href="#/login">← Back to sign in</a></div>
    </div>
  </div>`;
  mount(inner,()=>{
    $("#rsForm").addEventListener("submit",async(e)=>{
      e.preventDefault();
      const body={token:$("#token").value.trim(),newPassword:$("#newPassword").value};
      const btn=e.target.querySelector("button[type=submit]"); btn.disabled=true;
      const {data,error}=await api("/api/auth/reset-password",{method:"POST",body});
      btn.disabled=false;
      if(error){$("#rsAlert").innerHTML=`<div class="alert alert-error">${esc(error)}</div>`;return;}
      $("#rsAlert").innerHTML=`<div class="alert alert-success">${esc(data.message)}</div>`;
      toast("Password reset! You can sign in.","success");
      setTimeout(()=>navigate("/login"),1500);
    });
  });
}
window.togglePw=function(id,toggleId){
  const inp=$("#"+id); const tg=$("#"+toggleId);
  if(inp.type==="password"){inp.type="text";tg.textContent="Hide";}
  else{inp.type="password";tg.textContent="Show";}
};

/* ===================================================================
   DOCTOR PROFILE (own)
   =================================================================== */
async function viewDoctorProfile(){
  if(!state.user||state.user.role!=="DOCTOR"){
    mount(`${emptyState("Access denied","Only doctor accounts can access this page.")}<div style="text-align:center;margin-top:12px"><a class="btn btn-primary" href="#/login">Sign in</a></div>`);return;
  }
  mount(loadingView());
  const {data,error}=await api("/api/doctor/profile");
  if(error){mount(`${emptyState("Error",error)}`);return;}
  const p=data.profile||{};
  const {data:hospData}=await api("/api/hospitals");
  const hospitals=hospData?.hospitals||[];
  const {data:catData}=await api("/api/categories");
  const categories=catData?.categories||[];
  const {data:cityData}=await api("/api/cities");
  const cities=cityData?.cities||[];
  const hospName = hospitals.find(h=>h.id===p.hospitalId)?.name || "";
  const avatarStyle = p.photo ? `style="background-image:url('${esc(p.photo)}')"` : "";
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>My Doctor Profile</h1><p>This appears in the public directory.</p></div>
  ${state.needsApproval?`<div class="alert alert-warn">⏳ Your account is pending approval by a Super Admin. You can complete your profile meanwhile.</div>`:""}
  <div id="dpAlert"></div>
  <div class="dp-hero" id="dpHero">
    <div class="dp-avatar" id="dpAvatar" ${avatarStyle}>${p.photo?"":esc(initials(p.name||state.user.username))}</div>
    <h2 id="dpName">${esc(p.name||"Your Name")}</h2>
    <div class="dp-sp" id="dpSp">${esc(p.specialty||"Your Specialty")}</div>
    <div class="dp-badges" id="dpBadges">
      ${hospName?`<span class="b">🏥 ${esc(hospName)}</span>`:""}
      ${p.city?`<span class="b">📍 ${esc(p.city)}</span>`:""}
      ${p.experience?`<span class="b">⏱ ${esc(p.experience)} yrs</span>`:""}
    </div>
  </div>
  <div class="dp-stats">
    <div class="dp-stat"><div class="v" id="dpStatExp">${p.experience||0}</div><div class="l">Years Exp</div></div>
    <div class="dp-stat"><div class="v" id="dpStatFee">${p.fee?`৳${p.fee}`:"Free"}</div><div class="l">Fee</div></div>
    <div class="dp-stat"><div class="v" id="dpStatDeg">${esc(p.qualifications?p.qualifications.split(",")[0]:"-")}</div><div class="l">Degree</div></div>
  </div>
  <div class="form-card">
    <form id="dpForm">
      <div class="form-section-title">👤 Personal Info</div>
      <div class="form-row"><div class="field"><label>Full name *</label><input id="name" required value="${esc(p.name||"")}" placeholder="Dr. John Doe"></div><div class="field"><label>Specialty *</label><select id="specialty" required><option value="">Select…</option>${categories.map(c=>`<option value="${esc(c.name)}" ${p.specialty===c.name?"selected":""}>${esc(c.name)}</option>`).join("")}</select></div></div>
      <div class="form-row"><div class="field"><label>Qualifications *</label><input id="qualifications" required value="${esc(p.qualifications||"")}" placeholder="MBBS, FCPS"></div><div class="field"><label>Experience (yrs)</label><input id="experience" type="number" min="0" value="${p.experience??0}"></div></div>
      <div class="field"><label>Bio</label><textarea id="bio" placeholder="Short biography">${esc(p.bio||"")}</textarea></div>

      <div class="form-section-title">🏥 Hospital & Location</div>
      <div class="field"><label>Hospital *</label><select id="hospitalId" required><option value="">Select hospital…</option>${hospitals.map(h=>`<option value="${h.id}" ${p.hospitalId===h.id?"selected":""}>${esc(h.name)} — ${esc(h.city)}</option>`).join("")}</select><div class="hint">Hospitals are added by admins</div></div>
      <div class="form-row"><div class="field"><label>City *</label><select id="city" required><option value="">Select…</option>${cities.map(c=>`<option value="${esc(c.name)}" ${p.city===c.name?"selected":""}>${esc(c.name)}</option>`).join("")}</select></div><div class="field"><label>Address *</label><input id="address" required value="${esc(p.address||"")}"></div></div>
      <div class="field"><label>Chamber hours *</label><input id="hours" required value="${esc(p.hours||"")}" placeholder="Sat-Thu, 10am - 4pm"></div>

      <div class="form-section-title">📞 Contact & Fee</div>
      <div class="form-row"><div class="field"><label>Fee (৳)</label><input id="fee" type="number" min="0" value="${p.fee??0}"></div><div class="field"><label>Phone *</label><input id="phone" type="tel" required value="${esc(p.phone||"")}" placeholder="+8801…"></div></div>
      <div class="field"><label>Email</label><input id="email" type="email" value="${esc(p.email||"")}"></div>

      <div class="form-section-title">📸 Media & Links</div>
      <div class="field"><label>Photo URL</label><input id="photo" value="${esc(p.photo||"")}" placeholder="https://…"></div>
      <div class="field"><label>Google Maps link</label><input id="mapLink" value="${esc(p.mapLink||"")}" placeholder="https://maps.google.com/…"><div class="hint"><a href="https://www.google.com/maps" target="_blank" rel="noopener" style="color:var(--primary-2);font-weight:600">Open Google Maps ↗</a> to find your location, then copy the share link here</div></div>
      <div class="field"><label>YouTube video URL</label><input id="youtubeUrl" value="${esc(p.youtubeUrl||"")}" placeholder="https://youtube.com/watch?v=..."><div class="hint">Paste a YouTube link — it will be embedded on your public profile</div></div>

      <div class="form-section-title">🔐 Security</div>
      <div class="field"><label>Change password</label><input id="password" type="password" placeholder="leave blank to keep current (min 6)"></div>
      <button class="btn btn-primary btn-block" type="submit" style="margin-top:6px">💾 Save profile</button>
    </form>
  </div>
  `;
  mount(inner,()=>{
    // Live preview updates
    const updatePreview=()=>{
      const nm=$("#name").value.trim()||"Your Name";
      const sp=$("#specialty").value.trim()||"Your Specialty";
      const ph=$("#photo").value.trim();
      const exp=$("#experience").value||0;
      const fee=$("#fee").value||0;
      const qual=$("#qualifications").value.trim().split(",")[0]||"-";
      const city=$("#city").value.trim();
      const hosp=$("#hospitalId");
      const hospTxt=hosp.options[hosp.selectedIndex]?.text.split(" — ")[0]||"";
      $("#dpName").textContent=nm;
      $("#dpSp").textContent=sp;
      const av=$("#dpAvatar");
      if(ph){av.style.backgroundImage=`url('${ph}')`;av.textContent="";}
      else{av.style.backgroundImage="";av.textContent=initials(nm);}
      $("#dpStatExp").textContent=exp;
      $("#dpStatFee").textContent=fee?`৳${fee}`:"Free";
      $("#dpStatDeg").textContent=qual;
      $("#dpBadges").innerHTML=`${hospTxt?`<span class="b">🏥 ${esc(hospTxt)}</span>`:""}${city?`<span class="b">📍 ${esc(city)}</span>`:""}${exp?`<span class="b">⏱ ${esc(exp)} yrs</span>`:""}`;
    };
    ["name","specialty","photo","experience","fee","qualifications","city","hospitalId"].forEach(id=>{
      const el=$("#"+id); if(el) el.addEventListener("input",updatePreview);
    });
    $("#dpForm").addEventListener("submit",async(e)=>{
      e.preventDefault();
      const body={name:$("#name").value.trim(),specialty:$("#specialty").value.trim(),qualifications:$("#qualifications").value.trim(),experience:Number($("#experience").value||0),fee:Number($("#fee").value||0),phone:$("#phone").value.trim(),email:$("#email").value.trim(),hospitalId:$("#hospitalId").value||null,city:$("#city").value.trim(),address:$("#address").value.trim(),hours:$("#hours").value.trim(),photo:$("#photo").value.trim()||null,mapLink:$("#mapLink").value.trim()||null,youtubeUrl:$("#youtubeUrl").value.trim()||null,bio:$("#bio").value.trim()||null,password:$("#password").value||undefined};
      const btn=e.target.querySelector("button[type=submit]"); btn.disabled=true; btn.textContent="Saving…";
      const {data,error}=await api("/api/doctor/profile",{method:"PUT",body});
      btn.disabled=false; btn.textContent="💾 Save profile";
      if(error){$("#dpAlert").innerHTML=`<div class="alert alert-error">${esc(error)}</div>`;return;}
      $("#dpAlert").innerHTML=`<div class="alert alert-success">${esc(data.message||"Saved.")}</div>`;
      toast("Profile saved","success"); await loadMe();
    });
  });
}

/* ===================================================================
   ADMIN DASHBOARD
   =================================================================== */
const ADMIN_TABS=[
  {key:"overview",label:"Overview",ico:"📊"},
  {key:"users",label:"Users",ico:"👥",superOnly:true},
  {key:"doctors",label:"Doctors",ico:"🩺"},
  {key:"hospitals",label:"Hospitals",ico:"🏥"},
  {key:"ambulances",label:"Ambulances",ico:"🚑"},
  {key:"cities",label:"Cities",ico:"📍",superOnly:true},
  {key:"articles",label:"Articles",ico:"📰",superOnly:true},
  {key:"categories",label:"Categories",ico:"🗂️",superOnly:true},
  {key:"slides",label:"Slides",ico:"🖼️",superOnly:true},
  {key:"blood",label:"Blood Donors",ico:"🩸",superOnly:true},
  {key:"settings",label:"Settings",ico:"⚙️",superOnly:true},
  {key:"profile",label:"My Profile",ico:"👤"},
];
function adminTab(){const parts=pathParts();return(parts[1]&&ADMIN_TABS.find(t=>t.key===parts[1]))?parts[1]:"overview";}

async function viewAdmin(){
  if(!state.user||!isAdmin()){
    mount(`${emptyState("Admin access required","Sign in with an admin account.")}<div style="text-align:center;margin-top:12px"><a class="btn btn-primary" href="#/login">Sign in</a></div>`);return;
  }
  let tab=adminTab();
  const tabDef=ADMIN_TABS.find(t=>t.key===tab);
  if(tabDef&&tabDef.superOnly&&!isSuperAdmin()){navigate("/admin/overview");return;}
  const tabs=ADMIN_TABS.filter(t=>!t.superOnly||isSuperAdmin());
  const u=state.user;
  const inner=`
  <div class="admin-shell">
    <div class="admin-hero">
      <div class="ah-avatar">${u.photo?`<img src="${esc(u.photo)}" style="width:100%;height:100%;border-radius:50%;object-fit:cover"/>`:esc(initials(u.name||u.username))}</div>
      <div class="ah-info"><div class="ah-title">${esc(u.name||u.username)}</div><div class="ah-sub">${esc(u.email)}</div></div>
      <div class="ah-badge">${esc(u.role)}</div>
    </div>
    <div class="admin-sidebar" id="adminSidebar">${tabs.map(t=>`<a class="admin-side-item ${tab===t.key?"active":""}" href="#/admin/${t.key}"><span class="si-ico">${t.ico}</span><span class="si-lbl">${esc(t.label)}</span></a>`).join("")}</div>
    <div id="adminContent">${loadingView()}</div>
  </div>
  <button class="admin-fab" onclick="adminFAB()" id="adminFab">+</button>
  `;
  // Use custom admin header with its own hamburger that opens admin drawer
  $("#app").innerHTML=`<div class="app-wrap">${adminHeader()}<main class="app-main">${inner}</main>${bottomNav()}</div>`;
  window.scrollTo(0,0);
  adminRender(tab);
}
function adminHeader(){
  const u=state.user;
  const unreadCount=state.notifs.filter(n=>!n.read).length;
  return `
  <header class="app-header">
    <div class="header-row">
      <button class="hamburger" onclick="openAdminDrawer()" aria-label="Menu"><span></span></button>
      <a class="brand" href="#/admin"><span class="logo"><img src="/icon-192.png" alt="Doctor App" style="width:100%;height:100%;object-fit:cover;border-radius:9px"/></span><span class="brand-info"><span class="brand-name">Admin Panel</span><span class="brand-slogan">${esc(u.role)}</span></span></a>
      <div class="header-btns">
        <button class="hbtn" onclick="toggleLang()" aria-label="Language">${state.lang==="en"?"বাং":"EN"}</button>
        <button class="hbtn" onclick="toggleTheme()" aria-label="Dark mode">${state.theme==="dark"?"☀️":"🌙"}</button>
        <button class="hbtn" onclick="openNotif()" aria-label="Notifications">🔔${unreadCount?`<span class="dot"></span>`:""}</button>
      </div>
    </div>
  </header>`;
}
function openAdminDrawer(){
  const d=$("#drawer");const b=$("#drawerBack");
  d.innerHTML=adminDrawerHtml();d.classList.add("open");b.classList.add("open");
}
window.openAdminDrawer=openAdminDrawer;
function adminDrawerHtml(){
  const u=state.user;
  const tabs=ADMIN_TABS.filter(t=>!t.superOnly||isSuperAdmin());
  const I={home:'<svg viewBox="0 0 24 24"><path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1V9.5z"/></svg>',logout:'<svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>',dashboard:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',profile:'<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>'};
  return `
    <div class="drawer-head">
      <div class="drawer-avatar">${u.photo?`<img src="${esc(u.photo)}" style="width:100%;height:100%;border-radius:50%;object-fit:cover"/>`:'<svg viewBox="0 0 24 24" style="width:26px;height:26px;stroke:var(--primary-2);stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>'}</div>
      <div class="drawer-head-info">
        <div class="uname">${esc(u.name||u.username)}</div>
        <div style="font-size:12px;color:var(--muted);margin-bottom:2px">${esc(u.email)}</div>
        <span class="badge badge-primary">${esc(u.role)}</span>
      </div>
      <button class="drawer-close" onclick="closeDrawer()" aria-label="Close">×</button>
    </div>
    <nav class="drawer-nav">
      <a href="#/admin" onclick="closeDrawer()"><span class="dico">${I.dashboard}</span>Admin Dashboard</a>
      ${tabs.filter(t=>t.key!=="overview"&&t.key!=="settings"&&t.key!=="profile").map(t=>`<a href="#/admin/${t.key}" class="${adminTab()===t.key?"active":""}" onclick="closeDrawer()"><span class="dico">${t.ico}</span>${esc(t.label)}</a>`).join("")}
      <div class="drawer-sep"></div>
      <a href="#/" onclick="closeDrawer()"><span class="dico">${I.home}</span>Back to Home</a>
      <div class="drawer-sep"></div>
      <a href="#/admin/profile" onclick="closeDrawer()"><span class="dico">${I.profile}</span>Profile</a>
      <button class="ditem" onclick="closeDrawer();logout()"><span class="dico">${I.logout}</span>Logout</button>
    </nav>
    <div class="drawer-foot">
      <div class="follow-label">Doctor App</div>
      <div class="version">❤️ Version 1.1.3<br>© 2026 Doctor App</div>
    </div>
  `;
}
function adminFAB(){
  const tab=adminTab();
  if(tab==="doctors")return doctorForm();
  if(tab==="hospitals")return hospitalForm();
  if(tab==="ambulances")return ambForm();
  if(tab==="articles")return artForm();
  if(tab==="categories")return catForm();
  if(tab==="slides")return slideForm();
  toast("Select a category to add items","info");
}
async function adminRender(tab){
  const c=$("#adminContent");if(!c)return;c.innerHTML=loadingView();
  const fab=$("#adminFab");if(fab)fab.style.display=["doctors","hospitals","ambulances","articles","categories","slides"].includes(tab)?"grid":"none";
  if(tab==="overview")return adminOverview(c);
  if(tab==="users")return adminUsers(c);
  if(tab==="doctors")return adminDoctors(c);
  if(tab==="hospitals")return adminHospitals(c);
  if(tab==="ambulances")return adminAmbulances(c);
  if(tab==="articles")return adminArticles(c);
  if(tab==="categories")return adminCategories(c);
  if(tab==="slides")return adminSlides(c);
  if(tab==="blood")return adminBloodDonors(c);
  if(tab==="cities")return adminCities(c);
  if(tab==="settings")return adminSettings(c);
  if(tab==="profile")return adminProfile(c);
}

async function adminOverview(c){
  const superAd=isSuperAdmin();
  const [h,d,a,art,cat]=await Promise.all([api("/api/admin/hospitals"),api("/api/admin/doctors"),api("/api/ambulances"),superAd?api("/api/articles"):Promise.resolve({data:{}}),superAd?api("/api/categories"):Promise.resolve({data:{}})]);
  const hosps=h.data?.hospitals||[],docs=d.data?.doctors||[],ambs=a.data?.ambulances||[],arts=art.data?.articles||[],cats=cat.data?.categories||[];
  let users=[],pending=[];
  let roleCounts={USER:0,DOCTOR:0,ADMIN:0,SUPER_ADMIN:0};
  if(superAd){const u=await api("/api/admin/users");users=u.data?.users||[];pending=users.filter(x=>x.status==="PENDING_DOCTOR"||x.status==="PENDING_ADMIN");users.forEach(u=>{roleCounts[u.role]=(roleCounts[u.role]||0)+1;});}
  c.innerHTML=`<div class="admin-stat-grid">
    ${superAd?`<div class="admin-stat-card"><div class="as-ico" style="background:#E0F2FE;color:#0284C7">👤</div><div class="as-body"><div class="as-val">${roleCounts.USER}</div><div class="as-lbl">Patients</div></div></div>`:""}
    <div class="admin-stat-card"><div class="as-ico" style="background:#DCFCE7;color:#16A34A">🩺</div><div class="as-body"><div class="as-val">${docs.length}</div><div class="as-lbl">Doctors</div></div></div>
    <div class="admin-stat-card"><div class="as-ico" style="background:#FEF3C7;color:#F59E0B">🏥</div><div class="as-body"><div class="as-val">${hosps.length}</div><div class="as-lbl">Hospitals</div></div></div>
    <div class="admin-stat-card"><div class="as-ico" style="background:#FEE2E2;color:#EF4444">🚑</div><div class="as-body"><div class="as-val">${ambs.length}</div><div class="as-lbl">Ambulances</div></div></div>
    ${superAd?`<div class="admin-stat-card"><div class="as-ico" style="background:#F3E8FF;color:#8B5CF6">📰</div><div class="as-body"><div class="as-val">${arts.length}</div><div class="as-lbl">Articles</div></div></div>`:""}
    ${superAd?`<div class="admin-stat-card"><div class="as-ico" style="background:#FCE7F3;color:#EC4899">🗂️</div><div class="as-body"><div class="as-val">${cats.length}</div><div class="as-lbl">Categories</div></div></div>`:""}
    ${superAd?`<div class="admin-stat-card"><div class="as-ico" style="background:#FEF3C7;color:#D97706">⏳</div><div class="as-body"><div class="as-val">${pending.length}</div><div class="as-lbl">Pending</div></div></div>`:""}
  </div>
  ${superAd?`<div class="admin-card"><h3>👥 User Role Breakdown</h3><div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px">
    <div style="text-align:center;padding:10px;background:var(--primary-faint);border-radius:var(--radius-sm)"><div style="font-size:22px;font-weight:800;color:var(--primary-2)">${roleCounts.USER}</div><div style="font-size:12px;color:var(--muted)">Patients</div></div>
    <div style="text-align:center;padding:10px;background:var(--amber-soft);border-radius:var(--radius-sm)"><div style="font-size:22px;font-weight:800;color:var(--amber)">${roleCounts.DOCTOR}</div><div style="font-size:12px;color:var(--muted)">Doctors</div></div>
    <div style="text-align:center;padding:10px;background:var(--green-soft);border-radius:var(--radius-sm)"><div style="font-size:22px;font-weight:800;color:var(--green)">${roleCounts.ADMIN}</div><div style="font-size:12px;color:var(--muted)">Admins</div></div>
    <div style="text-align:center;padding:10px;background:var(--primary-soft);border-radius:var(--radius-sm)"><div style="font-size:22px;font-weight:800;color:var(--primary-dark)">${roleCounts.SUPER_ADMIN}</div><div style="font-size:12px;color:var(--muted)">Super Admins</div></div>
  </div></div>`:""}
  ${superAd&&pending.length?`<div class="admin-card"><h3>⏳ Pending Approvals</h3><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>User</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead><tbody>${pending.map(x=>`<tr><td><strong>${esc(x.username)}</strong></td><td style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(x.email)}</td><td><span class="badge badge-warn">${esc(x.status)}</span></td><td class="admin-row-actions"><button class="btn btn-soft btn-sm" onclick="approveUser('${x.id}','approve')">✓</button><button class="btn btn-danger btn-sm" onclick="approveUser('${x.id}','reject')">✕</button></td></tr>`).join("")}</tbody></table></div></div>`:""}
  <div class="admin-card"><h3>📊 Quick Actions</h3><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
    <a class="btn btn-soft btn-sm" href="#/admin/doctors" style="padding:12px">🩺 Manage Doctors</a>
    <a class="btn btn-soft btn-sm" href="#/admin/hospitals" style="padding:12px">🏥 Manage Hospitals</a>
    <a class="btn btn-soft btn-sm" href="#/admin/ambulances" style="padding:12px">🚑 Manage Ambulances</a>
    ${superAd?`<a class="btn btn-soft btn-sm" href="#/admin/users" style="padding:12px">👥 Manage Users</a>`:""}
    ${superAd?`<a class="btn btn-soft btn-sm" href="#/admin/articles" style="padding:12px">📰 Manage Articles</a>`:""}
    ${superAd?`<a class="btn btn-soft btn-sm" href="#/admin/categories" style="padding:12px">🗂️ Manage Categories</a>`:""}
  </div></div>`;
  window.approveUser=async(id,action)=>{const {data,error}=await api(`/api/admin/users/${id}`,{method:"PUT",body:{action}});if(error)return toast(error,"error");addNotif(action==="approve"?"User approved":"User rejected",`${action==="approve"?"Approved":"Rejected"} user request`,"👥");toast(data.message||"Done","success");adminOverview($("#adminContent"));};
}

async function adminUsers(c){
  const {data}=await api("/api/admin/users");const users=data?.users||[];
  c.innerHTML=`<div class="admin-card"><h3>👥 All Users <span class="badge badge-gray">${users.length}</span></h3><div style="display:flex;gap:8px;margin-bottom:10px"><input class="admin-search" placeholder="Search users…" oninput="filterAdminTable(this,'userTable')" style="flex:1"><select class="admin-search" id="userRoleFilter" onchange="filterUsersByRole()" style="width:auto;flex-shrink:0"><option value="">All Roles</option><option value="USER">Patients</option><option value="DOCTOR">Doctors</option><option value="ADMIN">Admins</option><option value="SUPER_ADMIN">Super Admins</option></select></div><div class="admin-table-wrap"><table class="admin-table" id="userTable"><thead><tr><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead><tbody>${users.map(x=>`<tr data-role="${esc(x.role)}"><td><strong>${esc(x.username)}</strong></td><td style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(x.email)}</td><td><span class="badge ${x.role==="SUPER_ADMIN"?"badge-primary":x.role==="ADMIN"?"badge-success":x.role==="DOCTOR"?"badge-warn":"badge-gray"}">${esc(x.role)}</span></td><td>${x.status==="ACTIVE"?'<span class="badge badge-success">Active</span>':`<span class="badge badge-warn">${esc(x.status)}</span>`}</td><td class="admin-row-actions">${x.status!=="ACTIVE"?`<button class="btn btn-soft btn-sm" onclick="approveUser('${x.id}','approve')">✓</button><button class="btn btn-danger btn-sm" onclick="approveUser('${x.id}','reject')">✕</button>`:`<button class="btn btn-ghost btn-sm" onclick="setRole('${x.id}')">Role</button>`}<button class="btn btn-danger btn-sm" onclick="delUser('${x.id}','${esc(x.username)}')">Del</button></td></tr>`).join("")}</tbody></table></div></div>`;
  window.delUser=(id,name)=>openModal("Delete user",`<p>Delete <strong>${esc(name)}</strong>?</p>`,[{label:"Delete",cls:"btn-danger",onClick:async()=>{const {error}=await api(`/api/admin/users/${id}`,{method:"DELETE"});if(error)return toast(error,"error");toast("User deleted","success");closeModal();adminUsers($("#adminContent"));}}]);
  window.setRole=(id)=>openModal("Change role",`<div class="field"><label>New role</label><select id="roleSel"><option value="USER">USER</option><option value="DOCTOR">DOCTOR</option><option value="ADMIN">ADMIN</option><option value="SUPER_ADMIN">SUPER_ADMIN</option></select></div>`,[{label:"Save",cls:"btn-primary",onClick:async()=>{const role=$("#roleSel").value;const {error}=await api(`/api/admin/users/${id}`,{method:"PUT",body:{role}});if(error)return toast(error,"error");toast("Role updated","success");closeModal();adminUsers($("#adminContent"));}}]);
}
window.filterUsersByRole=()=>{
  const sel=$("#userRoleFilter");if(!sel)return;
  const role=sel.value;
  const rows=document.querySelectorAll("#userTable tbody tr");
  rows.forEach(r=>{r.style.display=(!role||r.getAttribute("data-role")===role)?"":"none";});
};

async function adminDoctors(c){
  const {data}=await api("/api/admin/doctors");const docs=data?.doctors||[];
  c.innerHTML=`<div class="admin-card"><h3>🩺 Doctors <span class="badge badge-gray">${docs.length}</span></h3><input class="admin-search" placeholder="Search doctors…" oninput="filterAdminTable(this,'docTable')"><div class="admin-table-wrap"><table class="admin-table" id="docTable"><thead><tr><th>Name</th><th>Specialty</th><th>City</th><th>Fee</th><th>Actions</th></tr></thead><tbody>${docs.map(d=>`<tr><td><strong>${esc(d.name)}</strong></td><td>${esc(d.specialty)}</td><td>${esc(d.city)}</td><td>৳${d.fee||0}</td><td class="admin-row-actions"><button class="btn btn-ghost btn-sm" onclick="doctorForm('${d.id}')">Edit</button><button class="btn btn-danger btn-sm" onclick="delDoctor('${d.id}','${esc(d.name)}')">Del</button></td></tr>`).join("")}</tbody></table></div></div>`;
  window.delDoctor=(id,name)=>openModal("Delete doctor",`<p>Delete <strong>${esc(name)}</strong>?</p>`,[{label:"Delete",cls:"btn-danger",onClick:async()=>{const {error}=await api(`/api/admin/doctors/${id}`,{method:"DELETE"});if(error)return toast(error,"error");toast("Deleted","success");closeModal();adminDoctors($("#adminContent"));}}]);
}
async function doctorForm(id){
  let d={};if(id){const r=await api("/api/admin/doctors");d=(r.data?.doctors||[]).find(x=>x.id===id)||{};}
  const h=await api("/api/admin/hospitals");const hospitals=h.data?.hospitals||[];
  const c=await api("/api/categories");const categories=c.data?.categories||[];
  const ci=await api("/api/cities");const cities=ci.data?.cities||[];
  openModal(id?"Edit Doctor":"Add Doctor",`<div class="form-row"><div class="field"><label>Name *</label><input id="d_name" value="${esc(d.name||"")}"></div><div class="field"><label>Specialty *</label><select id="d_specialty" required><option value="">Select…</option>${categories.map(cat=>`<option value="${esc(cat.name)}" ${d.specialty===cat.name?"selected":""}>${esc(cat.name)}</option>`).join("")}</select></div></div><div class="field"><label>Qualifications *</label><input id="d_qualifications" value="${esc(d.qualifications||"")}"></div><div class="form-row"><div class="field"><label>Experience</label><input id="d_experience" type="number" value="${d.experience||0}"></div><div class="field"><label>Fee (৳)</label><input id="d_fee" type="number" value="${d.fee||0}"></div></div><div class="form-row"><div class="field"><label>Phone *</label><input id="d_phone" value="${esc(d.phone||"")}"></div><div class="field"><label>Email</label><input id="d_email" value="${esc(d.email||"")}"></div></div><div class="field"><label>Hospital</label><select id="d_hospitalId"><option value="">— None —</option>${hospitals.map(x=>`<option value="${x.id}" ${d.hospitalId===x.id?"selected":""}>${esc(x.name)}</option>`).join("")}</select></div><div class="form-row"><div class="field"><label>City *</label><select id="d_city" required><option value="">Select…</option>${cities.map(city=>`<option value="${esc(city.name)}" ${d.city===city.name?"selected":""}>${esc(city.name)}</option>`).join("")}</select></div><div class="field"><label>Address *</label><input id="d_address" value="${esc(d.address||"")}"></div></div><div class="field"><label>Hours *</label><input id="d_hours" value="${esc(d.hours||"")}"></div><div class="form-row"><div class="field"><label>Photo URL</label><input id="d_photo" value="${esc(d.photo||"")}"></div><div class="field"><label>Google Maps link</label><input id="d_mapLink" value="${esc(d.mapLink||"")}"></div></div><div class="field"><label>YouTube video URL</label><input id="d_youtubeUrl" value="${esc(d.youtubeUrl||"")}"></div><div class="field"><label>Bio</label><textarea id="d_bio">${esc(d.bio||"")}</textarea></div>`,[{label:id?"Update":"Create",cls:"btn-primary",onClick:async()=>{const body={name:val("d_name"),specialty:val("d_specialty"),qualifications:val("d_qualifications"),experience:val("d_experience"),fee:val("d_fee"),phone:val("d_phone"),email:val("d_email"),hospitalId:val("d_hospitalId")||null,city:val("d_city"),address:val("d_address"),hours:val("d_hours"),photo:val("d_photo")||null,mapLink:val("d_mapLink")||null,youtubeUrl:val("d_youtubeUrl")||null,bio:val("d_bio")||null};const url=id?`/api/admin/doctors/${id}`:"/api/admin/doctors";const {data,error}=await api(url,{method:id?"PUT":"POST",body});if(error)return toast(error,"error");addNotif(id?"Doctor updated":"Doctor added",`${id?"Updated":"Added"} doctor: ${val("d_name")}`,"🩺");toast(data.message||"Saved","success");closeModal();adminDoctors($("#adminContent"));}}]);
}

async function adminHospitals(c){
  const {data}=await api("/api/admin/hospitals");const list=data?.hospitals||[];
  c.innerHTML=`<div class="admin-card"><h3>🏥 Hospitals <span class="badge badge-gray">${list.length}</span></h3><input class="admin-search" placeholder="Search hospitals…" oninput="filterAdminTable(this,'hospTable')"><div class="admin-table-wrap"><table class="admin-table" id="hospTable"><thead><tr><th>Name</th><th>City</th><th>Phone</th><th>Doctors</th><th>Actions</th></tr></thead><tbody>${list.map(h=>`<tr><td><strong>${esc(h.name)}</strong></td><td>${esc(h.city)}</td><td>${esc(h.phone)}</td><td>${h._count?.doctors||0}</td><td class="admin-row-actions"><button class="btn btn-ghost btn-sm" onclick="hospitalForm('${h.id}')">Edit</button><button class="btn btn-danger btn-sm" onclick="delHosp('${h.id}','${esc(h.name)}')">Del</button></td></tr>`).join("")}</tbody></table></div></div>`;
  window.delHosp=(id,name)=>openModal("Delete hospital",`<p>Delete <strong>${esc(name)}</strong>?</p>`,[{label:"Delete",cls:"btn-danger",onClick:async()=>{const {error}=await api(`/api/admin/hospitals/${id}`,{method:"DELETE"});if(error)return toast(error,"error");toast("Deleted","success");closeModal();adminHospitals($("#adminContent"));}}]);
}
async function hospitalForm(id){
  let h={};if(id){const r=await api("/api/admin/hospitals");h=(r.data?.hospitals||[]).find(x=>x.id===id)||{};}
  const ci=await api("/api/cities");const cities=ci.data?.cities||[];
  openModal(id?"Edit Hospital":"Add Hospital",`<div class="field"><label>Name *</label><input id="h_name" value="${esc(h.name||"")}"></div><div class="form-row"><div class="field"><label>City *</label><select id="h_city" required><option value="">Select…</option>${cities.map(city=>`<option value="${esc(city.name)}" ${h.city===city.name?"selected":""}>${esc(city.name)}</option>`).join("")}</select></div><div class="field"><label>Phone *</label><input id="h_phone" value="${esc(h.phone||"")}"></div></div><div class="field"><label>Address *</label><input id="h_address" value="${esc(h.address||"")}"></div><div class="field"><label>Photo URL</label><input id="h_photo" value="${esc(h.photo||"")}"></div><div class="field"><label>Google Maps link</label><input id="h_mapLink" value="${esc(h.mapLink||"")}"></div><div class="form-row"><div class="field"><label>Facebook</label><input id="h_fb" value="${esc(h.fb||"")}"></div><div class="field"><label>WhatsApp</label><input id="h_wa" value="${esc(h.wa||"")}"></div></div><div class="field"><label>Website</label><input id="h_web" value="${esc(h.web||"")}"></div>`,[{label:id?"Update":"Create",cls:"btn-primary",onClick:async()=>{const body={name:val("h_name"),city:val("h_city"),phone:val("h_phone"),address:val("h_address"),photo:val("h_photo")||null,mapLink:val("h_mapLink")||null,fb:val("h_fb")||null,wa:val("h_wa")||null,web:val("h_web")||null};const url=id?`/api/admin/hospitals/${id}`:"/api/admin/hospitals";const {data,error}=await api(url,{method:id?"PUT":"POST",body});if(error)return toast(error,"error");addNotif(id?"Hospital updated":"Hospital added",`${id?"Updated":"Added"} hospital: ${val("h_name")}`,"🏥");toast(data.message||"Saved","success");closeModal();adminHospitals($("#adminContent"));}}]);
}

async function adminAmbulances(c){
  const {data}=await api("/api/admin/ambulances");const list=data?.ambulances||[];
  c.innerHTML=`<div class="admin-card"><h3>🚑 Ambulances <span class="badge badge-gray">${list.length}</span></h3><input class="admin-search" placeholder="Search ambulances…" oninput="filterAdminTable(this,'ambTable')"><div class="admin-table-wrap"><table class="admin-table" id="ambTable"><thead><tr><th>Name</th><th>City</th><th>Phone</th><th>Type</th><th>Actions</th></tr></thead><tbody>${list.map(a=>`<tr><td><strong>${esc(a.name)}</strong></td><td>${esc(a.city)}</td><td>${esc(a.phone)}</td><td>${esc(a.type||"")}</td><td class="admin-row-actions"><button class="btn btn-ghost btn-sm" onclick="ambForm('${a.id}')">Edit</button><button class="btn btn-danger btn-sm" onclick="delAmb('${a.id}','${esc(a.name)}')">Del</button></td></tr>`).join("")}</tbody></table></div></div>`;
  window.delAmb=(id,name)=>openModal("Delete ambulance",`<p>Delete <strong>${esc(name)}</strong>?</p>`,[{label:"Delete",cls:"btn-danger",onClick:async()=>{const {error}=await api(`/api/admin/ambulances/${id}`,{method:"DELETE"});if(error)return toast(error,"error");toast("Deleted","success");closeModal();adminAmbulances($("#adminContent"));}}]);
}
async function ambForm(id){
  let a={};if(id){const r=await api("/api/admin/ambulances");a=(r.data?.ambulances||[]).find(x=>x.id===id)||{};}
  const ci=await api("/api/cities");const cities=ci.data?.cities||[];
  openModal(id?"Edit Ambulance":"Add Ambulance",`<div class="field"><label>Name *</label><input id="a_name" value="${esc(a.name||"")}"></div><div class="field"><label>Profile Picture URL</label><input id="a_photo" value="${esc(a.photo||"")}" placeholder="https://… (optional)"></div><div class="form-row"><div class="field"><label>City *</label><select id="a_city" required><option value="">Select…</option>${cities.map(city=>`<option value="${esc(city.name)}" ${a.city===city.name?"selected":""}>${esc(city.name)}</option>`).join("")}</select></div><div class="field"><label>Area</label><input id="a_area" value="${esc(a.area||"")}"></div></div><div class="form-row"><div class="field"><label>Phone *</label><input id="a_phone" value="${esc(a.phone||"")}"></div><div class="field"><label>Type</label><input id="a_type" value="${esc(a.type||"Ambulance")}"></div></div><div class="field"><label>Google Maps link</label><input id="a_mapLink" value="${esc(a.mapLink||"")}"></div><div class="field"><label><input type="checkbox" id="a_available" ${a.available!==false?"checked":""}> Available</label></div>`,[{label:id?"Update":"Create",cls:"btn-primary",onClick:async()=>{const body={name:val("a_name"),city:val("a_city"),area:val("a_area")||null,phone:val("a_phone"),type:val("a_type"),mapLink:val("a_mapLink")||null,photo:val("a_photo")||null,available:$("#a_available").checked?"true":"false"};const url=id?`/api/admin/ambulances/${id}`:"/api/admin/ambulances";const {data,error}=await api(url,{method:id?"PUT":"POST",body});if(error)return toast(error,"error");addNotif(id?"Ambulance updated":"Ambulance added",`${id?"Updated":"Added"} ambulance: ${val("a_name")}`,"🚑");toast(data.message||"Saved","success");closeModal();adminAmbulances($("#adminContent"));}}]);
}

async function adminArticles(c){
  const {data}=await api("/api/admin/articles");const list=data?.articles||[];
  c.innerHTML=`<div class="admin-card"><h3>📰 Articles <span class="badge badge-gray">${list.length}</span></h3><input class="admin-search" placeholder="Search articles…" oninput="filterAdminTable(this,'artTable')"><div class="admin-table-wrap"><table class="admin-table" id="artTable"><thead><tr><th>Title</th><th>Category</th><th>Author</th><th>Actions</th></tr></thead><tbody>${list.map(a=>`<tr><td style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><strong>${esc(a.title)}</strong></td><td>${esc(a.category||"")}</td><td>${esc(a.author||"")}</td><td class="admin-row-actions"><button class="btn btn-ghost btn-sm" onclick="artForm('${a.id}')">Edit</button><button class="btn btn-danger btn-sm" onclick="delArt('${a.id}')">Del</button></td></tr>`).join("")}</tbody></table></div></div>`;
  window.delArt=(id)=>openModal("Delete article",`<p>Delete this article?</p>`,[{label:"Delete",cls:"btn-danger",onClick:async()=>{const {error}=await api(`/api/admin/articles/${id}`,{method:"DELETE"});if(error)return toast(error,"error");toast("Deleted","success");closeModal();adminArticles($("#adminContent"));}}]);
}
async function artForm(id){
  let a={};if(id){const r=await api("/api/admin/articles");a=(r.data?.articles||[]).find(x=>x.id===id)||{};}
  openModal(id?"Edit Article":"Add Article",`<div class="field"><label>Title *</label><input id="ar_title" value="${esc(a.title||"")}"></div><div class="form-row"><div class="field"><label>Category</label><input id="ar_category" value="${esc(a.category||"Health")}"></div><div class="field"><label>Author</label><input id="ar_author" value="${esc(a.author||"")}"></div></div><div class="form-row"><div class="field"><label>Read time (min)</label><input id="ar_readTime" type="number" value="${a.readTime||3}"></div><div class="field"><label>Cover image URL</label><input id="ar_coverImage" value="${esc(a.coverImage||"")}"></div></div><div class="field"><label>Excerpt *</label><textarea id="ar_excerpt">${esc(a.excerpt||"")}</textarea></div><div class="field"><label>Content *</label><textarea id="ar_content" style="min-height:140px">${esc(a.content||"")}</textarea></div>`,[{label:id?"Update":"Create",cls:"btn-primary",onClick:async()=>{const body={title:val("ar_title"),excerpt:val("ar_excerpt"),content:val("ar_content"),category:val("ar_category"),author:val("ar_author"),coverImage:val("ar_coverImage")||null,readTime:val("ar_readTime")};const url=id?`/api/admin/articles/${id}`:"/api/admin/articles";const {data,error}=await api(url,{method:id?"PUT":"POST",body});if(error)return toast(error,"error");addNotif(id?"Article updated":"Article added",`${id?"Updated":"Added"} article: ${val("ar_title")}`,"📰");toast(data.message||"Saved","success");closeModal();adminArticles($("#adminContent"));}}]);
}

async function adminCategories(c){
  const {data}=await api("/api/admin/categories");const list=data?.categories||[];
  c.innerHTML=`<div class="admin-card"><h3>🗂️ Categories <span class="badge badge-gray">${list.length}</span></h3><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Name</th><th>Bengali</th><th>Icon</th><th>Actions</th></tr></thead><tbody>${list.map(x=>`<tr><td><strong>${esc(x.name)}</strong></td><td>${esc(x.bn||"")}</td><td><span class="badge badge-primary">${catIcon(x.icon)} ${esc(x.icon)}</span></td><td class="admin-row-actions"><button class="btn btn-ghost btn-sm" onclick="catForm('${x.id}')">Edit</button><button class="btn btn-danger btn-sm" onclick="delCat('${x.id}','${esc(x.name)}')">Del</button></td></tr>`).join("")}</tbody></table></div></div>`;
  window.delCat=(id,name)=>openModal("Delete category",`<p>Delete <strong>${esc(name)}</strong>?</p>`,[{label:"Delete",cls:"btn-danger",onClick:async()=>{const {error}=await api(`/api/admin/categories/${id}`,{method:"DELETE"});if(error)return toast(error,"error");toast("Deleted","success");closeModal();adminCategories($("#adminContent"));}}]);
}
async function catForm(id){
  let x={};if(id){const r=await api("/api/admin/categories");x=(r.data?.categories||[]).find(z=>z.id===id)||{};}
  openModal(id?"Edit Category":"Add Category",`<div class="field"><label>Name *</label><input id="c_name" value="${esc(x.name||"")}"></div><div class="field"><label>Bengali name</label><input id="c_bn" value="${esc(x.bn||"")}"></div><div class="field"><label>Icon key</label><input id="c_icon" value="${esc(x.icon||"stethoscope")}"><div class="hint">heart, skin, brain, baby, child, stethoscope, tooth, bone, ear, eye</div></div>`,[{label:id?"Update":"Create",cls:"btn-primary",onClick:async()=>{const body={name:val("c_name"),bn:val("c_bn"),icon:val("c_icon")};const url=id?`/api/admin/categories/${id}`:"/api/admin/categories";const {data,error}=await api(url,{method:id?"PUT":"POST",body});if(error)return toast(error,"error");addNotif(id?"Category updated":"Category added",`${id?"Updated":"Added"} category: ${val("c_name")}`,"🗂️");toast(data.message||"Saved","success");closeModal();adminCategories($("#adminContent"));}}]);
}

async function adminSlides(c){
  const {data}=await api("/api/admin/slides");const list=data?.slides||[];
  c.innerHTML=`<div class="admin-card"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px"><h3 style="margin:0">🖼️ Slides (${list.length})</h3><button class="btn btn-primary btn-sm" onclick="slideForm()">+ Add</button></div><div style="display:grid;gap:10px">${list.map(s=>`<div style="border:1px solid var(--line);border-radius:var(--radius-sm);padding:12px;display:flex;gap:10px;align-items:center"><div style="width:80px;height:50px;border-radius:8px;background:url('${esc(s.image||"")}') center/cover;flex-shrink:0"></div><div style="flex:1;min-width:0"><strong>${esc(s.title)}</strong><div style="color:var(--muted);font-size:12px">${esc(s.subtitle||"")}</div><div style="margin-top:3px"><span class="badge badge-gray">Order ${s.order}</span></div></div><button class="btn btn-ghost btn-sm" onclick="slideForm('${s.id}')">Edit</button><button class="btn btn-danger btn-sm" onclick="delSlide('${s.id}')">Del</button></div>`).join("")}</div></div>`;
  window.delSlide=(id)=>openModal("Delete slide",`<p>Delete this slide?</p>`,[{label:"Delete",cls:"btn-danger",onClick:async()=>{const {error}=await api(`/api/admin/slides/${id}`,{method:"DELETE"});if(error)return toast(error,"error");toast("Deleted","success");closeModal();adminSlides($("#adminContent"));}}]);
}
async function slideForm(id){
  let s={};
  if(id){const r=await api("/api/admin/slides");s=(r.data?.slides||[]).find(x=>x.id===id)||{};}
  openModal(id?"Edit Slide":"Add Slide",`
    <div class="field"><label>Title *</label><input id="sl_title" value="${esc(s.title||"")}"></div>
    <div class="field"><label>Subtitle</label><input id="sl_subtitle" value="${esc(s.subtitle||"")}"></div>
    <div class="field">
      <label>Slide Image</label>
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
        <div id="sl_preview" style="width:80px;height:50px;border-radius:8px;background:${s.image?`url('${esc(s.image)}') center/cover`:'var(--primary-faint)'};flex-shrink:0;border:1px solid var(--line)"></div>
        <div>
          <input type="file" id="sl_file" accept="image/*" style="display:none" onchange="uploadSlideImg(this)">
          <button type="button" class="btn btn-soft btn-sm" onclick="document.getElementById('sl_file').click()">📷 Upload from Device</button>
        </div>
      </div>
      <input id="sl_image" value="${esc(s.image||"")}" placeholder="Or paste image URL here" style="margin-top:4px">
      <div class="hint">Upload from device or paste an image URL</div>
    </div>
    <div class="form-row"><div class="field"><label>Button Text</label><input id="sl_btnText" value="${esc(s.btnText||"")}" placeholder="Find a Doctor"></div><div class="field"><label>Button Link</label><input id="sl_btnLink" value="${esc(s.btnLink||"")}" placeholder="#/doctors"></div></div>
    <div class="field"><label>Order</label><input id="sl_order" type="number" value="${s.order||0}"></div>
  `,[{label:id?"Update":"Create",cls:"btn-primary",onClick:async()=>{
    const body={title:val("sl_title"),subtitle:val("sl_subtitle")||null,image:val("sl_image")||null,btnText:val("sl_btnText")||null,btnLink:val("sl_btnLink")||null,order:val("sl_order")||"0"};
    if(!body.title||!body.image)return toast("Title and image are required","error");
    const url=id?`/api/admin/slides/${id}`:"/api/admin/slides";
    const {data,error}=await api(url,{method:id?"PUT":"POST",body});
    if(error)return toast(error,"error");
    toast(data.message||"Saved","success");closeModal();adminSlides($("#adminContent"));
  }}]);
}
function uploadSlideImg(input){
  const file=input.files[0];if(!file)return;
  if(file.size>3*1024*1024){toast("Image too large (max 3MB)","error");return;}
  const reader=new FileReader();
  reader.onload=function(e){
    const dataUrl=e.target.result;
    $("#sl_image").value=dataUrl;
    $("#sl_preview").style.background=`url('${dataUrl}') center/cover`;
    toast("Image loaded","success");
  };
  reader.readAsDataURL(file);
}
window.uploadSlideImg=uploadSlideImg;

async function adminBloodDonors(c){
  const {data}=await api("/api/blood-donors");const list=data?.donors||[];
  c.innerHTML=`<div class="admin-card"><h3>🩸 Blood Donors <span class="badge badge-gray">${list.length}</span></h3><input class="admin-search" placeholder="Search donors…" oninput="filterAdminTable(this,'bdTable')"><div class="admin-table-wrap"><table class="admin-table" id="bdTable"><thead><tr><th>Name</th><th>Blood</th><th>City</th><th>Phone</th><th>Status</th></tr></thead><tbody>${list.map(b=>`<tr><td><strong>${esc(b.name)}</strong></td><td><span class="badge badge-danger">${esc(b.bloodGroup)}</span></td><td>${esc(b.city)}</td><td>${esc(b.phone)}</td><td>${b.available?'<span class="badge badge-success">Available</span>':'<span class="badge badge-gray">Unavailable</span>'}</td></tr>`).join("")}</tbody></table></div></div>`;
}

async function adminCities(c){
  const {data}=await api("/api/admin/cities");const list=data?.cities||[];
  c.innerHTML=`<div class="admin-card"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px"><h3 style="margin:0">📍 Cities <span class="badge badge-gray">${list.length}</span></h3><button class="btn btn-primary btn-sm" onclick="cityForm()">+ Add</button></div><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>City Name</th><th>Actions</th></tr></thead><tbody>${list.map(city=>`<tr><td><strong>${esc(city.name)}</strong></td><td class="admin-row-actions"><button class="btn btn-danger btn-sm" onclick="delCity('${city.id}','${esc(city.name)}')">Del</button></td></tr>`).join("")}</tbody></table></div></div>`;
  window.delCity=(id,name)=>openModal("Delete city",`<p>Delete <strong>${esc(name)}</strong>?</p>`,[{label:"Delete",cls:"btn-danger",onClick:async()=>{const {error}=await api(`/api/admin/cities/${id}`,{method:"DELETE"});if(error)return toast(error,"error");toast("City deleted","success");closeModal();adminCities($("#adminContent"));}}]);
}
async function cityForm(){
  openModal("Add City",`<div class="field"><label>City Name *</label><input id="city_name" placeholder="e.g. Dhaka, Chattogram"></div>`,[{label:"Add",cls:"btn-primary",onClick:async()=>{const name=val("city_name");if(!name)return toast("City name required","error");const {data,error}=await api("/api/admin/cities",{method:"POST",body:{name}});if(error)return toast(error,"error");toast(data.message||"City added","success");closeModal();adminCities($("#adminContent"));}}]);
}

async function adminProfile(c){
  const {data}=await api("/api/admin/profile");const p=data?.profile||{};
  c.innerHTML=`<div class="admin-card"><h3>👤 My Admin Profile</h3><div id="apAlert"></div><form id="apForm"><div class="form-row"><div class="field"><label>Name *</label><input id="ap_name" value="${esc(p.name||"")}"></div><div class="field"><label>Designation *</label><input id="ap_designation" value="${esc(p.designation||"")}"></div></div><div class="form-row"><div class="field"><label>Department *</label><input id="ap_department" value="${esc(p.department||"")}"></div><div class="field"><label>Phone *</label><input id="ap_phone" value="${esc(p.phone||"")}"></div></div><div class="form-row"><div class="field"><label>Email</label><input id="ap_email" value="${esc(p.email||"")}"></div><div class="field"><label>Photo URL</label><input id="ap_photo" value="${esc(p.photo||"")}"></div></div><div class="field"><label>Bio</label><textarea id="ap_bio">${esc(p.bio||"")}</textarea></div><button class="btn btn-primary btn-block" type="submit">💾 Save Profile</button></form></div>`;
  $("#apForm").addEventListener("submit",async(e)=>{e.preventDefault();const body={name:val("ap_name"),designation:val("ap_designation"),department:val("ap_department"),phone:val("ap_phone"),email:val("ap_email")||null,photo:val("ap_photo")||null,bio:val("ap_bio")||null};const btn=e.target.querySelector("button[type=submit]");btn.disabled=true;const {data:d,error}=await api("/api/admin/profile",{method:"PUT",body});btn.disabled=false;if(error){$("#apAlert").innerHTML=`<div class="alert alert-error">${esc(error)}</div>`;return;}$("#apAlert").innerHTML=`<div class="alert alert-success">${esc(d.message||"Saved")}</div>`;toast("Profile saved","success");await loadMe();});
}
function filterAdminTable(input,tableId){const q=input.value.toLowerCase();const rows=document.querySelectorAll("#"+tableId+" tbody tr");rows.forEach(r=>{r.style.display=r.textContent.toLowerCase().includes(q)?"":"none";});}
window.filterAdminTable=filterAdminTable;window.adminFAB=adminFAB;

/* ---------- Admin Settings ---------- */
async function adminSettings(c){
  const settings=loadSettings();
  c.innerHTML=`<div class="admin-card">
    <h3>⚙️ Settings</h3>
    <p style="color:var(--muted);font-size:13px;margin:0 0 14px">Configure your app preferences</p>
    <div id="setAlert"></div>
    <div class="form-section-title">📢 Marquee / Update Bar</div>
    <div class="field"><label><input type="checkbox" id="set_marquee" ${settings.marquee?"checked":""}> Show update marquee bar on homepage</label></div>
    <div class="field"><label>Marquee Text (one message per line)</label><textarea id="set_marqueeText" style="min-height:80px" placeholder="Welcome to Doctor App&#10;Find trusted doctors near you">${esc((settings.marqueeText||["Welcome to Doctor App — your health, our priority.","Find trusted doctors near you.","24/7 ambulance service available."]).join("\n"))}</textarea><div class="hint">Each line becomes a scrolling message</div></div>
    <div class="form-section-title">🤖 AI Assistant</div>
    <div class="field"><label><input type="checkbox" id="set_aiEnabled" ${settings.aiEnabled!==false?"checked":""}> Enable AI Assistant (Dr. AI)</label></div>
    <div class="field"><label>AI Assistant Name</label><input id="set_aiName" value="${esc(settings.aiName||"AI Assistant")}" placeholder="AI Assistant"></div>
    <div class="field"><label>AI Greeting Message</label><textarea id="set_aiGreeting" style="min-height:60px" placeholder="Hello! Welcome to Doctor App. I'm your virtual medical assistant.">${esc(settings.aiGreeting||"")}</textarea><div class="hint">Leave blank to use default greeting</div></div>
    <div class="form-section-title">📱 App Preferences</div>
    <div class="field"><label><input type="checkbox" id="set_installBanner" ${settings.installBanner?"checked":""}> Show PWA install banner on homepage</label></div>
    <div class="field"><label><input type="checkbox" id="set_heroSlider" ${settings.heroSlider?"checked":""}> Show hero image slider</label></div>
    <div class="field"><label><input type="checkbox" id="set_instantSearch" ${settings.instantSearch?"checked":""}> Enable instant search dropdown</label></div>
    <div class="form-section-title">🏥 Display Options</div>
    <div class="field"><label>Home page doctor count</label><select id="set_doctorCount"><option value="6" ${settings.doctorCount==="6"?"selected":""}>6 doctors</option><option value="8" ${settings.doctorCount==="8"?"selected":""}>8 doctors</option><option value="10" ${settings.doctorCount==="10"?"selected":""}>10 doctors</option><option value="12" ${settings.doctorCount==="12"?"selected":""}>12 doctors</option></select></div>
    <div class="field"><label>Default language</label><select id="set_lang"><option value="en" ${settings.lang==="en"?"selected":""}>English</option><option value="bn" ${settings.lang==="bn"?"selected":""}>বাংলা (Bangla)</option></select></div>
    <div class="field"><label>Default theme</label><select id="set_theme"><option value="light" ${settings.theme==="light"?"selected":""}>Light</option><option value="dark" ${settings.theme==="dark"?"selected":""}>Dark</option></select></div>
    <div class="form-section-title">ℹ️ App Info</div>
    <div class="info-row"><span class="lbl">Version</span><span class="val">1.1.3</span></div>
    <div class="info-row"><span class="lbl">Total Users</span><span class="val">${(await api("/api/admin/users")).data?.users?.length||0}</span></div>
    <div class="info-row"><span class="lbl">Total Doctors</span><span class="val">${(await api("/api/admin/doctors")).data?.doctors?.length||0}</span></div>
    <div class="info-row"><span class="lbl">Total Hospitals</span><span class="val">${(await api("/api/admin/hospitals")).data?.hospitals?.length||0}</span></div>
    <button class="btn btn-primary btn-block" style="margin-top:14px" onclick="saveSettings()">💾 Save Settings</button>
    <button class="btn btn-danger btn-block" style="margin-top:8px" onclick="resetSettings()">🔄 Reset to Default</button>
    <button class="btn btn-ghost btn-block" style="margin-top:8px" onclick="clearAllData()">🗑️ Clear All Local Data</button>
  </div>`;
}
function loadSettings(){
  try{return JSON.parse(localStorage.getItem("da_settings"))||{installBanner:true,marquee:true,marqueeText:["Welcome to Doctor App — your health, our priority.","Find trusted doctors near you.","24/7 ambulance service available."],aiEnabled:true,aiName:"AI Assistant",aiGreeting:"",heroSlider:true,instantSearch:true,doctorCount:"10",lang:"en",theme:"light"};}catch(e){return{installBanner:true,marquee:true,marqueeText:["Welcome to Doctor App — your health, our priority.","Find trusted doctors near you.","24/7 ambulance service available."],aiEnabled:true,aiName:"AI Assistant",aiGreeting:"",heroSlider:true,instantSearch:true,doctorCount:"10",lang:"en",theme:"light"};}
}
function saveSettings(){
  const s={
    installBanner:$("#set_installBanner").checked,
    marquee:$("#set_marquee").checked,
    marqueeText:$("#set_marqueeText").value.split("\n").filter(t=>t.trim()),
    aiEnabled:$("#set_aiEnabled").checked,
    aiName:$("#set_aiName").value||"AI Assistant",
    aiGreeting:$("#set_aiGreeting").value||"",
    heroSlider:$("#set_heroSlider").checked,
    instantSearch:$("#set_instantSearch").checked,
    doctorCount:$("#set_doctorCount").value,
    lang:$("#set_lang").value,
    theme:$("#set_theme").value,
  };
  try{localStorage.setItem("da_settings",JSON.stringify(s));}catch(e){}
  toast("Settings saved","success");
  render();
}
function resetSettings(){
  if(!confirm("Reset all settings to default?"))return;
  localStorage.removeItem("da_settings");
  toast("Settings reset to default","success");
  adminSettings($("#adminContent"));
}
function clearAllData(){
  if(!confirm("This will clear ALL local data (notifications, favorites, settings, AI chat). Continue?"))return;
  localStorage.removeItem("da_notifs");
  localStorage.removeItem("da_favs");
  localStorage.removeItem("da_ai_patient");
  localStorage.removeItem("da_settings");
  localStorage.removeItem("da_install_shown");
  localStorage.removeItem("da_install_dismissed");
  state.notifs=[];state.favs=[];
  toast("All local data cleared","success");
  render();
}
window.saveSettings=saveSettings;window.resetSettings=resetSettings;window.clearAllData=clearAllData;

/* ---------- generic helpers ---------- */
function val(id){const e=$("#"+id);return e?e.value.trim():"";}

/* ---------- Modal ---------- */
function openModal(title,bodyHtml,buttons=[]){
  $("#modalBox").innerHTML=`<div style="padding:10px 16px 0"><div class="grip" style="margin:0 auto"></div></div><div class="modal-head"><h3>${esc(title)}</h3><button class="close-x" onclick="closeModal()">×</button></div><div class="modal-body">${bodyHtml}</div>${buttons.length?`<div class="modal-foot">${buttons.map((b,i)=>`<button class="btn ${b.cls||"btn-ghost"}" data-i="${i}">${esc(b.label)}</button>`).join("")}</div>`:""}`;
  $("#modalBack").classList.add("open");
  buttons.forEach((b,i)=>{const btn=$(`.modal-foot button[data-i="${i}"]`);if(btn)btn.addEventListener("click",b.onClick);});
}
function closeModal(){const b=$("#modalBack");if(b)b.classList.remove("open");const m=$("#modalBox");if(m)m.innerHTML="";}
window.closeModal=closeModal;
(function(){const back=$("#modalBack");if(back)back.addEventListener("click",e=>{if(e.target.id==="modalBack")closeModal();});})();

/* ===================================================================
/* ===================================================================
   MEDICINE TRACKER (Simple & Robust)
   =================================================================== */
async function viewMedicineTracker(){
  if(!state.user){navigate("/login");return;}
  mount(loadingView());
  const {data,error}=await api("/api/medicine-reminders");
  if(error){mount(emptyState("Error",error));return;}
  const reminders=data?.reminders||[];
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>${t("medTracker")}</h1><p>${t("medTrackerSub")}</p></div>
  <button class="btn btn-primary btn-block" style="margin-bottom:14px" onclick="medicineForm()">${t("addMedReminder")}</button>
  ${reminders.length===0?emptyState(t("noReminders"),t("noRemindersSub")):""}
  <div id="reminderList">${reminders.map(r=>medicineCard(r)).join("")}</div>
  `;
  mount(inner);
}

function medicineCard(r){
  var times=[];
  try{times=JSON.parse(r.times||"[]");}catch(e){times=[];}
  var active=r.active!==false;
  var timeStr=times.length?times.map(function(tm){return fmtTime12(tm);}).join(", "):"—";
  var dateStr=fmtDate(r.startDate)+(r.endDate?" "+t("medTo")+" "+fmtDate(r.endDate):" ("+t("medOngoing")+")");
  return `
  <div class="doc-card med-card" style="border-left-color:${active?"var(--green)":"var(--muted-2)"};opacity:${active?"1":".6"};position:relative;cursor:pointer" onclick="navigate('/medicine/${r.id}')">
    <div class="doc-card-top">
      <div class="doc-avatar" style="background:var(--green-soft);color:var(--green)">💊</div>
      <div class="doc-info">
        <div class="doc-name">${esc(r.medicineName)}</div>
        <div class="doc-badge" style="background:var(--green-soft);color:var(--green)">${esc(r.dosage)}</div>
      </div>
    </div>
    <div class="doc-meta">
      <div class="row"><span class="ico">⏰</span> <span class="badge badge-primary">${esc(timeStr)}</span></div>
      <div class="row"><span class="ico">📅</span> ${esc(dateStr)}</div>
      ${r.notes?`<div class="row"><span class="ico">📝</span> ${esc(r.notes)}</div>`:""}
      <div class="row"><span class="ico">${active?"✅":"⏸️"}</span> ${active?t("medActive"):t("medPaused")}</div>
    </div>
    <div class="doc-btns" onclick="event.stopPropagation()">
      <button class="b-sec" onclick="medicineForm('${r.id}')" style="flex:1">✏️ ${t("medEdit")}</button>
      <button class="b-sec" onclick="toggleMedicine('${r.id}',${!active})" style="flex:1">${active?"⏸️ "+t("medPause"):"▶️ "+t("medResume")}</button>
      <button class="b-sec" onclick="delMedicine('${r.id}')" style="flex:1;color:var(--red)">🗑️ ${t("medDelete")}</button>
    </div>
  </div>`;
}

async function medicineForm(id){
  var r={};
  if(id){
    var res=await api("/api/medicine-reminders");
    if(res.data){r=(res.data.reminders||[]).find(function(x){return x.id===id;})||{};}
  }
  var times=["08:00","20:00"];
  try{times=JSON.parse(r.times)||["08:00","20:00"];}catch(e){times=["08:00","20:00"];}
  openModal(id?"Edit Medicine":"Add Medicine Reminder",`
    <div class="field"><label>💊 ${t("medMedName")} *</label><input id="med_name" value="${esc(r.medicineName||"")}" placeholder="e.g. Napa, Seclo"></div>
    <div class="field"><label>💊 ${t("medDosage")} *</label><input id="med_dosage" value="${esc(r.dosage||"")}" placeholder="e.g. 1 tablet, 500mg"></div>
    <div class="field"><label>⏰ ${t("medReminderTimes")}</label>
      <div id="med_times" style="display:flex;flex-wrap:wrap;gap:6px">
        ${times.map(function(tm){return '<input type="time" class="med-time" value="'+esc(tm)+'" style="width:calc(50% - 3px);padding:8px;border:1px solid var(--line);border-radius:8px;font-size:14px">';}).join("")}
      </div>
      <button type="button" class="btn btn-soft btn-sm" style="margin-top:6px" onclick="addTimeSlot()">➕ Add Time</button>
    </div>
    <div class="form-row">
      <div class="field"><label>📅 ${t("medStartDate")} *</label><input id="med_start" type="date" value="${esc(r.startDate||new Date().toISOString().slice(0,10))}"></div>
      <div class="field"><label>📅 ${t("medEndDate")}</label><input id="med_end" type="date" value="${esc(r.endDate||"")}"></div>
    </div>
    <div class="field"><label>📝 ${t("medNotes")}</label><textarea id="med_notes" placeholder="e.g. After meals">${esc(r.notes||"")}</textarea></div>
  `,[{label:id?"Update":"Add Reminder",cls:"btn-primary",onClick:async()=>{
    var name=val("med_name");var dosage=val("med_dosage");
    var timeInputs=document.querySelectorAll(".med-time");
    var timeArr=Array.from(timeInputs).map(function(i){return i.value;}).filter(function(v){return v;});
    if(!name||!dosage||timeArr.length===0){toast("Please fill all required fields","error");return;}
    var body={medicineName:name,dosage:dosage,times:JSON.stringify(timeArr),startDate:val("med_start"),endDate:val("med_end")||null,notes:val("med_notes")||null};
    var url=id?"/api/medicine-reminders/"+id:"/api/medicine-reminders";
    var res=await api(url,{method:id?"PUT":"POST",body:body});
    if(res.error){toast(res.error,"error");return;}
    toast(res.data&&res.data.message||"Saved","success");closeModal();
    addNotif("💊 Medicine reminder "+(id?"updated":"added"),name+" - "+dosage,"💊");
    viewMedicineTracker();
  }}]);
}

function addTimeSlot(){
  var c=document.getElementById("med_times");
  if(!c)return;
  var inp=document.createElement("input");
  inp.type="time";inp.className="med-time";
  inp.style.cssText="width:calc(50% - 3px);padding:8px;border:1px solid var(--line);border-radius:8px;font-size:14px";
  c.appendChild(inp);
}

async function toggleMedicine(id,active){
  var res=await api("/api/medicine-reminders/"+id,{method:"PUT",body:{active:String(active)}});
  if(res.error){toast(res.error,"error");return;}
  toast(active?t("medResume")+" ✓":t("medPause")+" ✓","success");
  viewMedicineTracker();
}

async function delMedicine(id){
  if(!confirm("Delete this medicine reminder?"))return;
  var res=await api("/api/medicine-reminders/"+id,{method:"DELETE"});
  if(res.error){toast(res.error,"error");return;}
  toast("Deleted","success");
  viewMedicineTracker();
}

async function viewMedicineDetail(id){
  if(!state.user){navigate("/login");return;}
  mount(loadingView());
  var res=await api("/api/medicine-reminders");
  if(res.error){mount(emptyState("Error",res.error));return;}
  var r=(res.data&&res.data.reminders||[]).find(function(x){return x.id===id;});
  if(!r){
    mount('<div class="page-head"><a class="back-link" href="#/medicine">'+t("medBackTracker")+'</a></div>'+emptyState(t("medNotFound"),t("medNotFoundSub"))+'<div style="text-align:center;margin-top:12px"><a class="btn btn-primary" href="#/medicine">'+t("medGoTracker")+'</a></div>');
    return;
  }
  var times=[];try{times=JSON.parse(r.times||"[]");}catch(e){}
  var active=r.active!==false;
  var today=new Date().toISOString().slice(0,10);
  var daysActive=0;
  try{daysActive=r.startDate<=today?Math.max(0,Math.floor((new Date(today)-new Date(r.startDate))/86400000))+1:0;}catch(e){}
  var statusText=active?t("medActive"):t("medPaused");
  var statusBadge=active
    ?'<span class="badge" style="background:var(--green);color:#fff">'+esc(statusText)+'</span>'
    :'<span class="badge" style="background:var(--amber);color:#fff">'+esc(statusText)+'</span>';
  var sortedTimes=times.slice().sort();
  var inner=`
  <div class="page-head">
    <a class="back-link" href="#/medicine">${t("medBackTracker")}</a>
    <h1>${t("medDetails")}</h1>
    <p>${t("medDetailsSub")}</p>
  </div>
  <div class="dp-hero" style="text-align:center;padding:24px 16px;background:linear-gradient(135deg,var(--green-soft),var(--primary-faint))">
    <div class="dp-avatar" style="width:84px;height:84px;font-size:40px;background:var(--green);color:#fff;margin:0 auto 12px">💊</div>
    <h2 style="margin:0 0 6px;font-size:22px;color:var(--text)">${esc(r.medicineName)}</h2>
    <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;align-items:center">
      <span class="doc-badge" style="background:var(--green-soft);color:var(--green);font-size:14px;padding:5px 12px">${esc(r.dosage)}</span>
      ${statusBadge}
    </div>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">${t("medInfo")}</div>
    <div class="amb-row"><span>${t("medMedName")}</span><span><strong>${esc(r.medicineName)}</strong></span></div>
    <div class="amb-row"><span>${t("medDosage")}</span><span>${esc(r.dosage)}</span></div>
    <div class="amb-row"><span>${t("medStatus")}</span><span>${esc(statusText)}</span></div>
    ${r.notes?'<div class="amb-row"><span>'+t("medNotes")+'</span><span>'+esc(r.notes)+'</span></div>':""}
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">${t("medSchedule")}</div>
    <div class="amb-row"><span>${t("medReminderTimes")}</span><span>${sortedTimes.length?sortedTimes.map(function(tm){return '<span class="badge badge-primary" style="margin-left:4px">'+esc(fmtTime12(tm))+'</span>';}).join(""):"—"}</span></div>
    <div class="amb-row"><span>${t("medFrequency")}</span><span>${times.length} ${t("timePerDay")}</span></div>
    <div class="amb-row"><span>${t("medDailyDoses")}</span><span>${times.length} ${t("dosePlural")}</span></div>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">${t("medDuration")}</div>
    <div class="amb-row"><span>${t("medStartDate")}</span><span>${esc(fmtDate(r.startDate))}</span></div>
    <div class="amb-row"><span>${t("medEndDate")}</span><span>${r.endDate?esc(fmtDate(r.endDate)):'<span style="color:var(--muted)">'+t("medNoEnd")+'</span>'}</span></div>
    <div class="amb-row"><span>${t("medDaysActive")}</span><span>${daysActive}</span></div>
    <div class="amb-row"><span>${t("medAddedOn")}</span><span>${fmtDate(r.createdAt)}</span></div>
  </div>
  <div style="display:flex;gap:8px;margin-top:14px">
    <button class="btn btn-primary" style="flex:1" onclick="medicineForm('${r.id}')">✏️ ${t("medEditDetails")}</button>
    <button class="btn btn-soft" style="flex:1" onclick="toggleMedicine('${r.id}',${!active})">${active?"⏸️ "+t("medPause"):"▶️ "+t("medResume")}</button>
  </div>
  <button class="btn btn-ghost btn-block" style="margin-top:8px;color:var(--red)" onclick="delMedicine('${r.id}')">🗑️ ${t("medDeleteReminder")}</button>
  `;
  mount(inner);
}

function checkReminders(reminders){
  try{
    var now=new Date();
    var currentTime=String(now.getHours()).padStart(2,"0")+":"+String(now.getMinutes()).padStart(2,"0");
    var today=now.toISOString().slice(0,10);
    reminders.forEach(function(r){
      if(!r.active)return;
      if(r.startDate>today)return;
      if(r.endDate&&r.endDate<today)return;
      var times=[];
      try{times=JSON.parse(r.times||"[]");}catch(e){return;}
      if(times.indexOf(currentTime)>=0){
        var key="med_"+r.id+"_"+currentTime+"_"+today;
        try{
          if(!localStorage.getItem(key)){
            localStorage.setItem(key,"1");
            playNotifSound();
            addNotif("💊 Medicine Reminder","Time to take "+r.medicineName+" ("+r.dosage+")","💊");
            toast("💊 Time to take "+r.medicineName,"warn");
          }
        }catch(e){}
      }
    });
  }catch(e){}
}

window.medicineForm=medicineForm;window.toggleMedicine=toggleMedicine;window.delMedicine=delMedicine;window.viewMedicineDetail=viewMedicineDetail;window.addTimeSlot=addTimeSlot;

/* ===================================================================
   RATING SYSTEM
   =================================================================== */
async function showRatingModal(entityType,entityId,name){
  const {data}=await api(`/api/ratings?entityType=${entityType}&entityId=${entityId}`);
  const ratings=data?.ratings||[];
  const myRating=ratings.find(r=>r.userId===state.user?.id);
  const currentRating=myRating?myRating.rating:0;
  openModal(`⭐ Rate ${esc(name)}`,`
    <div style="text-align:center;margin-bottom:14px">
      <div id="starRating" style="font-size:36px;cursor:pointer;letter-spacing:4px">
        ${[1,2,3,4,5].map(i=>`<span class="star" data-val="${i}" onclick="setStars(${i})" style="color:${i<=currentRating?'#F59E0B':'#E5E7EB'}">${i<=currentRating?'★':'☆'}</span>`).join("")}
      </div>
      <div id="ratingLabel" style="margin-top:8px;font-size:14px;color:var(--muted)">${currentRating>0?'Your rating: '+currentRating+' stars':'Tap a star to rate'}</div>
    </div>
    <div class="field"><label>Review (optional)</label><textarea id="ratingReview" placeholder="Share your experience...">${myRating?esc(myRating.review||""):""}</textarea></div>
    ${ratings.length>0?`<div style="margin-top:10px"><strong style="font-size:13px">Recent Reviews:</strong>${ratings.slice(0,3).map(r=>`<div style="padding:8px 0;border-bottom:1px solid var(--line-2);font-size:12px"><span style="color:#F59E0B">${'★'.repeat(r.rating)}</span> ${esc(r.review||'No review')} <span style="color:var(--muted)">${fmtDate(r.createdAt)}</span></div>`).join("")}</div>`:""}
  `,[{label:"Submit Rating",cls:"btn-primary",onClick:async()=>{
    const stars=document.querySelectorAll(".star.active");
    const rating=window.__selectedRating||currentRating;
    if(!rating)return toast("Please select a rating","error");
    const review=$("#ratingReview")?$("#ratingReview").value.trim():null;
    const {data,error}=await api("/api/ratings",{method:"POST",body:{entityType,entityId,rating,review}});
    if(error)return toast(error,"error");
    toast(data.message||"Rating submitted!","success");
    closeModal();
    render();
  }}]);
  window.__selectedRating=currentRating;
}
function setStars(n){
  window.__selectedRating=n;
  const stars=document.querySelectorAll("#starRating .star");
  stars.forEach((s,i)=>{
    s.style.color=i<n?'#F59E0B':'#E5E7EB';
    s.textContent=i<n?'★':'☆';
  });
  const labels=['','Poor','Fair','Good','Very Good','Excellent'];
  $("#ratingLabel").textContent='Your rating: '+n+' stars - '+labels[n];
}
window.setStars=setStars;window.showRatingModal=showRatingModal;

/* ===================================================================
   CATEGORIES
   =================================================================== */
async function viewCategories(){
  mount(loadingView());
  const {data}=await api("/api/categories");
  const list=data?.categories||[];
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>${t("allCategories")}</h1><p>${t("browseBySpecialty")}</p></div>
  <div class="cat-grid" style="grid-template-columns:repeat(4,1fr);gap:12px">
    ${list.map(c=>`<div class="cat-card" onclick="navigate('/doctors?specialty=${encodeURIComponent(c.name)}')" style="padding:14px 6px"><div class="cat-ico" style="width:48px;height:48px;font-size:26px">${catIcon(c.name)}</div><div class="name">${esc(state.lang==="bn"&&c.bn?c.bn:c.name)}</div>${c.bn&&state.lang==="en"?`<div style="font-size:10px;color:var(--muted);margin-top:3px">${esc(c.bn)}</div>`:""}</div>`).join("")}
  </div>
  `;
  mount(inner);
}

/* ===================================================================
   ACCOUNT (simple for users)
   =================================================================== */
function viewAccount(){
  if(!state.user){navigate("/login");return;}
  const u=state.user;
  const avatarStyle = u.photo ? `style="background-image:url('${esc(u.photo)}')"` : "";
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>${t("myProfile")}</h1></div>
  ${isAdmin()?`<a href="#/admin" class="btn btn-primary btn-block" style="margin-bottom:14px;font-size:15px;padding:14px">⚙️ Go to Admin Dashboard</a>`:""}
  ${isDoctor()?`<a href="#/doctor-profile" class="btn btn-primary btn-block" style="margin-bottom:14px;font-size:15px;padding:14px">🩺 Go to Doctor Profile</a>`:""}
  <div class="dp-hero" id="acctHero">
    <div class="dp-avatar" id="acctAvatar" ${avatarStyle}>${u.photo?"":esc(initials(u.name||u.username))}</div>
    <h2 id="acctName">${esc(u.name||u.username)}</h2>
    <div class="dp-sp">${esc(u.role)}${u.bloodGroup?" · 🩸 "+esc(u.bloodGroup):""}</div>
    <div class="dp-badges">
      <span class="b">${esc(u.email)}</span>
      ${u.phone?`<span class="b">☎ ${esc(u.phone)}</span>`:""}
    </div>
  </div>
  <div id="acctAlert"></div>
  <div class="form-card">
    <form id="acctForm">
      <div class="form-section-title">👤 Profile Information</div>
      <div class="field">
        <label>Profile Photo</label>
        <div style="display:flex;align-items:center;gap:12px">
          <div id="photoPreview" style="width:64px;height:64px;border-radius:50%;background:var(--primary-soft);background-size:cover;background-position:center;display:grid;place-items:center;color:var(--primary-dark);font-weight:700;font-size:22px;flex-shrink:0;border:2px solid var(--line)">${u.photo?"":esc(initials(u.name||u.username))}</div>
          <div style="flex:1">
            <input type="file" id="acct_photoFile" accept="image/*" style="display:none" onchange="uploadPhoto(this)">
            <button type="button" class="btn btn-soft btn-sm" onclick="document.getElementById('acct_photoFile').click()">📷 Upload from Device</button>
            <input type="hidden" id="acct_photo" value="${esc(u.photo||"")}">
            <div class="hint" style="margin-top:4px">Tap to upload a photo from your device</div>
          </div>
        </div>
      </div>
      <div class="field"><label>Full Name</label><input id="acct_name" value="${esc(u.name||"")}" placeholder="Your name"></div>
      <div class="field"><label>Phone Number</label><input id="acct_phone" type="tel" value="${esc(u.phone||"")}" placeholder="+8801…"></div>
      <div class="field"><label>Address</label><input id="acct_address" value="${esc(u.address||"")}" placeholder="Your address"></div>
      <div class="field"><label>Blood Group</label>
        <select id="acct_bloodGroup">
          <option value="">Select…</option>
          ${["A+","A-","B+","B-","AB+","AB-","O+","O-"].map(g=>`<option value="${g}" ${u.bloodGroup===g?"selected":""}>${g}</option>`).join("")}
        </select>
      </div>
      <button class="btn btn-primary btn-block" type="submit">💾 Save Profile</button>
    </form>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">🩸 Blood Donation</div>
    <div id="bdAlert"></div>
    <div id="bdSection">${loadingView()}</div>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">🔐 Account</div>
    <div class="info-row"><span class="lbl">Email</span><span class="val">${esc(u.email)}</span></div>
    <div class="info-row"><span class="lbl">Username</span><span class="val">${esc(u.username)}</span></div>
    <div class="info-row"><span class="lbl">Role</span><span class="val"><span class="badge badge-primary">${esc(u.role)}</span></span></div>
    <div class="info-row"><span class="lbl">Joined</span><span class="val">${fmtDate(u.createdAt)}</span></div>
    <div class="detail-actions" style="margin-top:14px">
      <button class="btn btn-danger" onclick="logout()">Logout</button>
    </div>
  </div>
  `;
  mount(inner,async()=>{
    // Set photo preview if exists
    if(u.photo){const pv=$("#photoPreview"); pv.style.backgroundImage=`url('${u.photo}')`; pv.textContent="";}
    $("#acctForm").addEventListener("submit",async(e)=>{
      e.preventDefault();
      const body={
        name:$("#acct_name").value.trim(),
        phone:$("#acct_phone").value.trim(),
        address:$("#acct_address").value.trim(),
        photo:$("#acct_photo").value||null,
        bloodGroup:$("#acct_bloodGroup").value||null,
      };
      const btn=e.target.querySelector("button[type=submit]"); btn.disabled=true; btn.textContent="Saving…";
      const {data,error}=await api("/api/user/profile",{method:"PUT",body});
      btn.disabled=false; btn.textContent="💾 Save Profile";
      if(error){$("#acctAlert").innerHTML=`<div class="alert alert-error">${esc(error)}</div>`;return;}
      $("#acctAlert").innerHTML=`<div class="alert alert-success">Profile updated successfully.</div>`;
      toast("Profile saved","success");
      $("#acctName").textContent=body.name||u.username;
      const av=$("#acctAvatar");
      if(body.photo){av.style.backgroundImage=`url('${body.photo}')`;av.textContent="";}
      else{av.style.backgroundImage="";av.textContent=initials(body.name||u.username);}
      state.user={...state.user,name:body.name,phone:body.phone,address:body.address,photo:body.photo,bloodGroup:body.bloodGroup};
      const bdName=$("#bd_name"); if(bdName && !bdName.value) bdName.value=body.name||"";
      const bdPhone=$("#bd_phone"); if(bdPhone && !bdPhone.value) bdPhone.value=body.phone||"";
      const bdBlood=$("#bd_bloodGroup"); if(bdBlood && !bdBlood.value) bdBlood.value=body.bloodGroup||"";
    });
    await loadBloodDonorSection();
  });
}
function uploadPhoto(input){
  const file=input.files[0];
  if(!file) return;
  if(file.size>2*1024*1024){toast("Image too large (max 2MB)","error");return;}
  const reader=new FileReader();
  reader.onload=function(e){
    const dataUrl=e.target.result;
    $("#acct_photo").value=dataUrl;
    const pv=$("#photoPreview");
    pv.style.backgroundImage=`url('${dataUrl}')`;
    pv.textContent="";
    toast("Photo loaded — tap Save Profile","success");
  };
  reader.readAsDataURL(file);
}
window.uploadPhoto=uploadPhoto;

/* ---------- Blood donation section (inside profile) ---------- */
async function loadBloodDonorSection(){
  const c=$("#bdSection"); if(!c) return;
  const {data,error}=await api("/api/blood-donors/me");
  if(error){c.innerHTML=`<div class="alert alert-error">${esc(error)}</div>`;return;}
  const d=data.donor;
  const {data:cityData}=await api("/api/cities");
  const cities=cityData?.cities||[];
  c.innerHTML=`
    ${d?`<div class="alert alert-success" style="margin-bottom:12px">✓ You are registered as a blood donor (${esc(d.bloodGroup)}). ${d.available?"You are available.":"You are currently unavailable."}</div>`:""}
    <form id="bdForm">
      <div class="form-row">
        <div class="field"><label>Full Name *</label><input id="bd_name" required value="${esc(d?.name||state.user?.name||"")}" placeholder="Your name"></div>
        <div class="field"><label>Blood Group *</label>
          <select id="bd_bloodGroup" required>
            <option value="">Select…</option>
            ${["A+","A-","B+","B-","AB+","AB-","O+","O-"].map(g=>`<option value="${g}" ${d?.bloodGroup===g?"selected":""}>${g}</option>`).join("")}
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="field"><label>Phone *</label><input id="bd_phone" type="tel" required value="${esc(d?.phone||state.user?.phone||"")}" placeholder="+8801…"></div>
        <div class="field"><label>City *</label><select id="bd_city" required><option value="">Select…</option>${cities.map(c=>`<option value="${esc(c.name)}" ${d?.city===c.name?"selected":""}>${esc(c.name)}</option>`).join("")}</select></div>
      </div>
      <div class="form-row">
        <div class="field"><label>Area</label><input id="bd_area" value="${esc(d?.area||"")}" placeholder="Mirpur, Gulshan…"></div>
        <div class="field"><label>Last Donated</label><input id="bd_lastDonated" type="date" value="${esc(d?.lastDonated||"")}"></div>
      </div>
      <div class="field"><label><input type="checkbox" id="bd_available" ${!d||d.available?"checked":""}> Available to donate</label></div>
      <div class="field"><label>Note (optional)</label><input id="bd_note" value="${esc(d?.note||"")}" placeholder="Any health note…"></div>
      <button class="btn btn-primary btn-block" type="submit">${d?"Update":"Register as Blood Donor"}</button>
      ${d?`<button class="btn btn-danger btn-block" type="button" onclick="removeBloodDonor()" style="margin-top:8px">Remove from blood donors</button>`:""}
    </form>
  `;
  $("#bdForm").addEventListener("submit",async(e)=>{
    e.preventDefault();
    const body={
      name:$("#bd_name").value.trim(),
      bloodGroup:$("#bd_bloodGroup").value,
      phone:$("#bd_phone").value.trim(),
      city:$("#bd_city").value.trim(),
      area:$("#bd_area").value.trim()||null,
      lastDonated:$("#bd_lastDonated").value||null,
      available:$("#bd_available").checked?"true":"false",
      note:$("#bd_note").value.trim()||null,
    };
    const btn=e.target.querySelector("button[type=submit]"); btn.disabled=true; btn.textContent="Saving…";
    const {data:dd,error:err}=await api("/api/blood-donors",{method:"POST",body});
    btn.disabled=false; btn.textContent="Update";
    if(err){$("#bdAlert").innerHTML=`<div class="alert alert-error">${esc(err)}</div>`;return;}
    $("#bdAlert").innerHTML=`<div class="alert alert-success">${esc(dd.message||"Saved")}</div>`;
    toast("Blood donation details saved","success");
    await loadBloodDonorSection();
  });
}
async function removeBloodDonor(){
  if(!confirm("Remove yourself from the blood donor directory?")) return;
  const {error}=await api("/api/blood-donors/me",{method:"DELETE"});
  if(error) return toast(error,"error");
  toast("Removed from blood donors","success");
  await loadBloodDonorSection();
}
window.removeBloodDonor=removeBloodDonor;

/* ---------- Blood donors directory ---------- */
async function viewBloodDonors(){
  mount(loadingView());
  const bg=qs("bloodGroup")||"";
  const ct=qs("city")||"";
  const {data}=await api("/api/blood-donors"+location.hash.replace(/^#\/blood-donors/,""));
  const list=data?.donors||[];
  const cities=[...new Set(list.map(d=>d.city).filter(Boolean))].sort();
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>${t("bloodDonors")}</h1><p>${list.length} ${t("registeredDonors")}</p></div>
  <div class="toolbar">
    <select id="bdF_bg" onchange="bdFilter()">
      <option value="">All blood groups</option>
      ${["A+","A-","B+","B-","AB+","AB-","O+","O-"].map(g=>`<option value="${g}" ${g===bg?"selected":""}>${g}</option>`).join("")}
    </select>
    <select id="bdF_city" onchange="bdFilter()">
      <option value="">All cities</option>
      ${cities.map(c=>`<option value="${esc(c)}" ${c===ct?"selected":""}>${esc(c)}</option>`).join("")}
    </select>
  </div>
  <div id="bdList">${list.length?list.map(bloodDonorCard).join(""):emptyState("No donors found","Be the first to register as a blood donor!")}</div>
  ${!state.user?`<div style="text-align:center;margin-top:14px"><a class="btn btn-primary" href="#/login">Sign in to become a donor</a></div>`:""}
  `;
  mount(inner,()=>{window.__bdonors=list;});
  $("#bdF_bg").addEventListener("change",bdFilter);
  $("#bdF_city").addEventListener("change",bdFilter);
}
window.bdFilter=function(){
  const bg=$("#bdF_bg").value, ct=$("#bdF_city").value;
  let list=window.__bdonors||[];
  if(bg) list=list.filter(d=>d.bloodGroup===bg);
  if(ct) list=list.filter(d=>d.city===ct);
  $("#bdList").innerHTML=list.length?list.map(bloodDonorCard).join(""):emptyState("No donors found","Try a different filter.");
};
function bloodDonorCard(d){
  return `
  <div class="amb-card" style="border-left-color:var(--red)">
    <div class="amb-top">
      <div class="amb-ico" style="background:#FEE2E2;color:#DC2626;font-weight:700;font-size:14px">${esc(d.bloodGroup)}</div>
      <div class="amb-info">
        <div class="amb-name">${esc(d.name)}</div>
        <div class="amb-city">📍 ${esc(d.city)}${d.area?", "+esc(d.area):""} · ${d.available?'<span class="badge badge-success">Available</span>':'<span class="badge badge-gray">Unavailable</span>'}</div>
      </div>
    </div>
    ${d.lastDonated?`<div class="amb-row"><span>Last donated</span><span>${esc(d.lastDonated)}</span></div>`:""}
    ${d.note?`<div class="amb-row"><span>Note</span><span>${esc(d.note)}</span></div>`:""}
    <div class="amb-btns">
      <a class="b-call" style="background:var(--red)" href="tel:${esc(d.phone)}">📞 Call</a>
      ${d.available?`<a class="b-map" href="sms:${esc(d.phone)}">💬 Message</a>`:""}
    </div>
  </div>`;
}

/* ===================================================================
   PRIVACY POLICY & TERMS OF USE
   =================================================================== */
function viewPrivacyPolicy(){
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>🔒 Privacy Policy</h1><p>Last updated: October 2026</p></div>
  <div class="form-card">
    <div class="form-section-title">📋 Introduction</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">Doctor App ("we", "us", or "our") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application and website. Please read this policy carefully. If you do not agree with the terms, please do not use the service.</p>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">🗂️ Information We Collect</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">We collect the following types of information:</p>
    <ul style="font-size:14px;line-height:1.8;color:var(--text-2);padding-left:20px">
      <li><strong>Personal Information:</strong> Name, email address, phone number, blood group, and address when you create an account.</li>
      <li><strong>Health Information:</strong> Medicine reminders, health metrics (blood pressure, glucose, etc.) that you voluntarily log.</li>
      <li><strong>Usage Data:</strong> Information about how you interact with the app, including device type, browser, and pages visited.</li>
      <li><strong>Ratings & Reviews:</strong> Your ratings and reviews for doctors, hospitals, and ambulance services.</li>
    </ul>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">🔧 How We Use Your Information</div>
    <ul style="font-size:14px;line-height:1.8;color:var(--text-2);padding-left:20px">
      <li>To provide and maintain the service, including doctor/hospital/ambulance search.</li>
      <li>To manage your account and provide personalized features like medicine tracking.</li>
      <li>To display ratings and reviews to help other users make informed decisions.</li>
      <li>To send notifications about medicine reminders and health updates.</li>
      <li>To improve our services based on your feedback and usage patterns.</li>
      <li>To comply with legal obligations and protect against fraud.</li>
    </ul>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">🛡️ Data Security</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">We implement appropriate technical and organizational measures to protect your personal information, including encrypted password storage (scrypt hashing), secure session management, and regular security reviews. However, no method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.</p>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">📤 Information Sharing</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">We do not sell, trade, or rent your personal information to third parties. We may share your information only in the following circumstances:</p>
    <ul style="font-size:14px;line-height:1.8;color:var(--text-2);padding-left:20px">
      <li>With healthcare providers you contact through the app (doctors, hospitals, ambulances).</li>
      <li>When required by law, court order, or government regulation.</li>
      <li>To protect the rights, property, or safety of our users or others.</li>
    </ul>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">🗑️ Data Retention & Deletion</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">We retain your information for as long as your account is active. You can request deletion of your account and associated data at any time by contacting us. Medicine reminders and health metrics stored locally on your device can be cleared from the app settings.</p>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">👤 Your Rights</div>
    <ul style="font-size:14px;line-height:1.8;color:var(--text-2);padding-left:20px">
      <li><strong>Access:</strong> You can view your personal information in your profile.</li>
      <li><strong>Update:</strong> You can edit your profile information at any time.</li>
      <li><strong>Delete:</strong> You can request account deletion by contacting support.</li>
      <li><strong>Opt-out:</strong> You can disable notifications and clear local data from settings.</li>
    </ul>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">📞 Contact Us</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">If you have questions about this Privacy Policy, please contact us at: <strong>contacttosharif@gmail.com</strong></p>
  </div>
  `;
  mount(inner);
  window.scrollTo(0,0);
}

function viewTermsOfUse(){
  const inner=`
  <div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a><h1>📄 Terms of Use</h1><p>Last updated: October 2026</p></div>
  <div class="form-card">
    <div class="form-section-title">📋 Agreement to Terms</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">By accessing and using Doctor App, you accept and agree to be bound by these Terms of Use. If you do not agree to these terms, please do not use our service. These terms apply to all users of the application.</p>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">🩺 Medical Disclaimer</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)"><strong>Important:</strong> Doctor App is a directory and health tracking tool, NOT a medical service. The information provided through this app is for general informational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of a qualified healthcare provider with any questions you may have regarding a medical condition. Never disregard professional medical advice or delay in seeking it because of something you have read on this app.</p>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">✅ Acceptable Use</div>
    <ul style="font-size:14px;line-height:1.8;color:var(--text-2);padding-left:20px">
      <li>Use the app only for lawful purposes and in accordance with these terms.</li>
      <li>Provide accurate and complete information when creating an account.</li>
      <li>Rate and review doctors, hospitals, and ambulances honestly and fairly.</li>
      <li>Respect the privacy and rights of other users and healthcare providers.</li>
      <li>Use medicine reminders and health tracking features for personal use only.</li>
    </ul>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">❌ Prohibited Conduct</div>
    <ul style="font-size:14px;line-height:1.8;color:var(--text-2);padding-left:20px">
      <li>Using the app for any illegal or unauthorized purpose.</li>
      <li>Posting false, misleading, or fraudulent ratings and reviews.</li>
      <li>Attempting to interfere with, disrupt, or disable the service.</li>
      <li>Sharing your account credentials with others.</li>
      <li>Scraping, copying, or duplicating content without permission.</li>
      <li>Harassing, abusing, or harming other users or healthcare providers.</li>
    </ul>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">🏥 Healthcare Provider Listings</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">Doctor App lists healthcare providers (doctors, hospitals, ambulances) for informational purposes only. We do not endorse any specific provider and are not responsible for the quality of services provided. Users are solely responsible for their choice of healthcare provider and the outcomes of any medical consultation or service.</p>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">💊 Medicine & Health Tracking</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">The medicine reminder and health metrics features are provided as tools to help you manage your health. They are not medical devices and should not replace professional medical advice. Always follow your doctor's instructions regarding medication. We are not liable for any health consequences resulting from the use of these tracking features.</p>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">⚖️ Limitation of Liability</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">To the maximum extent permitted by law, Doctor App and its operators shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of the service.</p>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">🔄 Changes to Terms</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">We reserve the right to modify these terms at any time. We will notify users of significant changes through the app. Your continued use of the service after changes constitutes acceptance of the new terms.</p>
  </div>
  <div class="form-card" style="margin-top:14px">
    <div class="form-section-title">📞 Contact Us</div>
    <p style="font-size:14px;line-height:1.7;color:var(--text-2)">If you have questions about these Terms of Use, please contact us at: <strong>contacttosharif@gmail.com</strong></p>
  </div>
  `;
  mount(inner);
  window.scrollTo(0,0);
}

/* ===================================================================
   ROUTER
   =================================================================== */
async function render(){
  closeDrawer();
  const parts=pathParts();
  const root=parts[0]||"";
  if(root==="")return viewHome();
  if(root==="doctors"){if(parts[1])return viewDoctorDetail(parts[1]);return viewDoctors();}
  if(root==="hospitals"){if(parts[1])return viewHospitalDetail(parts[1]);return viewHospitals();}
  if(root==="ambulances")return viewAmbulances();
  if(root==="blood-donors")return viewBloodDonors();
  if(root==="medicine"){if(parts[1])return viewMedicineDetail(parts[1]);return viewMedicineTracker();}
  if(root==="categories")return viewCategories();
  if(root==="articles"){if(parts[1])return viewArticleDetail(parts[1]);return viewArticles();}
  if(root==="login")return viewLogin();
  if(root==="register")return viewRegister();
  if(root==="forgot")return viewForgot();
  if(root==="reset")return viewReset();
  if(root==="doctor-profile")return viewDoctorProfile();
  if(root==="admin")return viewAdmin();
  if(root==="account")return viewAccount();
  if(root==="privacy")return viewPrivacyPolicy();
  if(root==="terms")return viewTermsOfUse();
  mount(`<div class="page-head"><a class="back-link" href="#/">${t("backHome")}</a></div>${emptyState("Page not found","The page you requested does not exist.")}<div style="text-align:center;margin-top:12px"><a class="btn btn-primary" href="#/">Go home</a></div>`);
}

async function init(){
  // Load persisted preferences
  try{
    state.lang = localStorage.getItem("da_lang") || "en";
    state.theme = localStorage.getItem("da_theme") || "light";
    if(state.theme==="dark") document.body.classList.add("dark");
  }catch(e){}
  loadNotifs();
  loadFavs();
  await loadMe();
  // If the iframe has no hash but the parent window does (refresh case),
  // copy the parent hash so we stay on the same page.
  if(!location.hash && window.parent && window.parent.location && window.parent.location.hash){
    location.hash = window.parent.location.hash;
  }
  render();
  window.addEventListener("hashchange",render);
  // Sync parent hash when iframe hash changes (so refresh keeps the page)
  try{
    if(window.parent && window.parent!==window){
      window.addEventListener("hashchange",()=>{
        try{ window.parent.location.hash = location.hash; }catch(e){}
      });
    }
  }catch(e){}
  // Register service worker for PWA install
  if("serviceWorker" in navigator){
    navigator.serviceWorker.register("/sw.js").catch(()=>{});
  }
}
function bootstrap(){
  if(window.__mcBooted)return;
  window.__mcBooted=true;
  // Intercept all clicks on <a href="#/..."> links so they use navigate()
  // instead of the browser's default (which reloads the srcdoc iframe).
  document.addEventListener("click",(e)=>{
    const link = e.target.closest('a[href^="#/"]');
    if(link){
      e.preventDefault();
      const href = link.getAttribute("href");
      // href is like "#/doctors" → navigate to "/doctors"
      const path = href.replace(/^#\/?/,"/");
      navigate(path);
    }
  });
  // Capture PWA install prompt
  window.addEventListener("beforeinstallprompt",(e)=>{
    e.preventDefault();
    state.deferredPrompt = e;
    toast("Install Doctor App from the menu","info");
  });
  init().catch(e=>console.error("Doctor App init error:",e));
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bootstrap);
else bootstrap();
