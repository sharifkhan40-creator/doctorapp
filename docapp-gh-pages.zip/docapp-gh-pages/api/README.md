# API Endpoints — Doctor App

This folder documents the backend API consumed by the static front-end in
`/js/app.js`. The front-end uses `fetch()` against these paths, which means
**GitHub Pages alone cannot serve the dynamic endpoints** — only static JSON
files. The `stubs/` subfolder contains example responses for each endpoint.

To make the site fully functional, you have three options:

| Option | How |
| --- | --- |
| **1. Deploy the original Next.js app** to Vercel / Netlify / Render, keep the static site on GitHub Pages, and update `api()` in `js/app.js` to prefix requests with the backend URL. | Edit `js/app.js` line ~1286: `fetch(path, ...)` → `fetch(API_BASE + path, ...)` |
| **2. Convert the static site to call the stub JSON files directly** (read-only demo, no login/writes). | Edit `api()` in `js/app.js` to map `/api/doctors` → `/api/stubs/doctors.json`. Auth/admin features will still fail. |
| **3. Reimplement the backend as serverless functions** (Cloudflare Workers, Vercel Edge, GitHub Pages Functions via Actions). | Out of scope of this conversion. |

## Endpoint reference

### Public (no auth)

| Method | Path | Response |
| --- | --- | --- |
| GET | `/api/slides` | `{ slides: Slide[] }` |
| GET | `/api/categories` | `{ categories: Category[] }` |
| GET | `/api/cities` | `{ cities: City[] }` |
| GET | `/api/doctors` | `{ doctors: DoctorProfile[] }` — supports `?q=`, `?specialty=`, `?city=`, `?hospitalId=` |
| GET | `/api/doctors/:id` | `{ doctor: DoctorProfile }` |
| GET | `/api/hospitals` | `{ hospitals: Hospital[] }` — supports `?q=`, `?city=` |
| GET | `/api/hospitals/:id` | `{ hospital: Hospital }` |
| GET | `/api/ambulances` | `{ ambulances: Ambulance[] }` |
| GET | `/api/articles` | `{ articles: Article[] }` |
| GET | `/api/articles/:id` | `{ article: Article }` |
| GET | `/api/blood-donors` | `{ donors: BloodDonor[] }` |
| GET | `/api/ratings?entityType=doctor&entityId=...` | `{ ratings: Rating[] }` |
| POST | `/api/ratings` | `{ rating: Rating }` — body: `{ entityType, entityId, rating, review? }` |
| POST | `/api/ai-chat` | `{ reply: string }` — body: `{ messages: [...] }` |

### Auth

| Method | Path | Body | Response |
| --- | --- | --- | --- |
| GET | `/api/auth/me` | — | `{ user: User \| null, needsApproval?: boolean, profile?: any }` |
| POST | `/api/auth/login` | `{ identifier, password }` | `{ user, message }` |
| POST | `/api/auth/register` | `{ email, username, password, role?, hospitalId? }` | `{ user, message }` |
| POST | `/api/auth/logout` | — | `{ message }` |
| POST | `/api/auth/logout-all` | — | `{ message }` |
| POST | `/api/auth/forgot-password` | `{ email }` | `{ message }` |
| POST | `/api/auth/reset-password` | `{ token, password }` | `{ message }` |

### Logged-in user

| Method | Path | Body |
| --- | --- | --- |
| GET | `/api/user/profile` | — |
| PUT | `/api/user/profile` | `{ name, phone, address, bloodGroup, photo }` |
| GET | `/api/doctor/profile` | — |
| PUT | `/api/doctor/profile` | Doctor profile fields |
| GET | `/api/blood-donors/me` | — |
| POST | `/api/blood-donors` | Blood donor fields |
| PUT | `/api/blood-donors/me` | Blood donor fields |
| GET | `/api/medicine-reminders` | — |
| POST | `/api/medicine-reminders` | `{ medicineName, dosage, times, startDate, endDate?, notes? }` |
| PUT | `/api/medicine-reminders/:id` | same |
| DELETE | `/api/medicine-reminders/:id` | — |

### Admin (requires `ADMIN` or `SUPER_ADMIN` role)

| Method | Path |
| --- | --- |
| GET/POST | `/api/admin/doctors` |
| GET/PUT/DELETE | `/api/admin/doctors/:id` |
| GET/POST | `/api/admin/hospitals` |
| GET/PUT/DELETE | `/api/admin/hospitals/:id` |
| GET/POST | `/api/admin/ambulances` |
| GET/PUT/DELETE | `/api/admin/ambulances/:id` |
| GET/POST | `/api/admin/articles` |
| GET/PUT/DELETE | `/api/admin/articles/:id` |
| GET/POST | `/api/admin/categories` |
| GET/PUT/DELETE | `/api/admin/categories/:id` |
| GET/POST | `/api/admin/cities` |
| GET/PUT/DELETE | `/api/admin/cities/:id` |
| GET/POST | `/api/admin/slides` |
| GET/PUT/DELETE | `/api/admin/slides/:id` |
| GET | `/api/admin/users` |
| PUT | `/api/admin/users/:id` (status / role changes) |
| GET/PUT | `/api/admin/profile` |

## Stub files

Look in `stubs/` for example responses. File names map to endpoints like so:

| Endpoint | Stub file |
| --- | --- |
| GET `/api/doctors` | `stubs/doctors.json` |
| GET `/api/hospitals` | `stubs/hospitals.json` |
| GET `/api/ambulances` | `stubs/ambulances.json` |
| GET `/api/articles` | `stubs/articles.json` |
| GET `/api/categories` | `stubs/categories.json` |
| GET `/api/cities` | `stubs/cities.json` |
| GET `/api/slides` | `stubs/slides.json` |
| GET `/api/auth/me` (logged out) | `stubs/auth_me.json` |
| GET `/api/auth/me` (logged in) | `stubs/auth_me_logged_in.json` |
| POST `/api/auth/login` | `stubs/auth_login_response.json` |
| POST `/api/auth/register` | `stubs/auth_register_response.json` |
| POST `/api/auth/forgot-password` | `stubs/auth_forgot_password_response.json` |
| POST `/api/auth/reset-password` | `stubs/auth_reset_password_response.json` |
| POST `/api/ai-chat` | `stubs/ai_chat_response.json` |
| GET `/api/blood-donors` | `stubs/blood_donors.json` |
| GET `/api/blood-donors/me` | `stubs/blood_donors_me.json` |
| GET `/api/ratings` | `stubs/ratings.json` |
| GET `/api/medicine-reminders` | `stubs/medicine_reminders.json` |
| GET `/api/doctor/profile` | `stubs/doctor_profile.json` |
| GET `/api/user/profile` | `stubs/user_profile.json` |
| GET `/api/admin/doctors` | `stubs/admin_doctors.json` |
| GET `/api/admin/hospitals` | `stubs/admin_hospitals.json` |
| GET `/api/admin/ambulances` | `stubs/admin_ambulances.json` |
| GET `/api/admin/articles` | `stubs/admin_articles.json` |
| GET `/api/admin/categories` | `stubs/admin_categories.json` |
| GET `/api/admin/cities` | `stubs/admin_cities.json` |
| GET `/api/admin/slides` | `stubs/admin_slides.json` |
| GET `/api/admin/users` | `stubs/admin_users.json` |
| GET `/api/admin/profile` | `stubs/admin_profile.json` |
